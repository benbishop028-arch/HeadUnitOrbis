TomTom's official navigation example app (SDK 1.26.4), packaged to build with the same workflow.
Orbis map is switched on at start-up. The launcher project is unchanged elsewhere.
