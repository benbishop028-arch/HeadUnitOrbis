# Drive Launcher
Tiguan-style head-unit launcher: top menu, home with a switchable picture-in-picture window (3D map or any app),
media/phone/vehicle/apps/settings pages and a climate bar. Native MapLibre map with TomTom Orbis style, search,
routing, turn-by-turn and voice (TomTom REST API, key via -PtomtomApiKey or Settings).
Build: gradle :app:assembleDebug -PtomtomApiKey=YOUR_KEY
