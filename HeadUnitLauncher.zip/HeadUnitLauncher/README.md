# Head Unit Launcher (TomTom Maps & Navigation SDK v2 / Orbis)

Dark, car-style launcher: left rail (Nav / Media / Call / Settings / Apps), full-screen 3D navigation home page,
and the same live map shrinking into a picture-in-picture window on every other page (tap it to expand).

## Build an APK with GitHub (no local setup)
1. Create a new GitHub repo and push this folder to the `main` branch.
2. Repo > Settings > Secrets and variables > Actions > New secret: `TOMTOM_API_KEY` = your key
   (my.tomtom.com > Maps and Navigation SDK for Android).
3. Actions tab > "Build APK" > Run workflow (it also runs on every push).
4. Download the `HeadUnitLauncher-debug-apk` artifact, unzip, sideload `app-debug.apk`.

## Build locally
Open in Android Studio (JDK 17, SDK 35, NDK 26), put your key in `gradle.properties` (`tomtomApiKey=`), Run.

## Install on the head unit
`adb install app-debug.apk`, press Home, choose "Head Unit Launcher" > Always. Or Settings > Default home app.

## Requirements / caveats
- The TomTom SDK ships only **arm64-v8a** and **x86_64** native libs. 32-bit-only (armeabi-v7a) head units can't run it.
- Needs Vulkan 1.0, Android 8.0+ (minSdk 26), ~2 GB RAM recommended.
- Telemetry consent defaults to Off (Settings page). Check your TomTom contract allows opting out.
- This was written against the TomTom v2.6.x docs but not compiled. Lines that touch SDK types I could not
  verify are tagged `// SDK-CHECK` (grep for them). If the build fails, the errors will point at those lines.


## Update: web map engine
The map is now TomTom Orbis vector tiles rendered by MapLibre GL in a WebView (`app/src/main/assets/nav.html`),
using the same REST endpoints (style, geocoding, routing) as the standalone Orbis Nav test app. The native TomTom
SDK has been removed. Light/dark follows the device setting. Voice prompts rely on the WebView's speech support,
which many head units lack.
