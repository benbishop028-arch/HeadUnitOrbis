package com.headunit.launcher.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.nav.Guidance
import com.headunit.launcher.nav.ManeuverIcon
import com.headunit.launcher.nav.NavUi
import com.headunit.launcher.nav.Place
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.roundToInt

fun ManeuverIcon.vector(): ImageVector = when (this) {
    ManeuverIcon.LEFT -> Icons.Filled.TurnLeft
    ManeuverIcon.RIGHT -> Icons.Filled.TurnRight
    ManeuverIcon.SLIGHT_LEFT -> Icons.Filled.TurnSlightLeft
    ManeuverIcon.SLIGHT_RIGHT -> Icons.Filled.TurnSlightRight
    ManeuverIcon.U_TURN -> Icons.Filled.UTurnLeft
    ManeuverIcon.ARRIVE -> Icons.Filled.Flag
    ManeuverIcon.STRAIGHT -> Icons.Filled.ArrowUpward
}

fun fmtDist(m: Double): String = when {
    m < 1000 -> "${max(10, (m / 10).roundToInt() * 10)} m"
    m < 10_000 -> String.format("%.1f km", m / 1000).replace(".0 km", " km")
    else -> "${(m / 1000).roundToInt()} km"
}

fun fmtDur(sec: Long): String =
    if (sec < 3600) "${max(1, (sec + 30) / 60)} min" else "${sec / 3600} h ${(sec % 3600) / 60} min"

private val HHMM = DateTimeFormatter.ofPattern("HH:mm")

@Composable
fun rememberClock(plusSeconds: Long = 0): String {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalTime.now(); delay(5_000) } }
    return now.plusSeconds(plusSeconds).format(HHMM)
}

/** Blue turn card: next manoeuvre on top, "Then ..." row underneath (like the reference screenshot). */
@Composable
fun GuidanceBanner(g: Guidance, modifier: Modifier = Modifier) {
    Column(modifier.width(470.dp).clip(RoundedCornerShape(16.dp))) {
        Row(
            Modifier.fillMaxWidth().background(Blue).padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(g.icon.vector(), null, tint = Color.White, modifier = Modifier.size(56.dp))
            Spacer(Modifier.width(24.dp))
            Column {
                Text(fmtDist(g.distanceM.toDouble()), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
                Text(g.text, color = Color.White, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (g.thenIcon != null) {
            Row(
                Modifier.fillMaxWidth().background(BlueSoft).padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(g.thenIcon.vector(), null, tint = Color.White, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(24.dp))
                Text("Then ${g.thenIcon.verb()}", color = Color.White, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Bottom bar: arrival time, distance, duration, traffic delay. Idle = clock + "Where to?". */
@Composable
fun EtaBar(ui: NavUi, onStop: () -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier) {
    val eta = rememberClock(if (ui.navigating) ui.remainingSec else 0)
    Row(
        modifier.width(520.dp)
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(Panel)
            .clickable(enabled = !ui.navigating) { onSearch() }
            .padding(horizontal = 28.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(eta, color = Ink, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
            if (ui.navigating && ui.remainingSec == 0L) {
                Text("Calculating…", color = TextDim, fontSize = 22.sp)
            } else if (ui.navigating) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${fmtDist(ui.remainingM)}  •  ${fmtDur(ui.remainingSec)}  •  ", color = TextDim, fontSize = 22.sp)
                    Icon(Icons.Filled.Traffic, null, tint = Green, modifier = Modifier.size(22.dp))
                    Text(" ${ui.delayMin} min", color = Green, fontSize = 22.sp)
                }
            } else {
                Text("Where to?", color = TextDim, fontSize = 22.sp)
            }
        }
        if (ui.navigating) {
            Surface(
                onClick = onStop, shape = CircleShape, color = Color.Transparent,
                border = BorderStroke(2.dp, TextDim), modifier = Modifier.size(64.dp),
            ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Close, "Stop", tint = Ink, modifier = Modifier.size(32.dp)) } }
        }
    }
}

@Composable
fun RoundBtn(icon: ImageVector, desc: String, onClick: () -> Unit, ring: Color = Line, active: Boolean = false) {
    Surface(
        onClick = onClick, shape = CircleShape, color = if (active) Blue else Panel,
        border = BorderStroke(2.dp, ring), modifier = Modifier.size(68.dp),
    ) { Box(contentAlignment = Alignment.Center) { Icon(icon, desc, tint = if (active) Color.White else Ink, modifier = Modifier.size(32.dp)) } }
}

@Composable
fun SearchPanel(
    results: List<Place>, onSearch: (String) -> Unit, onPick: (Place) -> Unit,
    onClose: () -> Unit, modifier: Modifier = Modifier,
) {
    var q by rememberSaveable { mutableStateOf("") }
    Column(modifier.width(520.dp).clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Search address or place") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch(q) }),
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { onSearch(q) }) { Icon(Icons.Filled.Search, "Search", tint = Accent) }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close", tint = TextDim) }
        }
        LazyColumn(Modifier.heightIn(max = 320.dp)) {
            items(results) { p ->
                Column(Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 12.dp, horizontal = 8.dp)) {
                    Text(p.name, color = Ink, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(p.address, color = TextDim, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                HorizontalDivider(color = Line)
            }
        }
    }
}

/** Compact manoeuvre chip shown on the picture-in-picture map. */
@Composable
fun PipChip(g: Guidance, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).background(Blue).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(g.icon.vector(), null, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(8.dp))
        Text(fmtDist(g.distanceM.toDouble()), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}


fun ManeuverIcon.verb(): String = when (this) {
    ManeuverIcon.STRAIGHT -> "continue straight"
    ManeuverIcon.LEFT -> "turn left"
    ManeuverIcon.RIGHT -> "turn right"
    ManeuverIcon.SLIGHT_LEFT -> "bear left"
    ManeuverIcon.SLIGHT_RIGHT -> "bear right"
    ManeuverIcon.U_TURN -> "make a U-turn"
    ManeuverIcon.ARRIVE -> "arrive"
}

@Composable
fun RoundTextBtn(label: String, onClick: () -> Unit, active: Boolean = false) {
    Surface(
        onClick = onClick, shape = CircleShape, color = if (active) Blue else Panel,
        border = BorderStroke(2.dp, Line), modifier = Modifier.size(68.dp),
    ) { Box(contentAlignment = Alignment.Center) { Text(label, color = if (active) Color.White else Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }
}
