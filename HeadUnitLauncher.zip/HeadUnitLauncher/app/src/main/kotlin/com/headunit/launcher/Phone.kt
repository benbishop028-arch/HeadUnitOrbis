package com.headunit.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class Contact(val name: String, val number: String)
class CallEntry(val name: String, val number: String, val type: Int, val date: Long)

object PhoneData {
    val permissions = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE)

    private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun hasContacts(ctx: Context) = granted(ctx, Manifest.permission.READ_CONTACTS)
    fun hasCalls(ctx: Context) = granted(ctx, Manifest.permission.READ_CALL_LOG)

    fun contacts(ctx: Context): List<Contact> {
        if (!hasContacts(ctx)) return emptyList()
        val out = ArrayList<Contact>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC",
            )?.use { c ->
                while (c.moveToNext() && out.size < 3000) {
                    val n = c.getString(1) ?: continue
                    out += Contact(c.getString(0) ?: n, n)
                }
            }
        } catch (e: Exception) { /* permission revoked or provider missing */ }
        return out.distinctBy { it.name + "|" + it.number.filter { ch -> ch.isDigit() } }
    }

    fun calls(ctx: Context): List<CallEntry> {
        if (!hasCalls(ctx)) return emptyList()
        val out = ArrayList<CallEntry>()
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < 60) {
                    val n = c.getString(1) ?: continue
                    out += CallEntry(c.getString(0) ?: "", n, c.getInt(2), c.getLong(3))
                }
            }
        } catch (e: Exception) { /* ignore */ }
        return out
    }

    /** Calls directly when allowed, otherwise opens the dialler with the number filled in. */
    fun call(ctx: Context, number: String) {
        val uri = Uri.parse("tel:" + Uri.encode(number))
        val action = if (granted(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        try {
            ctx.startActivity(Intent(action, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { /* no phone app */ }
        }
    }
}
