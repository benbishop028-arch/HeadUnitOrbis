package com.headunit.launcher

import android.content.Context
import android.media.RingtoneManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Stopwatch and countdown timer. They live here (not in a screen) so they keep running when you leave the page. */
object ClockTools {
    var ctx: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // stopwatch
    var swRunning by mutableStateOf(false)
    var swElapsed by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>()
    private var swBase = 0L
    private var swJob: Job? = null

    fun swToggle() {
        if (swRunning) {
            swRunning = false
            swJob?.cancel()
        } else {
            swRunning = true
            swBase = System.currentTimeMillis() - swElapsed
            swJob = scope.launch { while (true) { swElapsed = System.currentTimeMillis() - swBase; delay(50) } }
        }
    }

    fun swLapOrReset() {
        if (swRunning) laps.add(0, swElapsed)
        else { swElapsed = 0L; laps.clear() }
    }

    // countdown timer
    var timerTotal by mutableLongStateOf(0L)
    var timerLeft by mutableLongStateOf(0L)
    var timerRunning by mutableStateOf(false)
    var timerDone by mutableStateOf(false)
    private var timerEnd = 0L
    private var timerJob: Job? = null

    fun timerSet(ms: Long) {
        timerJob?.cancel()
        timerRunning = false; timerDone = false
        timerTotal = ms; timerLeft = ms
    }

    fun timerAdd(ms: Long) = timerSet((timerTotal + ms).coerceIn(0L, 6 * 3_600_000L))

    fun timerToggle() {
        if (timerRunning) {
            timerRunning = false
            timerJob?.cancel()
            return
        }
        if (timerLeft <= 0L) return
        timerDone = false
        timerRunning = true
        timerEnd = System.currentTimeMillis() + timerLeft
        timerJob = scope.launch {
            while (true) {
                timerLeft = (timerEnd - System.currentTimeMillis()).coerceAtLeast(0L)
                if (timerLeft == 0L) break
                delay(100)
            }
            timerRunning = false
            timerDone = true
            ring()
        }
    }

    fun timerReset() = timerSet(timerTotal)

    private fun ring() {
        val c = ctx ?: return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(c, uri)
            r.play()
            scope.launch { delay(8000); try { r.stop() } catch (_: Exception) {} }
        } catch (e: Exception) { /* no sound available */ }
    }
}
