package com.headunit.launcher.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.headunit.launcher.NavEngine

/** Deep green of the Immersive theme's turn card (and a darker shade for its "then" row). */
val GmGreen = Color(0xFF127A6C)
val GmGreenDeep = Color(0xFF0C5C52)

/** True while the Immersive map theme is selected in Map settings. */
val NavEngine.immersive: Boolean get() = prefs.s("maptheme", "classic") == "immersive"

/** Surface of floating pills and chips in the Immersive theme: near-black at night, white by day. */
@Composable
fun immSurface(): Color = if (LocalVw.current.dark) Color(0xF21B1F27) else Color(0xF7FFFFFF)
