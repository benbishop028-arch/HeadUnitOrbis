package com.headunit.launcher.ui

import androidx.compose.ui.graphics.Color
import com.headunit.launcher.NavEngine

/** Deep green of the Immersive theme's turn card (and a darker shade for its "then" row). */
val GmGreen = Color(0xFF0B7A3E)
val GmGreenDeep = Color(0xFF075F2F)

/** True while the Immersive map theme is selected in Map settings. */
val NavEngine.immersive: Boolean get() = prefs.s("maptheme", "classic") == "immersive"
