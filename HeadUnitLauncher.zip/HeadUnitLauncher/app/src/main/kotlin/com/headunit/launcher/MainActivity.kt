package com.headunit.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.headunit.launcher.ui.App

class MainActivity : ComponentActivity() {
    private lateinit var map: MapBinding
    private lateinit var engine: NavEngine

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClockTools.ctx = applicationContext
        // keep the last crash so it can be read in Map settings
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        val crashFile = java.io.File(applicationContext.filesDir, "lastcrash.txt")
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile.writeText("Thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(3000)) } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val prefs = Prefs(applicationContext)
        map = MapBinding(this, prefs.b("mapfast", true), (prefs.s("mapres", "80").toIntOrNull() ?: 80) / 100f).also { it.setArrowScale((prefs.s("arrowpct", "240").toIntOrNull() ?: 240) / 100f) }
        lifecycle.addObserver(map)
        engine = NavEngine(applicationContext, prefs, map)
        val apps = AppsRepo(applicationContext)

        setContent { App(prefs, engine, map, apps) }

        if (!hasLocation()) perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    override fun onResume() {
        super.onResume()
        // after the permission dialog closes, wait a beat so the UI is settled before starting GPS
        if (hasLocation()) window.decorView.postDelayed({ if (!isFinishing && !isDestroyed) engine.startLocation() }, 400)
    }

    override fun onDestroy() {
        super.onDestroy()
        engine.shutdown()
    }
}
