package com.headunit.launcher

import org.json.JSONArray
import org.json.JSONObject

/** Saved places (home, work, favourites, recents, parked car), stored as JSON in [Prefs]. */
class PlaceStore(private val prefs: Prefs) {
    private fun enc(p: Place) = JSONObject().put("n", p.name).put("s", p.sub).put("la", p.pos.lat).put("lo", p.pos.lon)
    private fun dec(o: JSONObject) = Place(o.optString("n"), o.optString("s"), LL(o.getDouble("la"), o.getDouble("lo")))

    private fun readOne(key: String): Place? {
        val s = prefs.s(key, "")
        if (s.isBlank()) return null
        return try { dec(JSONObject(s)) } catch (e: Exception) { null }
    }

    private fun readList(key: String): List<Place> {
        val s = prefs.s(key, "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).mapNotNull { try { dec(a.getJSONObject(it)) } catch (e: Exception) { null } }
        } catch (e: Exception) { emptyList() }
    }

    private fun writeList(key: String, list: List<Place>) {
        val a = JSONArray()
        list.forEach { a.put(enc(it)) }
        prefs.put(key, a.toString())
    }

    private fun same(a: Place, b: Place) = Geo.dist(a.pos, b.pos) < 60

    fun slot(name: String): Place? = readOne("place_$name")
    fun setSlot(name: String, p: Place) = prefs.put("place_$name", enc(p).toString())

    fun parked(): Place? = readOne("place_parked")
    fun setParked(p: Place) = prefs.put("place_parked", enc(p).toString())

    fun favourites(): List<Place> = readList("places_fav")
    fun isFavourite(p: Place) = favourites().any { same(it, p) }
    fun toggleFavourite(p: Place): Boolean {
        val cur = favourites()
        return if (cur.any { same(it, p) }) {
            writeList("places_fav", cur.filterNot { same(it, p) }); false
        } else {
            writeList("places_fav", (listOf(p) + cur).take(20)); true
        }
    }

    fun recents(): List<Place> = readList("places_recent")
    fun addRecent(p: Place) {
        writeList("places_recent", (listOf(p) + recents().filterNot { same(it, p) }).take(8))
        // everywhere you have routed to is also kept for searching without signal
        writeList("places_seen", (listOf(p) + readList("places_seen").filterNot { same(it, p) }).take(600))
    }

    /** Search over saved, favourite and previously used places only: works without any signal. */
    fun searchLocal(q: String, near: LL?): List<Place> {
        val toks = q.lowercase().split(' ', ',').filter { it.isNotBlank() }
        if (toks.isEmpty()) return emptyList()
        val pool = ArrayList<Place>()
        slot("home")?.let { pool += Place("Home", it.name, it.pos) }
        slot("work")?.let { pool += Place("Work", it.name, it.pos) }
        pool += favourites(); pool += recents(); pool += readList("places_seen")
        val uniq = ArrayList<Place>()
        for (p in pool) if (uniq.none { same(it, p) }) uniq += p
        return uniq.filter { p -> val h = (p.name + " " + p.sub).lowercase(); toks.all { h.contains(it) } }
            .sortedBy { p -> (if (p.name.lowercase().startsWith(toks[0])) 0.0 else 1e7) + (if (near != null) Geo.dist(near, p.pos) else 0.0) }
            .take(10)
    }
}

// ------------------------------------------------------------------ trips, fuel, service

class Trip(val start: Long, val end: Long, val dist: Double, val moving: Long, val maxSpeed: Double, val to: String)

class TripStore(private val prefs: Prefs) {
    fun all(): List<Trip> {
        val s = prefs.s("trips", "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).mapNotNull {
                try {
                    val o = a.getJSONObject(it)
                    Trip(o.getLong("s"), o.getLong("e"), o.getDouble("d"), o.getLong("m"), o.getDouble("v"), o.optString("t"))
                } catch (e: Exception) { null }
            }
        } catch (e: Exception) { emptyList() }
    }

    fun add(t: Trip) {
        val a = JSONArray()
        (listOf(t) + all()).take(300).forEach {
            a.put(JSONObject().put("s", it.start).put("e", it.end).put("d", it.dist).put("m", it.moving).put("v", it.maxSpeed).put("t", it.to))
        }
        prefs.put("trips", a.toString())
    }

    fun clear() = prefs.put("trips", "")
}

class FuelEntry(val date: Long, val litres: Double, val cost: Double, val odo: Double)

class FuelStore(private val prefs: Prefs) {
    fun all(): List<FuelEntry> {
        val s = prefs.s("fuellog", "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).mapNotNull {
                try {
                    val o = a.getJSONObject(it)
                    FuelEntry(o.getLong("d"), o.getDouble("l"), o.getDouble("c"), o.optDouble("o", 0.0))
                } catch (e: Exception) { null }
            }.sortedByDescending { it.date }
        } catch (e: Exception) { emptyList() }
    }

    private fun write(list: List<FuelEntry>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("d", it.date).put("l", it.litres).put("c", it.cost).put("o", it.odo)) }
        prefs.put("fuellog", a.toString())
    }

    fun add(e: FuelEntry) = write(listOf(e) + all())
    fun remove(date: Long) = write(all().filterNot { it.date == date })
}

class Service(val id: Long, val name: String, val due: Long, val repeatMonths: Int)

class ServiceStore(private val prefs: Prefs) {
    fun all(): List<Service> {
        val s = prefs.s("services", "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).mapNotNull {
                try {
                    val o = a.getJSONObject(it)
                    Service(o.getLong("i"), o.getString("n"), o.getLong("d"), o.optInt("r", 0))
                } catch (e: Exception) { null }
            }.sortedBy { it.due }
        } catch (e: Exception) { emptyList() }
    }

    private fun write(list: List<Service>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("i", it.id).put("n", it.name).put("d", it.due).put("r", it.repeatMonths)) }
        prefs.put("services", a.toString())
    }

    fun add(name: String, due: Long, repeatMonths: Int) = write(all() + Service(System.currentTimeMillis(), name, due, repeatMonths))
    fun remove(id: Long) = write(all().filterNot { it.id == id })

    /** Marks a job done: repeating jobs move to their next date, one-off jobs are removed. */
    fun done(id: Long) {
        write(all().mapNotNull {
            if (it.id != id) it
            else if (it.repeatMonths > 0) {
                val c = java.util.Calendar.getInstance()
                c.timeInMillis = maxOf(it.due, System.currentTimeMillis())
                c.add(java.util.Calendar.MONTH, it.repeatMonths)
                Service(it.id, it.name, c.timeInMillis, it.repeatMonths)
            } else null
        })
    }

    /** Text for a start-up reminder when something is overdue or due within two weeks. */
    fun dueSoon(): String? {
        val soon = all().firstOrNull { it.due - System.currentTimeMillis() < 14L * 86_400_000L } ?: return null
        val days = Math.floor((soon.due - System.currentTimeMillis()) / 86_400_000.0).toInt()
        return if (days < 0) "${soon.name} is overdue" else if (days == 0) "${soon.name} is due today" else "${soon.name} due in $days days"
    }
}
