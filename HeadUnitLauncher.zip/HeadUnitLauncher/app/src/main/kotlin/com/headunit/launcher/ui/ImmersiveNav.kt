package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EvStation
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import kotlinx.coroutines.delay

/** Palette of the Immersive theme's panels: soft charcoal at night, clean white by day, with a Google-like blue accent. */
private fun immVw(c: Vw): Vw =
    if (c.dark) c.copy(
        surface = Color(0xE61F2339), surface2 = Color(0xFF282D48), tile = Color(0xFF2B3050),
        text = Color(0xFFF0F2FA), sub = Color(0xFFA0A8C4), accent = Color(0xFF82B1FF), line = Color(0x1FFFFFFF),
    ) else c.copy(
        surface = Color(0xEBFFFFFF), surface2 = Color(0xFFF2F4FA), tile = Color(0xFFEEF1F8),
        text = Color(0xFF1F2433), sub = Color(0xFF5C6478), accent = Color(0xFF2F7BEA), line = Color(0x14000000),
    )

private val Teal = GmGreen
private val TealDeep = GmGreenDeep

/** The whole map overlay for the Immersive theme. It shares no layout or styling with the classic overlay. */
@Composable
fun ImmersiveNav(engine: NavEngine) {
    val base = LocalVw.current
    val v = remember(base) { immVw(base) }
    CompositionLocalProvider(LocalVw provides v) { ImmBody(engine) }
}

@Composable
private fun ImmCircle(onClick: () -> Unit, size: Dp = 52.dp, active: Boolean = false, content: @Composable BoxScope.() -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(size).shadow(6.dp, CircleShape).clip(CircleShape).background(if (active) c.accent else c.surface).pressClick(onClick),
        contentAlignment = Alignment.Center, content = content,
    )
}

@Composable
private fun ImmIcon(icon: ImageVector, onClick: () -> Unit, active: Boolean = false, size: Dp = 52.dp) {
    val c = LocalVw.current
    ImmCircle(onClick, size, active) { Icon(icon, null, tint = if (active) Color.White else c.text, modifier = Modifier.size(size * 0.46f)) }
}

@Composable
private fun ImmPill(text: String, onClick: () -> Unit, icon: ImageVector? = null, filled: Boolean = false) {
    val c = LocalVw.current
    val fg = if (filled) Color.White else c.text
    Row(
        Modifier.height(48.dp).shadow(6.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(if (filled) c.accent else c.surface)
            .pressClick(onClick).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (icon != null) Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        Text(text, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun ImmBody(engine: NavEngine) {
    val c = LocalVw.current
    val shareEta = rememberShareEta(engine)
    var q by rememberSaveable { mutableStateOf("") }
    var layers by remember { mutableStateOf(false) }
    val voice = rememberVoiceInput("Say a destination") { q = it; engine.search(it) }
    val typingLocked by remember { derivedStateOf { (engine.fix?.speed ?: 0.0) > 3.0 && engine.prefs.b("drivelock", true) } }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q) {
        if (q.length >= 3) { delay(500); engine.search(q) } else if (q.isEmpty()) engine.results = emptyList()
    }
    val routing = engine.route != null && !engine.previewing
    val previewing = engine.previewing
    val simple by remember { derivedStateOf { engine.driving && engine.prefs.b("drivesimple", true) } }

    Box(Modifier.fillMaxSize().padding(vertical = 6.dp)) {
        // top left: search while idle, add-stop and the turn card while navigating
        Column(Modifier.align(Alignment.TopStart).padding(14.dp).width(372.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!routing && !previewing) {
                ImmSearch(engine, q, { q = it }, typingLocked, focus, voice)
                if (engine.results.isNotEmpty()) ImmResults(engine) { q = "" }
                else if (q.isEmpty() && engine.nearbyKind == null) ImmQuick(engine) { try { focus.requestFocus() } catch (_: Exception) {} }
            } else if (routing) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    ImmIcon(Icons.Rounded.Mic, { voice() }, size = 48.dp)
                    ImmPill("Add stop", { engine.loadNearby("fuel", false) }, Icons.Rounded.Add)
                }
                if (engine.results.isNotEmpty()) ImmResults(engine) { q = "" }
                else engine.turn?.let { t -> ImmTurnCard(engine, t) }
            }
            if (engine.nearbyKind != null && (!previewing || engine.stopMode)) NearbyCard(engine)
        }

        // top right: options, exit, compass and speed
        if (!previewing) Column(Modifier.align(Alignment.TopEnd).padding(14.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                ImmIcon(Icons.Rounded.Tune, { layers = !layers }, active = layers, size = 48.dp)
                ImmCompass(engine)
                if (routing) ImmPill("Exit", { engine.endRoute() })
            }
        }

        // bottom right: speed limit and your speed
        if (!previewing) Box(Modifier.align(Alignment.BottomEnd).padding(14.dp)) { ImmSpeed(engine) }

        // map layers
        if (layers && !previewing) Column(
            Modifier.align(Alignment.TopEnd).padding(top = 76.dp, end = 86.dp).width(330.dp).shadow(10.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.surface).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Map options", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            LayerRow("Satellite", engine.prefs.b("satellite", false)) { engine.prefs.put("satellite", it) }
            LayerRow("Traffic", engine.prefs.b("traffic", true)) { engine.prefs.put("traffic", it) }
            LayerRow("3D buildings", engine.prefs.b("buildings3d", true)) { engine.prefs.put("buildings3d", it) }
            Text("Find nearby", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Fuel", engine.nearbyKind == "fuel", { engine.loadNearby("fuel", false); layers = false })
                Pill("EV", engine.nearbyKind == "charging", { engine.loadNearby("charging", false); layers = false })
                Pill("Parking", engine.nearbyKind == "parking", { engine.loadNearby("parking", false); layers = false })
            }
            if (engine.dest != null) Pill("Parking at destination", false, { engine.loadNearby("parking", true); layers = false })
        }

        // right edge: round view controls and a zoom capsule
        if (!previewing) Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp, top = 64.dp, bottom = 100.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!simple) {
                ImmCircle({ engine.toggleTilt() }, 52.dp, engine.tilt3d) { Text(if (engine.tilt3d) "3D" else "2D", color = if (engine.tilt3d) Color.White else c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                ImmIcon(when (engine.soundMode) { 0 -> Icons.Rounded.VolumeUp; 1 -> Icons.Rounded.NotificationsActive; else -> Icons.Rounded.VolumeOff }, { engine.cycleSound() })
                if (routing) ImmIcon(Icons.Rounded.Route, { engine.overview() })
                if (engine.prefs.b("demo", false) || engine.simMode != 0) ImmIcon(Icons.Rounded.PlayArrow, { engine.cycleSim() }, active = engine.simMode != 0)
            }
            Column(Modifier.shadow(6.dp, RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp)).background(c.surface), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(52.dp).pressClick { engine.zoom(1.0) }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, "Zoom in", tint = c.text, modifier = Modifier.size(26.dp)) }
                Box(Modifier.width(26.dp).height(1.dp).background(c.line))
                Box(Modifier.size(52.dp).pressClick { engine.zoom(-1.0) }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Remove, "Zoom out", tint = c.text, modifier = Modifier.size(26.dp)) }
            }
        }

        // bottom left: hazards and the trip card (its own composable, so a new ETA only redraws this)
        if (!previewing) Box(Modifier.align(Alignment.BottomStart)) { ImmBottomLeft(engine, shareEta) }

        // bottom centre: re-centre pill appears once you have panned away
        if (!previewing && !engine.following) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) {
            ImmPill("Re-centre", { engine.recenter() }, Icons.Rounded.MyLocation, filled = true)
        }

        if (previewing) RoutePreview(engine)
        engine.arrival?.let { a -> ArrivalCard(engine, a, Modifier.align(Alignment.Center)) }

        engine.faster?.let { fr ->
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp).widthIn(max = 540.dp).shadow(10.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.surface).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Good.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Route, null, tint = Good, modifier = Modifier.size(24.dp)) }
                Column {
                    Text("Faster route found", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Saves about ${fr.savedMin} min", color = Good, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                ImmPill("Switch", { engine.acceptFaster() }, filled = true)
                ImmPill("Keep", { engine.dismissFaster() })
            }
        }

        if (engine.busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = c.accent)
    }
}

@Composable
private fun ImmBottomLeft(engine: NavEngine, shareEta: () -> Unit) {
    val c = LocalVw.current
        val inc = engine.incidentAhead
        val cam = engine.cameraDist
        val eta = engine.eta
        if (inc != null || cam != null || eta != null) Column(Modifier.padding(start = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if ((inc != null && engine.alert?.kind != "incident") || (cam != null && engine.alert?.kind != "camera")) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (inc != null && engine.alert?.kind != "incident") HazardBadge("incident", inc.label, Geo.fmtDist(inc.dist, engine.imperial))
                if (cam != null && engine.alert?.kind != "camera") HazardBadge("camera", "Speed camera", Geo.fmtDist(cam.toDouble(), engine.imperial))
            }
            eta?.let { e ->
                val dc = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else Good
                Row(
                    Modifier.shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(c.surface).padding(start = 20.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    ImmStat(e.arrive, "arrival", c.text)
                    ImmStat(Geo.fmtDur(e.secs), "time left", dc)
                    ImmStat(Geo.fmtDist(e.dist, engine.imperial), "distance", c.text)
                    if (e.delayMin >= 1) Text("+${e.delayMin}", color = dc, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(dc.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 4.dp))
                    ImmCircle({ shareEta() }, 42.dp) { Icon(Icons.Rounded.Share, "Share ETA", tint = c.text, modifier = Modifier.size(20.dp)) }
                }
            }
        }
}

@Composable
private fun ImmStat(value: String, label: String, color: Color) {
    val c = LocalVw.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = c.sub, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun ImmCompass(engine: NavEngine) {
    val c = LocalVw.current
    Box(
        Modifier.size(48.dp).shadow(6.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(c.surface).pressClick { engine.toggleNorthUp() },
        contentAlignment = Alignment.Center,
    ) { Text("N", color = if (engine.northUp) c.accent else c.text, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
}

/** Speed limit sign beside a large readout of your current speed, in one card. */
@Composable
private fun ImmSpeed(engine: NavEngine) {
    val c = LocalVw.current
    val show = engine.prefs.b("mapspeed", true)
    val lim = engine.speedLimit
    if (lim == null && !show) return
    val k = if (engine.imperial) 2.23694 else 3.6
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (lim != null) SpeedLimitSign(engine, 68.dp)
        if (show) Column(
            Modifier.shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(c.surface).padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("${Math.round((engine.fix?.speed ?: 0.0) * k)}", color = speedTint(engine) ?: c.text, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(if (engine.imperial) "mph" else "km/h", color = c.sub, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ImmTurnCard(engine: NavEngine, t: com.headunit.launcher.TurnInfo) {
    val shape = RoundedCornerShape(26.dp)
    val frac = ((450.0 - t.dist) / 450.0).coerceIn(0.0, 1.0).toFloat()
    Column(Modifier.fillMaxWidth().shadow(10.dp, shape).clip(shape).background(Teal)) {
        Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(58.dp))
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                RollText(Geo.fmtDist(t.dist, engine.imperial), Color.White, 36.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (t.sign.isNotBlank() && t.sign != t.street) Text(t.sign, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 120.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1E8E55)).padding(horizontal = 7.dp, vertical = 2.dp))
                    Text(t.street, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (engine.prefs.b("lanestrip", true)) t.lanes?.let { ls ->
            Box(Modifier.fillMaxWidth().background(TealDeep).padding(vertical = 4.dp), contentAlignment = Alignment.Center) { LaneRow(ls, t.maneuver, t.dist < 400.0) }
        }
        t.laneAdvice?.let { Text(it, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().background(TealDeep).padding(horizontal = 16.dp, vertical = 6.dp)) }
        if (t.thenManeuver != null) {
            Row(Modifier.fillMaxWidth().background(TealDeep).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                ManeuverArrow(t.thenManeuver, Geo.maneuverAngle(t.thenManeuver), Modifier.size(22.dp))
                Text(t.thenText, color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color.Black.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxSize().background(Color.White.copy(alpha = 0.9f)))
        }
    }
}

@Composable
private fun ImmSearch(engine: NavEngine, q: String, onQ: (String) -> Unit, locked: Boolean, focus: FocusRequester, voice: () -> Unit) {
    val c = LocalVw.current
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().height(58.dp).shadow(8.dp, shape).clip(shape).background(c.surface)) {
        TextField(
            value = q, onValueChange = onQ, enabled = !locked,
            placeholder = { Text(if (locked) "Tap the mic to search while driving" else "Where to?", fontSize = if (locked) 15.sp else 18.sp) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = c.sub) },
            trailingIcon = {
                if (q.isNotEmpty()) Icon(Icons.Rounded.Close, "Clear", tint = c.sub, modifier = Modifier.padding(end = 8.dp).clickable { onQ(""); engine.results = emptyList() })
                else Box(Modifier.padding(end = 8.dp).size(42.dp).clip(CircleShape).background(c.accent).pressClick { voice() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Mic, "Voice search", tint = Color.White, modifier = Modifier.size(23.dp))
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { engine.search(q) }),
            shape = shape,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = c.surface, unfocusedContainerColor = c.surface, disabledContainerColor = c.surface,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent,
                focusedTextColor = c.text, unfocusedTextColor = c.text, disabledTextColor = c.sub,
                focusedPlaceholderColor = c.sub, unfocusedPlaceholderColor = c.sub, disabledPlaceholderColor = c.sub,
                cursorColor = c.accent,
            ),
            modifier = Modifier.fillMaxSize().focusRequester(focus),
        )
    }
}

@Composable
private fun ImmResults(engine: NavEngine, onPicked: () -> Unit) {
    val c = LocalVw.current
    val shape = RoundedCornerShape(26.dp)
    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp).shadow(8.dp, shape).clip(shape).background(c.surface).padding(vertical = 6.dp)) {
        items(engine.results) { p ->
            Row(Modifier.fillMaxWidth().clickable { onPicked(); engine.pickPlace(p) }.padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Place, null, tint = Color(0xFFEA4335), modifier = Modifier.size(22.dp))
                }
                Column(Modifier.padding(start = 14.dp)) {
                    Text(p.name, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(p.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun ImmChip(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    val c = LocalVw.current
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.height(46.dp).shadow(6.dp, shape).clip(shape).background(c.surface).pressClick(onClick).padding(start = 8.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)) }
        Text(label, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun ImmQuick(engine: NavEngine, focusSearch: () -> Unit) {
    val c = LocalVw.current
    val home = engine.places.slot("home")
    val work = engine.places.slot("work")
    val car = engine.places.parked()
    val favs = engine.places.favourites()
    val recents = engine.places.recents().filter { r -> favs.none { Geo.dist(it.pos, r.pos) < 60 } }
    val saved: List<Pair<com.headunit.launcher.Place, Boolean>> = favs.map { it to true } + recents.take(4).map { it to false }
    val here = engine.fix?.pos
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ImmChip(Icons.Rounded.Home, Color(0xFF4C8DFF), if (home != null) "Home" else "Set home") {
                if (home != null) engine.startRoute(home) else { engine.pendingSave = "home"; engine.toast("Search for your home address", 3500); focusSearch() }
            }
            ImmChip(Icons.Rounded.Work, Color(0xFFF29900), if (work != null) "Work" else "Set work") {
                if (work != null) engine.startRoute(work) else { engine.pendingSave = "work"; engine.toast("Search for your work address", 3500); focusSearch() }
            }
            ImmChip(Icons.Rounded.DirectionsCar, Color(0xFFA56BFF), "Car") {
                if (car != null) engine.startRoute(car) else engine.toast("No parked location saved yet. It saves itself after you park.", 3500)
            }
            ImmChip(Icons.Rounded.LocalGasStation, Color(0xFFEA4335), "Fuel") { engine.loadNearby("fuel", false) }
            ImmChip(Icons.Rounded.EvStation, Color(0xFF34A853), "EV") { engine.loadNearby("charging", false) }
            ImmChip(Icons.Rounded.LocalParking, Color(0xFF4C8DFF), "Parking") { engine.loadNearby("parking", false) }
        }
        engine.resume?.let { rp ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(TealDeep).clickable { engine.startRoute(rp) }.padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Route, null, tint = Color.White, modifier = Modifier.size(26.dp))
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    Text("Resume trip to ${rp.name}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("You hadn't arrived when the app closed", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
                Icon(Icons.Rounded.Close, "Dismiss", tint = Color.White, modifier = Modifier.padding(start = 8.dp).size(24.dp).clickable { engine.resume = null; engine.prefs.put("resume", "{}") })
            }
        }
        val suggestion = remember { engine.habits.suggest(System.currentTimeMillis()) }
        if (suggestion != null) Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Teal).clickable { engine.startRoute(suggestion) }.padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.History, null, tint = Color.White, modifier = Modifier.size(26.dp))
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text("Going to ${suggestion.name}?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (suggestion.sub.isNotBlank()) Text(suggestion.sub, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Go", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (saved.isNotEmpty()) Column(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp)).background(c.surface).padding(vertical = 8.dp)) {
            Text("Saved & recent", color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 18.dp, top = 6.dp, bottom = 4.dp))
            LazyColumn(Modifier.heightIn(max = 250.dp)) {
                items(saved) { (p, fav) ->
                    Row(Modifier.fillMaxWidth().clickable { engine.startRoute(p) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
                            Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.History, null, tint = if (fav) Warn else c.sub, modifier = Modifier.size(22.dp))
                        }
                        Column(Modifier.padding(start = 14.dp).weight(1f)) {
                            Text(p.name, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (p.sub.isNotBlank()) Text(p.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (here != null) Text(Geo.fmtDist(Geo.dist(here, p.pos), engine.imperial), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}
