package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.CalEvent
import com.headunit.launcher.CalendarData
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import com.headunit.launcher.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Home-screen card shown while no music is playing: weather, the next calendar event and trip times to saved places. */
@Composable
fun GlanceCard(engine: NavEngine, prefs: Prefs, onOpen: (Page) -> Unit, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var next by remember { mutableStateOf<CalEvent?>(null) }
    var hasCal by remember { mutableStateOf(CalendarData.has(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            hasCal = CalendarData.has(ctx)
            next = withContext(Dispatchers.IO) { CalendarData.upcoming(ctx, 2).firstOrNull() }
            delay(120_000)
        }
    }
    val imp = isImperial(prefs)
    val w = engine.weather
    Column(modifier.floating(24.dp).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onOpen(Page.Weather) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (w != null) {
                Icon(wxIcon(w.code), null, tint = wxTint(w.code), modifier = Modifier.size(46.dp))
                Column {
                    Text(if (imp) "${(w.tempC * 9 / 5 + 32).roundToInt()}°F" else "${w.tempC.roundToInt()}°C", color = c.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(Weather.text(w.code), color = c.sub, fontSize = 14.sp)
                }
            } else Text("Weather loading…", color = c.sub, fontSize = 16.sp)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line.copy(alpha = 0.6f)))
        val e = next
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onOpen(Page.Calendar) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconBadge(Icons.Rounded.Event, c.accent, Modifier, 40.dp)
            Column(Modifier.weight(1f)) {
                if (e != null) {
                    val mins = ((e.begin - System.currentTimeMillis()) / 60000).toInt()
                    Text(e.title, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        when {
                            e.allDay -> "All day"
                            mins <= 0 -> "Now"
                            mins < 60 -> "In $mins min"
                            else -> "At " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(e.begin))
                        } + (if (e.where.isNotBlank()) " · " + e.where else ""),
                        color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                } else {
                    Text(if (hasCal) "No upcoming events" else "Calendar not connected", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (hasCal) "Nothing in the next two days" else "Tap to allow access", color = c.sub, fontSize = 13.sp)
                }
            }
        }
        if (engine.quickEtas.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.line.copy(alpha = 0.6f)))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                engine.quickEtas.take(2).forEach { q ->
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(c.tile)
                            .clickable { engine.startRoute(q.place); onOpen(Page.Nav) }.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(if (q.name.contains("work", true)) Icons.Rounded.Work else Icons.Rounded.Home, null, tint = c.accent, modifier = Modifier.size(24.dp))
                        Column {
                            Text("${q.minutes} min", color = if (q.delayMin >= 5) Warn else c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(q.name, color = c.sub, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}
