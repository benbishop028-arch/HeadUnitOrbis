package com.headunit.launcher.ui

import android.annotation.SuppressLint
import android.graphics.Color as AColor
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.headunit.launcher.BuildConfig

/**
 * The navigation map: TomTom Orbis vector map rendered with MapLibre GL inside one WebView.
 * One instance is reused as the full Nav page and as the picture-in-picture window.
 */
private class WebState { var pageReady = false; var pip = false; var dark = true }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NavWeb(pip: Boolean, dark: Boolean, modifier: Modifier) {
    val state = remember { WebState() }
    state.pip = pip
    state.dark = dark

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(AColor.BLACK)
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    setGeolocationEnabled(true)
                    mediaPlaybackRequiresUserGesture = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    cacheMode = WebSettings.LOAD_DEFAULT
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?, callback: GeolocationPermissions.Callback?,
                    ) {
                        callback?.invoke(origin, true, false)
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        state.pageReady = true
                        applyState(view, state)
                    }
                }
                val html = ctx.assets.open("nav.html").bufferedReader().use { it.readText() }
                    .replace("__TT_KEY__", BuildConfig.TOMTOM_API_KEY)
                loadDataWithBaseURL("https://orbisnav.local/", html, "text/html", "utf-8", null)
            }
        },
        update = { view ->
            state.pip = pip
            state.dark = dark
            if (state.pageReady) applyState(view, state)
        },
        onRelease = { it.destroy() },
    )
}

private fun applyState(view: WebView, s: WebState) {
    view.evaluateJavascript(
        "window.__launcher&&(window.__launcher.setDark(${s.dark}),window.__launcher.setPip(${s.pip}));", null,
    )
}
