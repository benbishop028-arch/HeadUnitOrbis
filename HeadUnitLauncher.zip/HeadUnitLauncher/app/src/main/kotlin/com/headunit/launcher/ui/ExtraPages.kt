package com.headunit.launcher.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Size as GSize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.DashCam
import com.headunit.launcher.Geo
import com.headunit.launcher.IssInfo
import com.headunit.launcher.LL
import com.headunit.launcher.Landmark
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.Sky
import com.headunit.launcher.Tracks
import com.headunit.launcher.Wiki
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
private fun fieldColors() = run {
    val c = LocalVw.current
    TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
}

// ------------------------------------------------------------------ drive computer
@Composable
fun DrivePage(engine: NavEngine) {
    val c = LocalVw.current
    val f = engine.fix
    val imp = engine.imperial
    val k = if (imp) 2.23694 else 3.6
    val unit = if (imp) "mph" else "km/h"
    val spd = if (f != null) (f.speed * k).roundToInt() else 0
    val lim = engine.speedLimit?.let { (Math.round(it * k / 5.0) * 5).toInt() }
    val dirs = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    val heading = f?.heading ?: 0.0
    val dir = dirs[(((heading + 22.5) / 45.0).toInt()) % 8]
    val movingSec = engine.tripMoving
    val avg = if (movingSec > 0) engine.tripDist / movingSec * k else 0.0
    val sinceFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1.3f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                val ring = speedTint(engine) ?: c.accent
                val maxS = (lim ?: (if (imp) 100 else 160)).toFloat() * 1.25f
                val frac = (spd / maxS).coerceIn(0f, 1f)
                val track = c.line
                Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val sw = 12.dp.toPx()
                        val pad0 = sw / 2
                        val sz = GSize(size.width - sw, size.height - sw)
                        drawArc(track, 135f, 270f, false, Offset(pad0, pad0), sz, style = Stroke(sw, cap = StrokeCap.Round))
                        if (frac > 0f) drawArc(ring, 135f, 270f * frac, false, Offset(pad0, pad0), sz, style = Stroke(sw, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        RollText("$spd", speedTint(engine) ?: c.text, 84.sp, fontWeight = FontWeight.Bold)
                        Text(unit, color = c.sub, fontSize = 18.sp)
                    }
                }
                if (lim != null) Text("Limit $lim" + (if (engine.limitEstimated) " (estimated)" else ""), color = if (engine.overLimit) Bad else c.sub, fontSize = 20.sp, modifier = Modifier.padding(top = 10.dp))
                else Text("Speed limit unknown here", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                if (f == null) Text("Waiting for GPS…", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                Canvas(Modifier.size(130.dp)) {
                    val r = size.minDimension / 2
                    val ctr = Offset(size.width / 2, size.height / 2)
                    drawCircle(c.tile, r, ctr)
                    drawCircle(c.line, r, ctr, style = Stroke(2.dp.toPx()))
                    for (d in 0 until 36) {
                        val ang = Math.toRadians(d * 10.0)
                        val len = if (d % 9 == 0) 0.14f else 0.07f
                        drawLine(c.sub.copy(alpha = 0.6f), Offset(ctr.x + (r * (1f - len) * kotlin.math.sin(ang)).toFloat(), ctr.y - (r * (1f - len) * cos(ang)).toFloat()), Offset(ctr.x + (r * kotlin.math.sin(ang)).toFloat(), ctr.y - (r * cos(ang)).toFloat()), 1.5.dp.toPx())
                    }
                    val a = Math.toRadians(-heading)
                    // north marker rotates against the heading so it always points to north
                    val nx = ctr.x + (r * 0.8f * kotlin.math.sin(a)).toFloat()
                    val ny = ctr.y - (r * 0.8f * cos(a)).toFloat()
                    drawCircle(Bad, 7.dp.toPx(), Offset(nx, ny))
                    drawLine(c.accent, ctr, Offset(ctr.x, ctr.y - r * 0.6f), 5.dp.toPx(), StrokeCap.Round)
                }
                Text("${heading.roundToInt()}°  $dir", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Text("Red dot marks north", color = c.sub, fontSize = 12.sp)
            }
        }
        VCard(Modifier.weight(1.2f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionLabel("This trip")
                StatRow("Distance", Geo.fmtDist(engine.tripDist, imp))
                StatRow("Average", "${avg.roundToInt()} $unit")
                StatRow("Top speed", "${(engine.tripMax * k).roundToInt()} $unit")
                StatRow("Moving", Geo.fmtDur(movingSec))
                StatRow("Since", sinceFmt.format(Date(engine.tripStart)))
                SectionLabel("Position", Modifier.padding(top = 6.dp))
                StatRow("Altitude", if (f != null) (if (imp) "${(f.alt * 3.28084).roundToInt()} ft" else "${f.alt.roundToInt()} m") else "–")
                StatRow("GPS accuracy", if (f != null && f.acc > 0) "±" + (if (imp) "${(f.acc * 3.28084).roundToInt()} ft" else "${f.acc.roundToInt()} m") else "–")
                StatRow("Coordinates", if (f != null) String.format(Locale.US, "%.4f, %.4f", f.pos.lat, f.pos.lon) else "–")
                Box(Modifier.weight(1f))
                Pill("Reset trip", false, { engine.resetTrip() })
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    val c = LocalVw.current
    Row(Modifier.fillMaxWidth().inset(12.dp).padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ------------------------------------------------------------------ smart home buttons
@Composable
fun SmartHomePage(engine: NavEngine) {
    val c = LocalVw.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val hooks = remember(tick) { engine.hooks.all() }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val homeHook = engine.prefs.s("homehook", "-1").toIntOrNull() ?: -1
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PageTitle("Smart home", "Buttons that call a web address")
            Text("Each button calls a web address, for example a Home Assistant or IFTTT webhook. Start the address with POST to send a POST request.", color = c.sub, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextField(name, { name = it }, singleLine = true, label = { Text("Name") }, colors = fieldColors(), shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f))
                TextField(url, { url = it }, singleLine = true, label = { Text("Address (https://…)") }, colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(2.2f))
                Pill("Add", true, {
                    if (name.isNotBlank() && (url.startsWith("http", true) || url.startsWith("POST http", true))) {
                        engine.hooks.add(name.trim(), url.trim()); name = ""; url = ""; tick++
                    } else engine.toast("Enter a name and an address starting with http", 3000)
                })
            }
            if (hooks.isEmpty()) Text("No buttons yet.", color = c.sub, fontSize = 14.sp)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(hooks.size) { i ->
                    val h = hooks[i]
                    Row(Modifier.fillMaxWidth().inset(16.dp, if (homeHook == i) c.accent else null).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Rounded.Bolt, c.accent, Modifier.padding(end = 12.dp), 42.dp)
                        Column(Modifier.weight(1f)) {
                            Text(h.name, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            Text(h.url, color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Pill("Run", true, {
                            scope.launch {
                                val ok = withContext(Dispatchers.IO) { engine.hooks.fire(h) }
                                engine.toast(if (ok) "${h.name}: done" else "${h.name}: failed", 2500)
                            }
                        })
                        Icon(Icons.Rounded.Close, "Delete", tint = c.sub, modifier = Modifier.padding(start = 12.dp).size(22.dp).clickable {
                            engine.hooks.remove(i)
                            if (homeHook == i) engine.prefs.put("homehook", "-1")
                            tick++
                        })
                    }
                }
            }
            if (hooks.isNotEmpty()) {
                SectionLabel("When I arrive home, run")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("Nothing", homeHook !in hooks.indices, { engine.prefs.put("homehook", "-1") })
                    hooks.forEachIndexed { i, h -> Pill(h.name, homeHook == i, { engine.prefs.put("homehook", i.toString()) }) }
                }
                if (engine.places.slot("home") == null) Text("Set a Home address in Navigation first.", color = Warn, fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ dash cam
@Composable
fun DashCamPage() {
    val c = LocalVw.current
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { DashCam.refresh(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) DashCam.start(ctx.applicationContext) else DashCam.status = "Camera permission was denied"
    }
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PageTitle("Dash cam", "${DashCam.clips} clips saved")
            Text("Records video from the device camera in 3 minute clips and keeps the newest 10, deleting the oldest. It records while the launcher is running, without sound.", color = c.sub, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().inset(18.dp, if (DashCam.recording) Bad else null).padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                IconBadge(if (DashCam.recording) Icons.Rounded.Stop else Icons.Rounded.Videocam, if (DashCam.recording) Bad else c.sub, size = 48.dp)
                Column {
                    Text(if (DashCam.recording) "RECORDING" else "STANDBY", color = if (DashCam.recording) Bad else c.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(DashCam.status, color = c.text, fontSize = 17.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!DashCam.recording) Pill("Start recording", true, {
                    if (ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) DashCam.start(ctx.applicationContext)
                    else launcher.launch(Manifest.permission.CAMERA)
                }) else Pill("Stop recording", true, { DashCam.stop() })
                Pill("Delete all clips", false, { DashCam.deleteAll(ctx) })
            }
                        Text("Saved in: " + DashCam.dir(ctx).absolutePath, color = c.sub, fontSize = 11.sp)
            Text("Not every head unit has a usable camera. If it reports an error, this device probably can't record.", color = c.sub, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ discover: nearby places + sky
@Composable
fun MoonDisc(nowMs: Long, modifier: Modifier = Modifier, light: Color = Color(0xFFEDE8D5), dark: Color = Color(0xFF1B2230)) {
    val age = Sky.moonAge(nowMs)
    val f = (age / 29.530588853).toFloat()
    val illum = Sky.moonIllumination(nowMs)
    Canvas(modifier) {
        val r = size.minDimension / 2
        val ctr = Offset(size.width / 2, size.height / 2)
        drawCircle(dark, r, ctr)
        val waxing = f < 0.5f
        drawArc(light, if (waxing) -90f else 90f, 180f, true, Offset(ctr.x - r, ctr.y - r), Size(2 * r, 2 * r))
        val ew = abs(cos(2 * PI * f)).toFloat() * r
        if (ew > 0.5f) drawOval(if (illum > 0.5) light else dark, Offset(ctr.x - ew, ctr.y - r), Size(2 * ew, 2 * r))
    }
}

@Composable
fun DiscoverPage(engine: NavEngine, prefs: Prefs, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    var places by remember { mutableStateOf<List<Landmark>?>(null) }
    var iss by remember { mutableStateOf<IssInfo?>(null) }
    var issFailed by remember { mutableStateOf(false) }
    val fixPos = engine.fix?.pos
    val pos: LL? = fixPos ?: prefs.s("lastlat", "").toDoubleOrNull()?.let { la -> prefs.s("lastlon", "").toDoubleOrNull()?.let { lo -> LL(la, lo) } }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(fixPos != null, reload) {
        val p = engine.fix?.pos ?: pos
        if (p != null) places = withContext(Dispatchers.IO) { Wiki.nearby(p) }
    }
    LaunchedEffect(reload, pos != null) {
        while (true) {
            val p = engine.fix?.pos ?: pos
            if (p != null) {
                val r = withContext(Dispatchers.IO) { Sky.iss(p) }
                issFailed = r == null
                if (r != null) iss = r
            }
            delay(20_000)
        }
    }
    val now = System.currentTimeMillis()
    val imp = engine.imperial
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(2f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PageTitle("Discover", "Interesting places nearby", Modifier.weight(1f))
                    Pill("Refresh", false, { places = null; reload++ })
                }
                if (engine.fix == null) Text("Using your last known area. Places will be more accurate with a GPS fix.", color = c.sub, fontSize = 11.sp)
                val list = places
                when {
                    pos == null -> Text("Waiting for a position…", color = c.sub, fontSize = 14.sp)
                    list == null -> Text("Looking around…", color = c.sub, fontSize = 14.sp)
                    list.isEmpty() -> Text("Nothing found nearby, or no internet connection.", color = c.sub, fontSize = 14.sp)
                    else -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list) { l ->
                            Column(Modifier.fillMaxWidth().inset(16.dp).padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconBadge(Icons.Rounded.Place, c.accent, Modifier.padding(end = 12.dp), 40.dp)
                                    Column(Modifier.weight(1f)) {
                                        Text(l.title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(Geo.fmtDist(l.dist, imp), color = c.accent, fontSize = 12.sp)
                                    }
                                    Pill("Read", false, { engine.speakForce(l.title + ". " + l.text) })
                                    Box(Modifier.width(6.dp))
                                    Pill("Go", true, { engine.startRoute(Place(l.title, "", l.pos)); onOpen(Page.Nav) })
                                }
                                Text(l.text, color = c.sub, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("Sky", Modifier.align(Alignment.Start))
                MoonDisc(now, Modifier.size(84.dp))
                Text(Sky.moonName(now), color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("${(Sky.moonIllumination(now) * 100).roundToInt()}% lit", color = c.sub, fontSize = 13.sp)
                Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
                SectionLabel("Space station", Modifier.align(Alignment.Start))
                val i = iss
                if (i != null) {
                    val dirs = listOf("north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west")
                    val dir = dirs[(((i.bearing + 22.5) / 45.0).toInt()) % 8]
                    Text(if (imp) "${(i.groundKm * 0.621371).roundToInt()} miles away" else "${i.groundKm.roundToInt()} km away", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (i.elevation > 0) "Above your horizon, to the $dir, ${i.elevation.roundToInt()}° high" else "Below your horizon, towards the $dir",
                        color = if (i.elevation > 0) c.accent else c.sub, fontSize = 13.sp,
                    )
                    Text("Look up after dusk if it is above the horizon.", color = c.sub, fontSize = 11.sp)
                } else Text(if (issFailed) "Could not reach the tracking service." else "Locating…", color = c.sub, fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ visited map (drawn from recorded tracks)
@Composable
fun VisitedTab() {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val tracks = remember(version) { Tracks.readAll(ctx) }
    VCard(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PageTitle("Places visited", "${tracks.size} trips mapped", Modifier.weight(1f))
                if (tracks.isNotEmpty()) Pill("Clear map", false, { Tracks.clear(ctx); version++ })
            }
            if (tracks.isEmpty()) Text("Roads you drive are drawn here. Only trips from now on are recorded.", color = c.sub, fontSize = 14.sp)
            else Canvas(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.tile)) {
                var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
                tracks.forEach { t -> t.forEach { minLat = min(minLat, it.lat); maxLat = max(maxLat, it.lat); minLon = min(minLon, it.lon); maxLon = max(maxLon, it.lon) } }
                val kx = cos(Math.toRadians((minLat + maxLat) / 2))
                val w = max((maxLon - minLon) * kx, 1e-4)
                val h = max(maxLat - minLat, 1e-4)
                val pad = 18.dp.toPx()
                val sc = min((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
                val offX = (size.width - w * sc) / 2
                val offY = (size.height - h * sc) / 2
                fun pt(p: LL) = Offset((offX + (p.lon - minLon) * kx * sc).toFloat(), (size.height - offY - (p.lat - minLat) * sc).toFloat())
                tracks.forEachIndexed { idx, t ->
                    val path = Path()
                    t.forEachIndexed { i, p -> val o = pt(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                    val recent = idx >= tracks.size - 1
                    drawPath(path, c.accent.copy(alpha = if (recent) 0.95f else 0.45f), style = Stroke(if (recent) 3.dp.toPx() else 2.dp.toPx(), cap = StrokeCap.Round))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ share ETA by text message
@Composable
fun rememberPhonePicker(onPicked: (String, String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data ?: return@rememberLauncherForActivityResult
        try {
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) onPicked(it.getString(0) ?: "", it.getString(1) ?: "")
            }
        } catch (e: Exception) { }
    }
    return {
        try { pick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) } catch (e: Exception) { }
    }
}

@Composable
fun rememberEtaContactPicker(prefs: Prefs, onPicked: () -> Unit = {}): () -> Unit =
    rememberPhonePicker { num, name ->
        prefs.put("etanum", num)
        prefs.put("etaname", name)
        onPicked()
    }

@Composable
fun rememberShareEta(engine: NavEngine): () -> Unit {
    val ctx = LocalContext.current
    val prefs = engine.prefs
    fun message(): String {
        val d = engine.dest?.name ?: "my destination"
        val e = engine.eta
        val p = engine.fix?.pos
        return "I'm on my way to $d" + (if (e != null) ", arriving about ${e.arrive}" else "") +
            (if (p != null) ". Where I am now: https://maps.google.com/?q=${p.lat},${p.lon}" else ".")
    }
    fun sendNow() {
        val num = prefs.s("etanum", "")
        if (num.isBlank()) return
        val msg = message()
        try {
            val sms = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(android.telephony.SmsManager::class.java) else android.telephony.SmsManager.getDefault()
            sms.sendMultipartTextMessage(num, null, sms.divideMessage(msg), null, null)
            engine.toast("ETA sent to ${prefs.s("etaname", num)}", 3000)
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", msg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) { engine.toast("No messaging app available", 3000) }
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { sendNow() }
    val pickContact = rememberEtaContactPicker(prefs) { engine.toast("Contact saved. Tap share again to send.", 3500) }
    return {
        if (prefs.s("etanum", "").isBlank()) {
            engine.toast("Choose who to send your ETA to", 3000)
            pickContact()
        } else if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) sendNow()
        else perm.launch(Manifest.permission.SEND_SMS)
    }
}

// ------------------------------------------------------------------ screensaver for when the car is parked
@Composable
fun Screensaver(onDismiss: () -> Unit) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }
    val stars = remember { List(70) { Triple(Math.random().toFloat(), Math.random().toFloat(), 0.3f + Math.random().toFloat() * 0.7f) } }
    // the stars drift by about a pixel a second, so a once-a-second step is plenty (a 60 fps animation here only wastes battery and GPU)
    var t by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { val t0 = android.os.SystemClock.elapsedRealtime(); while (true) { t = ((android.os.SystemClock.elapsedRealtime() - t0) / 240_000f) % 1f; delay(1000) } }
    val clock = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now)) }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (x, y, b) ->
                val yy = ((y + t * b * 0.25f) % 1f) * size.height
                drawCircle(Color.White.copy(alpha = 0.25f + 0.5f * b), (0.6f + 1.4f * b).dp.toPx(), Offset(x * size.width, yy))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(clock, color = Color.White.copy(alpha = 0.88f), fontSize = 120.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = 4.sp)
            Text(date, color = Color.White.copy(alpha = 0.55f), fontSize = 20.sp)
            Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MoonDisc(now, Modifier.size(34.dp))
                Text(Sky.moonName(now), color = Color.White.copy(alpha = 0.55f), fontSize = 16.sp)
            }
        }
    }
}
