package com.headunit.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Its existence lets the user grant "notification access", which unlocks reading media sessions.
 * It also reads new chat messages aloud when that option is switched on in Settings.
 */
class MediaListener : NotificationListenerService() {
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var lastSpoken = ""

    override fun onCreate() {
        super.onCreate()
        tts = android.speech.tts.TextToSpeech(applicationContext) { st ->
            if (st == android.speech.tts.TextToSpeech.SUCCESS) { ttsReady = true; tts?.language = java.util.Locale.getDefault() }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification?) {
        try {
            if (sbn == null || !ttsReady) return
            val sp = applicationContext.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
            if (sp.getString("readmsgs", "false") != "true") return
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if (n.category != android.app.Notification.CATEGORY_MESSAGE) return
            if ((n.flags and android.app.Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val who = ex.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = ex.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (text.isBlank()) return
            val line = "Message from $who. ${text.take(220)}"
            if (line == lastSpoken) return
            lastSpoken = line
            tts?.speak(line, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "msg")
        } catch (e: Exception) { /* never crash the listener */ }
    }
}

class AppEntry(val label: String, val pkg: String, val icon: ImageBitmap)

class AppsRepo(private val ctx: Context) {
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    suspend fun refresh() {
        val list = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .map {
                    val icon = try { it.loadIcon(pm).toBitmap(96, 96, Bitmap.Config.ARGB_8888).asImageBitmap() }
                    catch (e: Exception) { Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888).asImageBitmap() }
                    AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, icon)
                }
                .sortedBy { it.label.lowercase() }
        }
        apps = list
    }

    fun find(pkg: String) = apps.firstOrNull { it.pkg == pkg }

    /** Android Auto / CarPlay-style projection apps first. */
    fun projectionApps(): List<AppEntry> = apps.filter {
        it.pkg == "com.google.android.projection.gearhead" ||
            it.label.contains("carplay", true) || it.label.contains("android auto", true) ||
            it.label.contains("carlink", true) || it.label.contains("zlink", true) || it.label.contains("carbit", true)
    }

    fun musicApps(): List<AppEntry> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
        val pk = pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName }.toSet()
        return apps.filter { it.pkg in pk }
    }
}

object Launch {
    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
            if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI)
    }

    /** Launch an app; with [bounds] we ask the system for a window of that size (works only where freeform / multi-window is enabled). */
    fun app(ctx: Context, pkg: String, bounds: Rect? = null): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (bounds != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                val o = ActivityOptions.makeBasic()
                o.setLaunchBounds(bounds)
                ctx.startActivity(intent, o.toBundle())
            } else ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            try { ctx.startActivity(intent); true } catch (e2: Exception) { false }
        }
    }

    fun settings(ctx: Context, action: String): Boolean = try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e2: Exception) { false }
    }

    fun view(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }
}

class MediaInfo(
    val title: String, val artist: String, val art: ImageBitmap?, val playing: Boolean,
    val pos: Long, val dur: Long, val app: String, val controller: MediaController,
)

object MediaHelper {
    fun hasAccess(ctx: Context): Boolean = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun openAccess(ctx: Context) {
        Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    }

    fun current(ctx: Context): MediaInfo? {
        if (!hasAccess(ctx)) return null
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list.firstOrNull { it.metadata != null } ?: list.firstOrNull() ?: return null
            val md = c.metadata
            val ps = c.playbackState
            val art = (md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON))?.asImageBitmap()
            val playing = ps?.state == PlaybackState.STATE_PLAYING
            var pos = ps?.position ?: 0L
            if (playing && ps != null && ps.position >= 0) {
                pos += ((android.os.SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
            }
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)?.takeIf { it.isNotBlank() }
                ?: "Nothing playing"
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            MediaInfo(title, artist, art, playing, pos, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L, c.packageName, c)
        } catch (e: Exception) { null }
    }
}
