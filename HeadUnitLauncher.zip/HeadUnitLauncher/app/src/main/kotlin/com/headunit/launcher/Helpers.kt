package com.headunit.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Its existence lets the user grant "notification access", which unlocks reading media sessions.
 * It also reads new chat messages aloud when that option is switched on in Settings.
 */
class MediaListener : NotificationListenerService() {
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var lastSpoken = ""

    companion object {
        /** The connected listener, used to read media notifications when an app (like a head unit's Bluetooth player) shows no media session. */
        @Volatile var instance: MediaListener? = null
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    /** Media-style notifications currently showing (title, text, artwork, buttons). */
    fun mediaNotes(): List<MediaNote> = try {
        activeNotifications.orEmpty().filter { sbn ->
            val n = sbn.notification
            sbn.packageName != packageName && n != null &&
                (n.category == android.app.Notification.CATEGORY_TRANSPORT || n.extras?.containsKey(android.app.Notification.EXTRA_MEDIA_SESSION) == true)
        }.map { sbn ->
            val n = sbn.notification
            val ex = n.extras
            val art = try { (n.getLargeIcon()?.loadDrawable(applicationContext) as? android.graphics.drawable.BitmapDrawable)?.bitmap } catch (e: Exception) { null }
            MediaNote(
                sbn.packageName,
                ex?.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty(),
                ex?.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty(),
                art,
                n.actions.orEmpty().mapNotNull { a -> a.actionIntent?.let { pi -> Pair(a.title?.toString().orEmpty(), pi) } },
            )
        }
    } catch (e: Exception) { emptyList() }

    override fun onCreate() {
        super.onCreate()
        tts = android.speech.tts.TextToSpeech(applicationContext) { st ->
            if (st == android.speech.tts.TextToSpeech.SUCCESS) { ttsReady = true; tts?.language = java.util.Locale.getDefault() }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification?) {
        try {
            if (sbn == null || !ttsReady) return
            val sp = applicationContext.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
            if (sp.getString("readmsgs", "false") != "true") return
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if (n.category != android.app.Notification.CATEGORY_MESSAGE) return
            if ((n.flags and android.app.Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val who = ex.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = ex.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
            if (text.isBlank()) return
            val line = "Message from $who. ${text.take(220)}"
            if (line == lastSpoken) return
            lastSpoken = line
            tts?.speak(line, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "msg")
        } catch (e: Exception) { /* never crash the listener */ }
    }
}

class AppEntry(val label: String, val pkg: String, val icon: ImageBitmap)

class AppsRepo(private val ctx: Context) {
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    suspend fun refresh() {
        val list = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            // normal launcher apps plus TV and car launcher entries, which head units often use
            val cats = listOf(Intent.CATEGORY_LAUNCHER, "android.intent.category.LEANBACK_LAUNCHER", "android.intent.category.CAR_LAUNCHER")
            cats.flatMap { cat -> try { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0) } catch (e: Exception) { emptyList() } }
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .map {
                    val icon = try { it.loadIcon(pm).toBitmap(96, 96, Bitmap.Config.ARGB_8888).asImageBitmap() }
                    catch (e: Exception) { Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888).asImageBitmap() }
                    AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, icon)
                }
                .sortedBy { it.label.lowercase() }
        }
        apps = list
    }

    fun find(pkg: String) = apps.firstOrNull { it.pkg == pkg }

    /** Android Auto / CarPlay-style projection apps first. */
    fun projectionApps(): List<AppEntry> = apps.filter {
        it.pkg == "com.google.android.projection.gearhead" ||
            it.label.contains("carplay", true) || it.label.contains("android auto", true) ||
            it.label.contains("carlink", true) || it.label.contains("zlink", true) || it.label.contains("carbit", true)
    }

    fun musicApps(): List<AppEntry> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
        val pk = pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName }.toSet()
        return apps.filter { it.pkg in pk }
    }
}

object Launch {
    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
            if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI)
    }

    /** Launch an app; with [bounds] we ask the system for a window of that size (works only where freeform / multi-window is enabled). */
    fun app(ctx: Context, pkg: String, bounds: Rect? = null): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ok = try {
            if (bounds != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                val o = ActivityOptions.makeBasic()
                o.setLaunchBounds(bounds)
                ctx.startActivity(intent, o.toBundle())
            } else ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            try { ctx.startActivity(intent); true } catch (e2: Exception) { false }
        }
        if (ok) record(ctx, pkg)
        return ok
    }

    /** Apps opened through this launcher, newest first (Android does not let a normal app read the system's own recents list). */
    fun recent(ctx: Context): List<String> =
        ctx.getSharedPreferences("recent_apps", 0).getString("l", "").orEmpty().split(",").filter { it.isNotBlank() }

    private fun record(ctx: Context, pkg: String) {
        if (pkg == ctx.packageName) return
        val l = (listOf(pkg) + recent(ctx).filter { it != pkg }).take(10)
        ctx.getSharedPreferences("recent_apps", 0).edit().putString("l", l.joinToString(",")).apply()
    }

    fun settings(ctx: Context, action: String): Boolean = try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e2: Exception) { false }
    }

    fun view(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }
}

/**
 * What is playing. [controller] is null when audio is playing but no app published a media session
 * (some head units' own Bluetooth player does this); the buttons then send media keys instead.
 */
class MediaNote(val pkg: String, val title: String, val text: String, val art: Bitmap?, val actions: List<Pair<String, android.app.PendingIntent>>)

class MediaInfo(
    val title: String, val artist: String, val art: ImageBitmap?, val playing: Boolean,
    val pos: Long, val dur: Long, val app: String, val controller: MediaController?, private val ctx: Context? = null,
    /** Buttons from the player's notification, used when there is no media session to control. */
    private val acts: List<Pair<String, android.app.PendingIntent>> = emptyList(),
) {
    private fun act(vararg words: String): Boolean {
        val a = acts.firstOrNull { (t, _) -> words.any { t.contains(it, true) } } ?: return false
        return try { a.second.send(); true } catch (e: Exception) { false }
    }
    private fun key(code: Int) {
        val am = ctx?.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
        try {
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
        } catch (e: Exception) { }
    }
    fun previous() { val c = controller; if (c != null) c.transportControls.skipToPrevious() else if (!act("prev", "back")) key(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
    fun next() { val c = controller; if (c != null) c.transportControls.skipToNext() else if (!act("next", "skip", "forward")) key(android.view.KeyEvent.KEYCODE_MEDIA_NEXT) }
    fun toggle() {
        val c = controller
        if (c != null) { if (playing) c.transportControls.pause() else c.transportControls.play() }
        else if (!act("pause", "play")) key(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }
    fun seek(ms: Long) { controller?.transportControls?.seekTo(ms) }
}

class MediaSource(val pkg: String, val label: String, val playing: Boolean, val bluetooth: Boolean)

object MediaHelper {
    /** Package of the session the user picked on the Sources tab. Empty means automatic (whatever is playing). */
    @Volatile var preferred: String = ""

    /** True for the head unit's Bluetooth audio session (a phone connected over Bluetooth). */
    fun isBluetooth(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("bluetooth") || p.contains("a2dp") || p.contains("avrcp") || p.contains("btmusic") || p.contains(".bt") || p.contains("blue")
    }

    fun sources(ctx: Context): List<MediaSource> {
        if (!hasAccess(ctx)) return emptyList()
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java)).map {
                val bt = isBluetooth(it.packageName)
                val label = if (bt) "Bluetooth audio" else try {
                    ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(it.packageName, 0)).toString()
                } catch (e: Exception) { it.packageName }
                MediaSource(it.packageName, label, it.playbackState?.state == PlaybackState.STATE_PLAYING, bt)
            }
        } catch (e: Exception) { emptyList() }
    }

    fun hasAccess(ctx: Context): Boolean = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun openAccess(ctx: Context) {
        Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    }

    /** Audio is coming out but no app published a session: show a generic player driven by media keys. */
    private fun fallback(ctx: Context): MediaInfo? = try {
        val note = MediaListener.instance?.mediaNotes()?.firstOrNull { it.title.isNotBlank() }
        if (note != null) {
            val playing = note.actions.any { it.first.contains("pause", true) }
            MediaInfo(note.title, note.text, note.art?.asImageBitmap(), playing, 0L, 0L, note.pkg, null, ctx, note.actions)
        } else {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            if (am.isMusicActive) MediaInfo("Audio playing", "No track info from this source", null, true, 0L, 0L, EXTERNAL, null, ctx) else null
        }
    } catch (e: Exception) { null }

    /** Plain-text report of everything the launcher can see about media, for working out why a source does not show. */
    fun diagnostics(ctx: Context): String {
        val sb = StringBuilder()
        sb.appendLine("Notification access: " + if (hasAccess(ctx)) "granted" else "NOT granted")
        sb.appendLine("Listener connected: " + if (MediaListener.instance != null) "yes" else "no")
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            sb.appendLine("Audio playing (music stream): " + am.isMusicActive)
        } catch (e: Exception) { }
        try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            sb.appendLine("Media sessions: ${list.size}")
            list.forEach {
                val st = when (it.playbackState?.state) { PlaybackState.STATE_PLAYING -> "playing"; PlaybackState.STATE_PAUSED -> "paused"; null -> "no state"; else -> "state ${it.playbackState?.state}" }
                sb.appendLine("  ${it.packageName}: $st, ${it.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "no title"}")
            }
        } catch (e: Exception) { sb.appendLine("Media sessions: unavailable (${e.javaClass.simpleName})") }
        val notes = MediaListener.instance?.mediaNotes().orEmpty()
        sb.appendLine("Media notifications: ${notes.size}")
        notes.forEach { sb.appendLine("  ${it.pkg}: ${it.title} / ${it.text} [${it.actions.joinToString { a -> a.first }}]") }
        try {
            val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
            sb.appendLine("Bluetooth: " + if (bt == null) "no adapter" else if (bt.isEnabled) "on" else "off")
            if (bt != null && bt.isEnabled) {
                fun st(n: Int) = when (n) { android.bluetooth.BluetoothProfile.STATE_CONNECTED -> "connected"; android.bluetooth.BluetoothProfile.STATE_DISCONNECTED -> "not connected"; else -> "state $n" }
                try { sb.appendLine("  Audio source profile (phone sends music): " + st(bt.getProfileConnectionState(android.bluetooth.BluetoothProfile.A2DP))) } catch (e: SecurityException) { sb.appendLine("  Bluetooth profile state needs the Nearby devices permission") }
                try { sb.appendLine("  Hands-free profile: " + st(bt.getProfileConnectionState(android.bluetooth.BluetoothProfile.HEADSET))) } catch (e: SecurityException) { }
                // a head unit receives music, so the relevant profile is the hidden "A2DP sink" (11), not the normal A2DP above
                try { sb.appendLine("  Audio sink profile (head unit receives music): " + st(bt.getProfileConnectionState(11))) } catch (e: Exception) { sb.appendLine("  Audio sink profile: not readable") }
                try { sb.appendLine("  Remote control profile (AVRCP controller): " + st(bt.getProfileConnectionState(12))) } catch (e: Exception) { }
                try {
                    val paired = bt.bondedDevices.map { it.name ?: it.address }
                    sb.appendLine("  Paired devices: " + if (paired.isEmpty()) "none" else paired.joinToString(", "))
                } catch (e: Exception) { sb.appendLine("  Paired devices: not readable (${e.javaClass.simpleName})") }
            }
        } catch (e: Exception) { }
        // apps that offer a media browser (a Bluetooth music app on the head unit usually does)
        try {
            val pm = ctx.packageManager
            val svc = pm.queryIntentServices(android.content.Intent("android.media.browse.MediaBrowserService"), 0).map { it.serviceInfo.packageName }.distinct().filter { it != ctx.packageName }
            sb.appendLine("Apps with a media browser: ${svc.size}")
            svc.forEach { sb.appendLine("  $it") }
        } catch (e: Exception) { }
        // the head unit's own Bluetooth / phone / music apps: tells us which package to look for
        try {
            val pm = ctx.packageManager
            val words = listOf("blue", "bt", "a2dp", "avrcp", "phone", "music", "dudu", "carplay", "link", "radio", "media")
            val hits = pm.getInstalledApplications(0).filter { ai ->
                val label = pm.getApplicationLabel(ai).toString().lowercase()
                val p = ai.packageName.lowercase()
                words.any { w -> p.contains(w) || label.contains(w) } && !p.startsWith("com.google.") && p != ctx.packageName
            }.sortedBy { it.packageName }.take(40)
            sb.appendLine("Installed audio / Bluetooth related apps: ${hits.size}")
            hits.forEach { sb.appendLine("  ${it.packageName} (${pm.getApplicationLabel(it)})") }
        } catch (e: Exception) { }
        return sb.toString().trim()
    }

    const val EXTERNAL = "audio.external"

    private var cachedArtKey = ""
    private var cachedArt: ImageBitmap? = null

    fun current(ctx: Context): MediaInfo? {
        if (!hasAccess(ctx)) return null
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            val pick = if (preferred.isNotEmpty()) list.firstOrNull { it.packageName == preferred } else null
            val c = pick ?: list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list.firstOrNull { it.metadata != null } ?: list.firstOrNull() ?: return fallback(ctx)
            val md = c.metadata
            val ps = c.playbackState
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            // the same picture keeps the same object, so colour extraction and fades are not redone every second
            val artKey = c.packageName + "|" + (md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" + (md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "") + "|" + (bmp?.width ?: 0) + "x" + (bmp?.height ?: 0)
            val art = if (bmp == null) null else if (artKey == cachedArtKey && cachedArt != null) cachedArt else bmp.asImageBitmap().also { cachedArt = it; cachedArtKey = artKey }
            val playing = ps?.state == PlaybackState.STATE_PLAYING
            var pos = ps?.position ?: 0L
            if (playing && ps != null && ps.position >= 0) {
                pos += ((android.os.SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
            }
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)?.takeIf { it.isNotBlank() }
                ?: "Nothing playing"
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)?.takeIf { it.isNotBlank() }
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            MediaInfo(title, artist, art, playing, pos, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L, c.packageName, c, ctx)
        } catch (e: Exception) { null }
    }
}
