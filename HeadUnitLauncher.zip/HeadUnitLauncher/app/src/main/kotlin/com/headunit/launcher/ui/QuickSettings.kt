package com.headunit.launcher.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothConnected
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.SettingsBrightness
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.SettingsInputAntenna
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Launch
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private fun netState(ctx: Context): Int = try {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    when {
        caps == null -> 0
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
        else -> 2
    }
} catch (e: Exception) { 0 }

/** 0 = off, 1 = on, 2 = an audio or hands-free device is connected. */
private fun btState(ctx: Context): Int = try {
    val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
    if (ad == null || !ad.isEnabled) 0 else try {
        val on = ad.getProfileConnectionState(android.bluetooth.BluetoothProfile.A2DP) == android.bluetooth.BluetoothProfile.STATE_CONNECTED ||
            ad.getProfileConnectionState(android.bluetooth.BluetoothProfile.HEADSET) == android.bluetooth.BluetoothProfile.STATE_CONNECTED
        if (on) 2 else 1
    } catch (e: SecurityException) { 1 }
} catch (e: Exception) { 0 }

private fun netLabel(n: Int) = when (n) { 1 -> "Wi-Fi"; 2 -> "Mobile data"; else -> "Offline" }
private fun btLabel(n: Int) = when (n) { 2 -> "Connected"; 1 -> "On"; else -> "Off" }

/** Small network and Bluetooth indicators for the top bar. */
@Composable
fun StatusIcons() {
    val ctx = LocalContext.current
    val c = LocalVw.current
    var net by remember { mutableIntStateOf(0) }
    var bt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { net = netState(ctx); bt = btState(ctx); delay(5000) } }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(when (net) { 1 -> Icons.Rounded.Wifi; 2 -> Icons.Rounded.SignalCellularAlt; else -> Icons.Rounded.WifiOff }, netLabel(net), tint = if (net == 0) Warn else c.onBg, modifier = Modifier.size(18.dp))
        if (bt > 0) Icon(if (bt == 2) Icons.Rounded.BluetoothConnected else Icons.Rounded.Bluetooth, "Bluetooth " + btLabel(bt), tint = if (bt == 2) c.accent else c.onBgSub, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun QTile(icon: ImageVector, label: String, sub: String, modifier: Modifier = Modifier, tint: Color? = null, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(c.tile).pressClick(onClick).padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Icon(icon, null, tint = tint ?: c.accent, modifier = Modifier.size(28.dp))
        Text(label, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(sub, color = c.sub, fontSize = 11.sp, maxLines = 1)
    }
}

/** Pull-down panel from the top-right corner: volume, brightness, connectivity shortcuts, voice assistant and the valet lock. */
@Composable
fun QuickSettings(prefs: Prefs, onClose: () -> Unit, onLock: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var bright by remember { mutableStateOf(prefs.i("bright", 100).toFloat()) }
    var net by remember { mutableIntStateOf(netState(ctx)) }
    var bt by remember { mutableIntStateOf(btState(ctx)) }
    LaunchedEffect(Unit) { while (true) { net = netState(ctx); bt = btState(ctx); delay(2000) } }
    val hasPin = prefs.s("pin", "").length >= 4
    val noRipple = remember { MutableInteractionSource() }

    Box(Modifier.fillMaxSize().clickable(interactionSource = noRipple, indication = null) { onClose() }) {
        Column(
            Modifier.align(Alignment.TopEnd).padding(top = 62.dp, end = 14.dp).widthIn(max = 470.dp).fillMaxWidth(0.46f)
                .shadow(18.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp)).background(c.surface)
                .border(1.dp, c.line.copy(alpha = 0.6f), RoundedCornerShape(28.dp))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Tune, null, tint = c.accent, modifier = Modifier.size(24.dp))
                Text("Quick settings", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp).weight(1f))
                Icon(Icons.Rounded.Close, "Close", tint = c.sub, modifier = Modifier.size(28.dp).clickable { onClose() })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (vol <= 0f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null, tint = c.text, modifier = Modifier.size(28.dp).clickable {
                    vol = if (vol <= 0f) (maxVol / 2f) else 0f
                    try { am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.roundToInt(), 0) } catch (e: Exception) { }
                })
                Slider(
                    value = vol, valueRange = 0f..maxVol.toFloat(),
                    onValueChange = { vol = it; try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0) } catch (e: Exception) { } },
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("${(vol / maxVol * 100).roundToInt()}%", color = c.sub, fontSize = 14.sp, modifier = Modifier.width(46.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.SettingsBrightness, null, tint = c.text, modifier = Modifier.size(28.dp))
                Slider(
                    value = bright, valueRange = 10f..100f,
                    onValueChange = { bright = it; prefs.put("bright", it.roundToInt()) },
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("${bright.roundToInt()}%", color = c.sub, fontSize = 14.sp, modifier = Modifier.width(46.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QTile(if (net == 0) Icons.Rounded.WifiOff else Icons.Rounded.Wifi, "Wi-Fi", netLabel(net), Modifier.weight(1f), if (net == 0) Warn else null) { Launch.settings(ctx, Settings.ACTION_WIFI_SETTINGS) }
                QTile(if (bt == 2) Icons.Rounded.BluetoothConnected else Icons.Rounded.Bluetooth, "Bluetooth", btLabel(bt), Modifier.weight(1f), if (bt == 0) c.sub else null) { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }
                QTile(Icons.Rounded.SettingsInputAntenna, "Hotspot", "Network settings", Modifier.weight(1f)) { Launch.settings(ctx, Settings.ACTION_WIRELESS_SETTINGS) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QTile(Icons.Rounded.Mic, "Assistant", "Voice command", Modifier.weight(1f)) {
                    onClose()
                    if (!Launch.view(ctx, Intent(Intent.ACTION_VOICE_COMMAND))) Launch.view(ctx, Intent(Intent.ACTION_ASSIST))
                }
                QTile(Icons.Rounded.SettingsBrightness, "Display", "System", Modifier.weight(1f)) { Launch.settings(ctx, Settings.ACTION_DISPLAY_SETTINGS) }
                QTile(Icons.Rounded.Lock, "Valet lock", if (hasPin) "Lock screen" else "Set PIN in Settings", Modifier.weight(1f), if (hasPin) null else c.sub) { if (hasPin) onLock() }
            }
        }
    }
}

/** Full-screen PIN lock (valet mode). It lives in memory only, so restarting the app always clears it. */
@Composable
fun LockScreen(prefs: Prefs, onUnlock: () -> Unit) {
    val c = LocalVw.current
    val pin = prefs.s("pin", "")
    var typed by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    LaunchedEffect(typed) {
        if (typed.length >= pin.length && pin.isNotEmpty()) {
            if (typed == pin) onUnlock() else { wrong = true; delay(700); typed = ""; wrong = false }
        }
    }
    Box(Modifier.fillMaxSize().background(c.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }, contentAlignment = Alignment.Center) {
        Row(horizontalArrangement = Arrangement.spacedBy(64.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Lock, null, tint = c.accent, modifier = Modifier.size(44.dp))
                Text(SimpleDateFormat(if (prefs.b("clock24", true)) "H:mm" else "h:mm", Locale.getDefault()).format(now), color = c.text, fontSize = 72.sp, fontWeight = FontWeight.Light)
                Text(if (wrong) "Wrong PIN" else "Enter PIN to unlock", color = if (wrong) Bad else c.sub, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 10.dp)) {
                    for (i in 0 until pin.length.coerceAtLeast(4)) {
                        Box(Modifier.size(16.dp).clip(CircleShape).background(if (wrong) Bad else if (i < typed.length) c.accent else c.line))
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<"))
                rows.forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        r.forEach { k ->
                            if (k.isEmpty()) Box(Modifier.size(84.dp))
                            else Box(
                                Modifier.size(84.dp).clip(CircleShape).background(c.tile).pressClick {
                                    if (k == "<") typed = typed.dropLast(1) else if (typed.length < 8 && !wrong) typed += k
                                },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (k == "<") Icon(Icons.Rounded.Backspace, "Delete", tint = c.text, modifier = Modifier.size(28.dp))
                                else Text(k, color = c.text, fontSize = 30.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }
    }
}
