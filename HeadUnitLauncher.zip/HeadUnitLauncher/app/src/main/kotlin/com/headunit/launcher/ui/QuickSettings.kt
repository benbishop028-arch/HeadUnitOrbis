package com.headunit.launcher.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.SliderDefaults
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothConnected
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.SettingsBrightness
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.SettingsInputAntenna
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Launch
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private fun netState(ctx: Context): Int = try {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    when {
        caps == null -> 0
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
        else -> 2
    }
} catch (e: Exception) { 0 }

/** 0 = off, 1 = on, 2 = an audio or hands-free device is connected. */
private fun btState(ctx: Context): Int = try {
    val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
    if (ad == null || !ad.isEnabled) 0 else try {
        val on = ad.getProfileConnectionState(android.bluetooth.BluetoothProfile.A2DP) == android.bluetooth.BluetoothProfile.STATE_CONNECTED ||
            ad.getProfileConnectionState(android.bluetooth.BluetoothProfile.HEADSET) == android.bluetooth.BluetoothProfile.STATE_CONNECTED
        if (on) 2 else 1
    } catch (e: SecurityException) { 1 }
} catch (e: Exception) { 0 }

private fun netLabel(n: Int) = when (n) { 1 -> "Wi-Fi"; 2 -> "Mobile data"; else -> "Offline" }
private fun btLabel(n: Int) = when (n) { 2 -> "Connected"; 1 -> "On"; else -> "Off" }

/** Small network and Bluetooth indicators for the top bar. */
@Composable
fun StatusIcons() {
    val ctx = LocalContext.current
    val c = LocalVw.current
    var net by remember { mutableIntStateOf(0) }
    var bt by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { net = netState(ctx); bt = btState(ctx); delay(5000) } }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(when (net) { 1 -> Icons.Rounded.Wifi; 2 -> Icons.Rounded.SignalCellularAlt; else -> Icons.Rounded.WifiOff }, netLabel(net), tint = if (net == 0) Warn else c.onBg, modifier = Modifier.size(18.dp))
        if (bt > 0) Icon(if (bt == 2) Icons.Rounded.BluetoothConnected else Icons.Rounded.Bluetooth, "Bluetooth " + btLabel(bt), tint = if (bt == 2) c.accent else c.onBgSub, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun QTile(icon: ImageVector, label: String, sub: String, modifier: Modifier = Modifier, active: Boolean = true, onClick: () -> Unit) {
    val c = LocalVw.current
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(if (active) c.accent.copy(alpha = 0.12f) else c.tile).pressClick(onClick).padding(horizontal = 6.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(if (active) c.accent.copy(alpha = 0.2f) else c.line.copy(alpha = 0.35f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (active) c.accent else c.sub, modifier = Modifier.size(22.dp))
        }
        Text(label, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(sub, color = c.sub, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QSlider(icon: ImageVector, value: Float, range: ClosedFloatingPointRange<Float>, label: String, onIcon: () -> Unit, onChange: (Float) -> Unit) {
    val c = LocalVw.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.tile).padding(start = 12.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = c.accent, modifier = Modifier.size(24.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onIcon() })
        Slider(
            value = value, valueRange = range, onValueChange = onChange,
            colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.line),
            modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
        )
        Text(label, color = c.sub, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.width(36.dp))
    }
}

/**
 * The quick settings content: volume, brightness, then a grid of shortcuts. It is placed by whoever shows it (docked where the music widget sits on the
 * home screen, or as a popup elsewhere) and calls [onClose] by itself a few seconds after the last touch.
 */
@Composable
fun QuickPanel(prefs: Prefs, modifier: Modifier, onClose: () -> Unit, onLock: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var bright by remember { mutableStateOf(prefs.i("bright", 100).toFloat()) }
    var net by remember { mutableIntStateOf(netState(ctx)) }
    var bt by remember { mutableIntStateOf(btState(ctx)) }
    LaunchedEffect(Unit) { while (true) { net = netState(ctx); bt = btState(ctx); delay(2000) } }
    val hasPin = prefs.s("pin", "").length >= 4
    val stamp = remember { longArrayOf(android.os.SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            if (android.os.SystemClock.elapsedRealtime() - stamp[0] > 7000L) { onClose(); break }
        }
    }
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.shadow(14.dp, shape).clip(shape).background(c.surface).border(1.dp, c.line.copy(alpha = 0.5f), shape)
            .pointerInput(Unit) {
                awaitPointerEventScope { while (true) { awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial); stamp[0] = android.os.SystemClock.elapsedRealtime() } }
            }
            .verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp)) {
            Text("Quick settings", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(32.dp).clip(CircleShape).background(c.tile).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, "Close", tint = c.sub, modifier = Modifier.size(18.dp))
            }
        }
        QSlider(
            if (vol <= 0f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, vol, 0f..maxVol.toFloat(), "${(vol / maxVol * 100).roundToInt()}%",
            onIcon = { vol = if (vol <= 0f) (maxVol / 2f) else 0f; try { am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.roundToInt(), 0) } catch (e: Exception) { } },
        ) { vol = it; try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0) } catch (e: Exception) { } }
        QSlider(Icons.Rounded.SettingsBrightness, bright, 10f..100f, "${bright.roundToInt()}%", onIcon = { }) { bright = it; prefs.put("bright", it.roundToInt()) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QTile(if (net == 0) Icons.Rounded.WifiOff else Icons.Rounded.Wifi, "Wi-Fi", netLabel(net), Modifier.weight(1f), net > 0) { Launch.settings(ctx, Settings.ACTION_WIFI_SETTINGS) }
            QTile(if (bt == 2) Icons.Rounded.BluetoothConnected else Icons.Rounded.Bluetooth, "Bluetooth", btLabel(bt), Modifier.weight(1f), bt > 0) { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }
            QTile(Icons.Rounded.SettingsInputAntenna, "Hotspot", "Network", Modifier.weight(1f), false) { Launch.settings(ctx, Settings.ACTION_WIRELESS_SETTINGS) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QTile(Icons.Rounded.Mic, "Assistant", "Voice", Modifier.weight(1f), false) {
                onClose()
                if (!Launch.view(ctx, Intent(Intent.ACTION_VOICE_COMMAND))) Launch.view(ctx, Intent(Intent.ACTION_ASSIST))
            }
            QTile(Icons.Rounded.SettingsBrightness, "Display", "System", Modifier.weight(1f), false) { Launch.settings(ctx, Settings.ACTION_DISPLAY_SETTINGS) }
            QTile(Icons.Rounded.Lock, "Valet lock", if (hasPin) "Lock" else "Set PIN", Modifier.weight(1f), hasPin) { if (hasPin) onLock() }
        }
    }
}

/** Full-screen PIN lock (valet mode). It lives in memory only, so restarting the app always clears it. */
@Composable
fun LockScreen(prefs: Prefs, onUnlock: () -> Unit) {
    val c = LocalVw.current
    val pin = prefs.s("pin", "")
    var typed by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    LaunchedEffect(typed) {
        if (typed.length >= pin.length && pin.isNotEmpty()) {
            if (typed == pin) onUnlock() else { wrong = true; delay(700); typed = ""; wrong = false }
        }
    }
    Box(Modifier.fillMaxSize().background(c.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }, contentAlignment = Alignment.Center) {
        Row(horizontalArrangement = Arrangement.spacedBy(64.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Lock, null, tint = c.accent, modifier = Modifier.size(44.dp))
                Text(SimpleDateFormat(if (prefs.b("clock24", true)) "H:mm" else "h:mm", Locale.getDefault()).format(now), color = c.text, fontSize = 72.sp, fontWeight = FontWeight.Light)
                Text(if (wrong) "Wrong PIN" else "Enter PIN to unlock", color = if (wrong) Bad else c.sub, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 10.dp)) {
                    for (i in 0 until pin.length.coerceAtLeast(4)) {
                        Box(Modifier.size(16.dp).clip(CircleShape).background(if (wrong) Bad else if (i < typed.length) c.accent else c.line))
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<"))
                rows.forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        r.forEach { k ->
                            if (k.isEmpty()) Box(Modifier.size(84.dp))
                            else Box(
                                Modifier.size(84.dp).clip(CircleShape).background(c.tile).pressClick {
                                    if (k == "<") typed = typed.dropLast(1) else if (typed.length < 8 && !wrong) typed += k
                                },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (k == "<") Icon(Icons.Rounded.Backspace, "Delete", tint = c.text, modifier = Modifier.size(28.dp))
                                else Text(k, color = c.text, fontSize = 30.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }
    }
}
