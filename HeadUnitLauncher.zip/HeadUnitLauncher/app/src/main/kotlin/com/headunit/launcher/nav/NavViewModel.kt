package com.headunit.launcher.nav

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.headunit.launcher.BuildConfig
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.init.buildSdkConfiguration            // SDK-CHECK import
import com.tomtom.sdk.init.createRoutePlanner
import com.tomtom.sdk.init.createSearch
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.location.OnLocationUpdateListener
import com.tomtom.sdk.navigation.NavigationOptions
import com.tomtom.sdk.navigation.ProgressUpdatedListener
import com.tomtom.sdk.navigation.RoutePlan                   // SDK-CHECK import
import com.tomtom.sdk.routing.RoutePlanner
import com.tomtom.sdk.routing.RoutePlanningCallback
import com.tomtom.sdk.routing.RoutePlanningResponse
import com.tomtom.sdk.routing.RoutingFailure
import com.tomtom.sdk.routing.options.Itinerary
import com.tomtom.sdk.routing.options.RoutePlanningOptions
import com.tomtom.sdk.routing.options.guidance.GuidanceOptions // SDK-CHECK import
import com.tomtom.sdk.routing.route.Route
import com.tomtom.sdk.search.Search
import com.tomtom.sdk.search.SearchCallback                  // SDK-CHECK import
import com.tomtom.sdk.search.SearchOptions                   // SDK-CHECK import
import com.tomtom.sdk.search.model.SearchResponse            // SDK-CHECK import
import com.tomtom.sdk.search.common.error.SearchFailure      // SDK-CHECK import
import com.tomtom.sdk.telemetry.UserConsent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class ManeuverIcon { STRAIGHT, LEFT, RIGHT, SLIGHT_LEFT, SLIGHT_RIGHT, U_TURN, ARRIVE }

data class Guidance(
    val distanceM: Int,
    val text: String,
    val icon: ManeuverIcon,
    val thenText: String?,
    val thenIcon: ManeuverIcon?,
)

data class Place(val name: String, val address: String, val point: GeoPoint)

data class NavUi(
    val sdkReady: Boolean = false,
    val position: GeoPoint? = null,
    val course: Double = 0.0,
    val route: Route? = null,
    val navigating: Boolean = false,
    val guidance: Guidance? = null,
    val remainingM: Double = 0.0,
    val remainingSec: Long = 0,
    val delayMin: Long = 0,
    val results: List<Place> = emptyList(),
    val message: String? = null,
)

class NavViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(NavUi())
    val ui: StateFlow<NavUi> = _ui

    private var planner: RoutePlanner? = null
    private var search: Search? = null
    private var locationHooked = false

    init {
        // SDK must be initialised once, off the main thread
        viewModelScope.launch(Dispatchers.Default) {
            try {
                if (!TomTomSdk.isInitialized) {
                    val cfg = buildSdkConfiguration(
                        context = app,
                        apiKey = BuildConfig.TOMTOM_API_KEY,
                        telemetryUserConsent = { Prefs.consent(app) },
                    )
                    TomTomSdk.initialize(context = app, sdkConfiguration = cfg)
                }
                planner = TomTomSdk.createRoutePlanner()
                search = TomTomSdk.createSearch()
                hookNavigationListeners()
                _ui.update { it.copy(sdkReady = true) }
            } catch (t: Throwable) {
                Log.e(TAG, "SDK init failed", t)
                _ui.update { it.copy(message = "Map SDK failed to start: ${t.message}") }
            }
        }
    }

    private fun hookNavigationListeners() {
        TomTomSdk.navigation.addProgressUpdatedListener(ProgressUpdatedListener { p ->
            val route = _ui.value.route ?: return@ProgressUpdatedListener
            val along = p.distanceAlongRoute.inMeters()                              // SDK-CHECK
            val remaining = (route.summary.length.inMeters() - along).coerceAtLeast(0.0) // SDK-CHECK
            _ui.update {
                it.copy(
                    remainingM = remaining,
                    remainingSec = p.remainingTime.inWholeSeconds,
                    guidance = guidanceFor(route, along),
                )
            }
            if (remaining < 25.0) stopNavigation()
        })
    }

    /** Called once the location permission prompt has been answered. */
    fun onLocationPermission() {
        viewModelScope.launch(Dispatchers.Default) {
            _ui.first { it.sdkReady }
            val lp = TomTomSdk.locationProvider
            if (!locationHooked) {
                lp.addOnLocationUpdateListener(OnLocationUpdateListener { loc -> // SDK-CHECK
                    _ui.update { it.copy(position = loc.position, course = loc.course ?: it.course) }
                })
                locationHooked = true
            }
            lp.enable()
        }
    }

    fun searchPlaces(query: String) {
        val s = search ?: return
        if (query.isBlank()) return
        s.search(
            SearchOptions(query = query, geoBias = _ui.value.position),             // SDK-CHECK
            object : SearchCallback {
                override fun onSuccess(result: SearchResponse) {
                    val places = result.results.map { r ->                           // SDK-CHECK
                        val addr = r.place.address?.freeformAddress ?: ""
                        Place(r.poi?.names?.firstOrNull() ?: addr, addr, r.place.coordinate)
                    }
                    _ui.update { it.copy(results = places) }
                }
                override fun onFailure(failure: SearchFailure) {
                    _ui.update { it.copy(message = "Search failed: ${failure.message}") }
                }
            },
        )
    }

    fun navigateTo(dest: Place) {
        val origin = _ui.value.position
        val rp = planner
        if (origin == null || rp == null) {
            _ui.update { it.copy(message = "Waiting for GPS fix…") }
            return
        }
        val opts = RoutePlanningOptions(
            itinerary = Itinerary(origin = origin, destination = dest.point),
            guidanceOptions = GuidanceOptions(),                                     // SDK-CHECK
        )
        rp.planRoute(opts, object : RoutePlanningCallback {
            override fun onSuccess(result: RoutePlanningResponse) {
                val route = result.routes.first()
                viewModelScope.launch(Dispatchers.Main) {
                    TomTomSdk.navigation.start(NavigationOptions(RoutePlan(route, opts)))
                    _ui.update {
                        it.copy(
                            route = route, navigating = true, results = emptyList(),
                            remainingM = route.summary.length.inMeters(),
                            remainingSec = route.summary.travelTime.inWholeSeconds,   // SDK-CHECK
                            delayMin = route.summary.trafficDelay.inWholeMinutes,     // SDK-CHECK
                            guidance = guidanceFor(route, 0.0),
                        )
                    }
                }
            }
            override fun onFailure(failure: RoutingFailure) {
                _ui.update { it.copy(message = "Couldn't plan route: ${failure.message}") }
            }
        })
    }

    fun stopNavigation() {
        viewModelScope.launch(Dispatchers.Main) {
            runCatching { TomTomSdk.navigation.stop() }
            _ui.update { it.copy(route = null, navigating = false, guidance = null) }
        }
    }

    fun clearResults() = _ui.update { it.copy(results = emptyList()) }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    // Guidance derived from the route's instruction list + distance travelled along the route
    private fun guidanceFor(route: Route, along: Double): Guidance? {
        val list = route.instructions                                                // SDK-CHECK
        val idx = list.indexOfFirst { it.routeOffset.inMeters() > along + 5 }        // SDK-CHECK
        if (idx < 0) return null
        val cur = list[idx]
        val next = list.getOrNull(idx + 1)
        return Guidance(
            distanceM = (cur.routeOffset.inMeters() - along).roundToInt().coerceAtLeast(0),
            text = cur.combinedMessage,                                              // SDK-CHECK
            icon = iconFor(cur.maneuver.toString()),                                 // SDK-CHECK
            thenText = next?.combinedMessage,
            thenIcon = next?.let { iconFor(it.maneuver.toString()) },
        )
    }

    private fun iconFor(raw: String): ManeuverIcon {
        val n = raw.uppercase().replace("_", "")
        val left = "LEFT" in n
        val right = "RIGHT" in n
        val soft = "SLIGHT" in n || "BEAR" in n || "KEEP" in n || "EASY" in n
        return when {
            "UTURN" in n -> ManeuverIcon.U_TURN
            "ARRIVE" in n || "DESTINATION" in n -> ManeuverIcon.ARRIVE
            left && soft -> ManeuverIcon.SLIGHT_LEFT
            right && soft -> ManeuverIcon.SLIGHT_RIGHT
            left -> ManeuverIcon.LEFT
            right -> ManeuverIcon.RIGHT
            else -> ManeuverIcon.STRAIGHT
        }
    }

    private companion object { const val TAG = "NavViewModel" }
}

object Prefs {
    private fun sp(app: Application) = app.getSharedPreferences("launcher", 0)
    fun consentLevel(app: Application) = sp(app).getInt("telemetry", 0)
    fun setConsentLevel(app: Application, v: Int) = sp(app).edit().putInt("telemetry", v).apply()
    fun consent(app: Application): UserConsent = when (consentLevel(app)) {
        2 -> UserConsent.TelemetryOn
        1 -> UserConsent.LocationOnly
        else -> UserConsent.TelemetryOff
    }
}
