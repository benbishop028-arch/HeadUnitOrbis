package com.headunit.launcher.nav

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.headunit.launcher.BuildConfig
import com.tomtom.quantity.Distance
import com.tomtom.sdk.common.configuration.buildSdkConfiguration
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.init.createRoutePlanner
import com.tomtom.sdk.init.createSearch
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.location.OnLocationUpdateListener
import com.tomtom.sdk.map.display.visualization.routing.*
import com.tomtom.sdk.navigation.NavigationOptions
import com.tomtom.sdk.navigation.ProgressUpdatedListener
import com.tomtom.sdk.navigation.RoutePlan
import com.tomtom.sdk.navigation.GuidanceUpdatedListener
import com.tomtom.sdk.navigation.guidance.GuidanceAnnouncement
import com.tomtom.sdk.navigation.guidance.InstructionPhase
import com.tomtom.sdk.navigation.guidance.instruction.GuidanceInstruction
import com.tomtom.sdk.routing.RoutePlanner
import com.tomtom.sdk.routing.RoutePlanningCallback
import com.tomtom.sdk.routing.RoutePlanningResponse
import com.tomtom.sdk.routing.RoutingFailure
import com.tomtom.sdk.routing.options.Itinerary
import com.tomtom.sdk.routing.options.RoutePlanningOptions
import com.tomtom.sdk.routing.route.Route
import com.tomtom.sdk.routing.route.RouteId
import com.tomtom.sdk.search.Search
import com.tomtom.sdk.search.SearchCallback
import com.tomtom.sdk.search.SearchOptions
import com.tomtom.sdk.search.SearchResponse
import com.tomtom.sdk.search.common.error.SearchFailure
import com.tomtom.sdk.telemetry.UserConsent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class ManeuverIcon { STRAIGHT, LEFT, RIGHT, SLIGHT_LEFT, SLIGHT_RIGHT, U_TURN, ARRIVE }

data class Guidance(
    val distanceM: Int,
    val text: String,
    val icon: ManeuverIcon,
    val thenIcon: ManeuverIcon?,
)

data class Place(val name: String, val address: String, val point: GeoPoint)

data class NavUi(
    val sdkReady: Boolean = false,
    val position: GeoPoint? = null,
    val course: Double = 0.0,
    val navigating: Boolean = false,
    val guidance: Guidance? = null,
    val remainingM: Double = 0.0,
    val remainingSec: Long = 0,
    val delayMin: Long = 0,
    val results: List<Place> = emptyList(),
    val message: String? = null,
)

class NavViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(NavUi())
    val ui: StateFlow<NavUi> = _ui

    private val routes = MutableStateFlow<List<Route>>(emptyList())
    private val selectedRouteId = MutableStateFlow<RouteId?>(null)

    val routingVisualizationInfrastructure: RoutingVisualizationInfrastructure by lazy {
        RoutingVisualizationInfrastructure(
            sdkContext = TomTomSdk.sdkContext,
            dataProvider = RoutingVisualizationDataProvider(routes, selectedRouteId),
        )
    }

    private var planner: RoutePlanner? = null
    private var search: Search? = null
    private var locationHooked = false

    init {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                if (!TomTomSdk.isInitialized) {
                    val cfg = buildSdkConfiguration(
                        context = app,
                        apiKey = BuildConfig.TOMTOM_API_KEY,
                        telemetryUserConsent = { Prefs.consent(app) },
                    )
                    TomTomSdk.initialize(context = app, sdkConfiguration = cfg)
                }
                planner = TomTomSdk.createRoutePlanner()
                search = TomTomSdk.createSearch()
                hookNavigationListeners()
                _ui.update { it.copy(sdkReady = true) }
            } catch (t: Throwable) {
                Log.e(TAG, "SDK init failed", t)
                _ui.update { it.copy(message = "Map SDK failed to start: ${t.message}") }
            }
        }
    }

    private fun hookNavigationListeners() {
        val nav = TomTomSdk.navigation
        nav.addProgressUpdatedListener(ProgressUpdatedListener { p ->
            val remaining = p.remainingDistance.inMeters()
            _ui.update {
                it.copy(
                    remainingM = remaining,
                    remainingSec = p.remainingTime.inWholeSeconds,
                    delayMin = p.remainingTrafficDelay.inWholeMinutes,
                )
            }
            if (remaining < 25.0) stopNavigation()
        })
        nav.addGuidanceUpdatedListener(object : GuidanceUpdatedListener {
            override fun onInstructionsChanged(instructions: List<GuidanceInstruction>) {
                lastInstructions = instructions
                publishGuidance(lastDistanceM)
            }
            override fun onAnnouncementGenerated(announcement: GuidanceAnnouncement, shouldPlay: Boolean) {}
            override fun onDistanceToNextInstructionChanged(
                distance: Distance,
                instructions: List<GuidanceInstruction>,
                currentPhase: InstructionPhase,
            ) {
                lastInstructions = instructions
                lastDistanceM = distance.inMeters().roundToInt().coerceAtLeast(0)
                publishGuidance(lastDistanceM)
            }
        })
    }

    private var lastInstructions: List<GuidanceInstruction> = emptyList()
    private var lastDistanceM = 0

    private fun publishGuidance(distM: Int) {
        val cur = lastInstructions.firstOrNull() ?: return
        val road = cur.nextSignificantRoad?.name?.toString() ?: cur.intersectionName?.toString() ?: ""
        val next = lastInstructions.getOrNull(1)
        _ui.update {
            it.copy(guidance = Guidance(distM, road, iconFor(cur), next?.let { n -> iconFor(n) }))
        }
    }

    private fun iconFor(ins: Any): ManeuverIcon {
        if (ins is com.tomtom.sdk.navigation.guidance.instruction.ArrivalGuidanceInstruction) return ManeuverIcon.ARRIVE
        if (ins is com.tomtom.sdk.navigation.guidance.instruction.TurnAroundWhenPossibleGuidanceInstruction) return ManeuverIcon.U_TURN
        val raw = if (ins is com.tomtom.sdk.navigation.guidance.instruction.TurnGuidanceInstruction)
            ins.turnDirection.toString() else ins.javaClass.simpleName
        val n = raw.uppercase().replace("_", "")
        val left = "LEFT" in n
        val right = "RIGHT" in n
        val soft = "SLIGHT" in n || "BEAR" in n || "KEEP" in n || "EASY" in n
        return when {
            "UTURN" in n -> ManeuverIcon.U_TURN
            "ARRI" in n || "DESTINATION" in n -> ManeuverIcon.ARRIVE
            left && soft -> ManeuverIcon.SLIGHT_LEFT
            right && soft -> ManeuverIcon.SLIGHT_RIGHT
            left -> ManeuverIcon.LEFT
            right -> ManeuverIcon.RIGHT
            else -> ManeuverIcon.STRAIGHT
        }
    }

    fun onLocationPermission() {
        viewModelScope.launch(Dispatchers.Default) {
            _ui.first { it.sdkReady }
            val lp = TomTomSdk.locationProvider
            if (!locationHooked) {
                lp.addOnLocationUpdateListener(OnLocationUpdateListener { loc ->
                    _ui.update { it.copy(position = loc.position, course = loc.course?.let { c -> (c as? Number)?.toDouble() ?: c.toString().toDoubleOrNull() } ?: it.course) }
                })
                locationHooked = true
            }
            lp.enable()
        }
    }

    fun searchPlaces(query: String) {
        val s = search ?: return
        if (query.isBlank()) return
        s.search(
            SearchOptions(query = query, geoBias = _ui.value.position),
            object : SearchCallback {
                override fun onSuccess(result: SearchResponse) {
                    val places = result.results.map { r ->
                        val addr = r.place.address?.freeformAddress ?: ""
                        Place(r.poi?.names?.firstOrNull() ?: addr, addr, r.place.coordinate)
                    }
                    _ui.update { it.copy(results = places) }
                }
                override fun onFailure(failure: SearchFailure) {
                    _ui.update { it.copy(message = "Search failed: ${failure.message}") }
                }
            },
        )
    }

    fun navigateTo(dest: Place) {
        val origin = _ui.value.position
        val rp = planner
        if (origin == null || rp == null) {
            _ui.update { it.copy(message = "Waiting for GPS fix…") }
            return
        }
        val opts = RoutePlanningOptions(
            itinerary = Itinerary(origin = origin, destination = dest.point),
            guidanceOptions = com.tomtom.sdk.routing.options.guidance.GuidanceOptions(),
        )
        rp.planRoute(opts, object : RoutePlanningCallback {
            override fun onSuccess(result: RoutePlanningResponse) {
                val route = result.routes.first()
                viewModelScope.launch(Dispatchers.Main) {
                    routes.value = listOf(route)
                    selectedRouteId.value = route.id
                    TomTomSdk.navigation.start(NavigationOptions(RoutePlan(route, opts)))
                    _ui.update {
                        it.copy(navigating = true, results = emptyList(), remainingM = 0.0, remainingSec = 0)
                    }
                }
            }
            override fun onFailure(failure: RoutingFailure) {
                _ui.update { it.copy(message = "Couldn't plan route: ${failure.message}") }
            }
        })
    }

    fun stopNavigation() {
        viewModelScope.launch(Dispatchers.Main) {
            runCatching { TomTomSdk.navigation.stop() }
            routes.value = emptyList()
            selectedRouteId.value = null
            _ui.update { it.copy(navigating = false, guidance = null) }
        }
    }

    fun clearResults() = _ui.update { it.copy(results = emptyList()) }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    private companion object { const val TAG = "NavViewModel" }
}

object Prefs {
    private fun sp(app: Application) = app.getSharedPreferences("launcher", 0)
    fun consentLevel(app: Application) = sp(app).getInt("telemetry", 0)
    fun setConsentLevel(app: Application, v: Int) = sp(app).edit().putInt("telemetry", v).apply()
    fun consent(app: Application): UserConsent = when (consentLevel(app)) {
        2 -> UserConsent.TelemetryOn
        1 -> UserConsent.LocationOnly
        else -> UserConsent.TelemetryOff
    }
}
