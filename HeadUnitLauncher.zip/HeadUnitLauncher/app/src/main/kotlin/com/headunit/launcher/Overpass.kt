package com.headunit.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Nearby(val place: Place, val dist: Double, val extra: String)

/** Free OpenStreetMap queries: speed limits, speed cameras and nearby fuel / charging / parking. */
object Overpass {
    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
    )

    private fun run(query: String): JSONArray {
        var last: Exception? = null
        for (ep in endpoints) {
            try {
                val c = URL(ep + "?data=" + URLEncoder.encode(query, "UTF-8")).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", "DriveLauncher/1.0")
                val code = c.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                val body = c.inputStream.bufferedReader().readText()
                return JSONObject(body).optJSONArray("elements") ?: JSONArray()
            } catch (e: Exception) { last = e }
        }
        throw last ?: IOException("Overpass unavailable")
    }

    private fun parseSpeed(s: String): Double? {
        val m = Regex("^(\\d+)\\s*(mph|km/h|kmh|kph)?$").find(s.trim().lowercase()) ?: return null
        val v = m.groupValues[1].toDouble()
        return if (m.groupValues[2] == "mph") v * 0.44704 else v / 3.6
    }

    /** Posted speed limit of the road at [p] in m/s, or null when OpenStreetMap has none. */
    fun speedLimit(p: LL): Double? = try {
        val els = run("[out:json][timeout:8];way(around:20,${p.lat},${p.lon})[\"highway\"][\"maxspeed\"];out tags geom 6;")
        var best: Double? = null
        var bd = 1e9
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val v = parseSpeed(e.optJSONObject("tags")?.optString("maxspeed").orEmpty()) ?: continue
            val g = e.optJSONArray("geometry") ?: continue
            var d = 1e9
            for (n in 0 until g.length()) {
                val o = g.getJSONObject(n)
                d = minOf(d, Geo.dist(p, LL(o.getDouble("lat"), o.getDouble("lon"))))
            }
            if (d < bd) { bd = d; best = v }
        }
        best
    } catch (e: Exception) { null }

    fun cameras(p: LL, radius: Int): List<LL> = try {
        val els = run("[out:json][timeout:10];node(around:$radius,${p.lat},${p.lon})[\"highway\"=\"speed_camera\"];out;")
        (0 until els.length()).mapNotNull {
            val e = els.getJSONObject(it)
            if (e.has("lat") && e.has("lon")) LL(e.getDouble("lat"), e.getDouble("lon")) else null
        }
    } catch (e: Exception) { emptyList() }

    /** kind: "fuel", "charging" or "parking". */
    fun nearby(kind: String, c: LL, radius: Int): List<Nearby> {
        val f = when (kind) {
            "fuel" -> "[\"amenity\"=\"fuel\"]"
            "charging" -> "[\"amenity\"=\"charging_station\"]"
            else -> "[\"amenity\"=\"parking\"]"
        }
        val q = "[out:json][timeout:20];(node(around:$radius,${c.lat},${c.lon})$f;way(around:$radius,${c.lat},${c.lon})$f;);out center tags 80;"
        val els = run(q)
        val out = ArrayList<Nearby>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags") ?: JSONObject()
            val pos = if (e.has("lat")) LL(e.getDouble("lat"), e.getDouble("lon"))
            else e.optJSONObject("center")?.let { LL(it.getDouble("lat"), it.getDouble("lon")) } ?: continue
            val label = when (kind) { "fuel" -> "Fuel station"; "charging" -> "Charging point"; else -> "Car park" }
            val name = tags.optString("name").ifBlank { tags.optString("brand") }.ifBlank { tags.optString("operator") }.ifBlank { label }
            val extra = ArrayList<String>()
            when (kind) {
                "fuel" -> {
                    tags.optString("brand").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                    tags.optString("opening_hours").takeIf { it.isNotBlank() }?.let { extra += it }
                }
                "charging" -> {
                    val sockets = ArrayList<String>()
                    val it2 = tags.keys()
                    while (it2.hasNext()) {
                        val k = it2.next()
                        if (k.startsWith("socket:") && k.count { ch -> ch == ':' } == 1) {
                            val nice = k.removePrefix("socket:").replace("_", " ")
                            val cnt = tags.optString(k)
                            sockets += if (cnt.toIntOrNull() != null) "$nice ×$cnt" else nice
                        }
                    }
                    if (sockets.isNotEmpty()) extra += sockets.take(3).joinToString(", ")
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it points" }
                    tags.optString("operator").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                }
                else -> {
                    when (tags.optString("fee")) { "yes" -> extra += "Paid"; "no" -> extra += "Free" }
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it spaces" }
                    when (tags.optString("parking")) { "multi-storey" -> extra += "Multi-storey"; "underground" -> extra += "Underground" }
                }
            }
            out += Nearby(Place(name, tags.optString("addr:street"), pos), Geo.dist(c, pos), extra.joinToString(" · "))
        }
        return out.sortedBy { it.dist }.take(40)
    }
}
