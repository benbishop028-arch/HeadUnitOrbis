package com.headunit.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Nearby(val place: Place, val dist: Double, val extra: String)

/** Free OpenStreetMap queries: speed limits, speed cameras and nearby fuel / charging / parking. */
object Overpass {
    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    )

    /** The server that answered last time is tried first. */
    @Volatile private var preferred = 0

    private fun run(query: String): JSONArray {
        val errors = ArrayList<String>()
        for (n in endpoints.indices) {
            val idx = (preferred + n) % endpoints.size
            val ep = endpoints[idx]
            val host = ep.removePrefix("https://").substringBefore('/')
            try {
                val c = URL(ep).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 18000
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("User-Agent", "DriveLauncher/1.0 (Android head unit launcher)")
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
                val code = c.responseCode
                if (code !in 200..299) throw IOException("HTTP $code")
                val body = c.inputStream.bufferedReader().readText()
                val els = JSONObject(body).optJSONArray("elements") ?: JSONArray()
                preferred = idx
                return els
            } catch (e: Exception) { errors += host.removePrefix("www.").substringBefore('.') + ": " + (e.message ?: e.javaClass.simpleName) }
        }
        throw IOException(errors.joinToString("; "))
    }

    private fun parseSpeed(s: String): Double? {
        val m = Regex("^(\\d+)\\s*(mph|km/h|kmh|kph)?$").find(s.trim().lowercase()) ?: return null
        val v = m.groupValues[1].toDouble()
        return if (m.groupValues[2] == "mph") v * 0.44704 else v / 3.6
    }

    class Limit(val ms: Double, val estimated: Boolean)

    /** Set when the last speed-limit lookup failed (no network, server busy…), null when it worked. */
    @Volatile var lastError: String? = null

    private val driveable = setOf(
        "motorway", "motorway_link", "trunk", "trunk_link", "primary", "primary_link", "secondary", "secondary_link",
        "tertiary", "tertiary_link", "unclassified", "residential", "living_street", "service", "road",
    )

    /** Typical limit for a road without a posted one, from its type and the country (m/s). */
    private fun estimate(tags: JSONObject, country: String): Double? {
        val hw = tags.optString("highway")
        if (hw !in driveable) return null
        val link = hw.endsWith("_link")
        val base = hw.removeSuffix("_link")
        val lit = tags.optString("lit") == "yes"
        val oneway = tags.optString("oneway") == "yes"
        val mph = 0.44704
        val kmh = 1.0 / 3.6
        return when (country) {
            "GB" -> when (base) {
                "motorway" -> if (link) 50 * mph else 70 * mph
                "trunk", "primary", "secondary", "tertiary", "unclassified" ->
                    if (link) 40 * mph else if (lit) 30 * mph else if (oneway && (base == "trunk" || base == "primary")) 70 * mph else 60 * mph
                "residential" -> 30 * mph
                "living_street" -> 20 * mph
                "service" -> 10 * mph
                else -> 30 * mph
            }
            "US" -> when (base) {
                "motorway" -> if (link) 45 * mph else 65 * mph
                "trunk", "primary" -> if (lit) 35 * mph else 55 * mph
                "secondary", "tertiary" -> if (lit) 30 * mph else 45 * mph
                "unclassified" -> 35 * mph
                "residential" -> 25 * mph
                "living_street" -> 10 * mph
                else -> 15 * mph
            }
            else -> when (base) {
                "motorway" -> if (link) 60 * kmh else 130 * kmh
                "trunk", "primary" -> if (link) 60 * kmh else if (lit) 50 * kmh else 100 * kmh
                "secondary", "tertiary", "unclassified" -> if (link) 50 * kmh else if (lit) 50 * kmh else 80 * kmh
                "residential" -> 30 * kmh
                "living_street" -> 10 * kmh
                else -> 20 * kmh
            }
        }
    }

    /** Speed limit of the road at [p]: the posted one when OpenStreetMap has it, otherwise the usual limit for that kind of road. */
    fun speedLimit(p: LL, country: String = java.util.Locale.getDefault().country): Limit? = try {
        val els = run("[out:json][timeout:8];way(around:20,${p.lat},${p.lon})[\"highway\"];out tags geom 10;")
        var bestTags: JSONObject? = null
        var bd = 1e9
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags") ?: continue
            if (tags.optString("highway") !in driveable) continue
            val g = e.optJSONArray("geometry") ?: continue
            var d = 1e9
            for (n in 0 until g.length()) {
                val o = g.getJSONObject(n)
                d = minOf(d, Geo.dist(p, LL(o.getDouble("lat"), o.getDouble("lon"))))
            }
            if (d < bd) { bd = d; bestTags = tags }
        }
        lastError = null
        val t = bestTags
        if (t == null) null
        else {
            val posted = parseSpeed(t.optString("maxspeed"))
            if (posted != null) Limit(posted, false)
            else estimate(t, country)?.let { Limit(it, true) }
        }
    } catch (e: Exception) { lastError = e.message ?: e.javaClass.simpleName; null }

    fun cameras(p: LL, radius: Int): List<LL> = try {
        val els = run("[out:json][timeout:10];node(around:$radius,${p.lat},${p.lon})[\"highway\"=\"speed_camera\"];out;")
        (0 until els.length()).mapNotNull {
            val e = els.getJSONObject(it)
            if (e.has("lat") && e.has("lon")) LL(e.getDouble("lat"), e.getDouble("lon")) else null
        }
    } catch (e: Exception) { emptyList() }

    /** kind: "fuel", "charging" or "parking". */
    fun nearby(kind: String, c: LL, radius: Int): List<Nearby> {
        val f = when (kind) {
            "fuel" -> "[\"amenity\"=\"fuel\"]"
            "charging" -> "[\"amenity\"=\"charging_station\"]"
            else -> "[\"amenity\"=\"parking\"]"
        }
        val q = "[out:json][timeout:20];(node(around:$radius,${c.lat},${c.lon})$f;way(around:$radius,${c.lat},${c.lon})$f;);out center tags 80;"
        val els = run(q)
        val out = ArrayList<Nearby>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags") ?: JSONObject()
            val pos = if (e.has("lat")) LL(e.getDouble("lat"), e.getDouble("lon"))
            else e.optJSONObject("center")?.let { LL(it.getDouble("lat"), it.getDouble("lon")) } ?: continue
            val label = when (kind) { "fuel" -> "Fuel station"; "charging" -> "Charging point"; else -> "Car park" }
            val name = tags.optString("name").ifBlank { tags.optString("brand") }.ifBlank { tags.optString("operator") }.ifBlank { label }
            val extra = ArrayList<String>()
            when (kind) {
                "fuel" -> {
                    tags.optString("brand").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                    tags.optString("opening_hours").takeIf { it.isNotBlank() }?.let { extra += it }
                }
                "charging" -> {
                    val sockets = ArrayList<String>()
                    val it2 = tags.keys()
                    while (it2.hasNext()) {
                        val k = it2.next()
                        if (k.startsWith("socket:") && k.count { ch -> ch == ':' } == 1) {
                            val nice = k.removePrefix("socket:").replace("_", " ")
                            val cnt = tags.optString(k)
                            sockets += if (cnt.toIntOrNull() != null) "$nice ×$cnt" else nice
                        }
                    }
                    if (sockets.isNotEmpty()) extra += sockets.take(3).joinToString(", ")
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it points" }
                    tags.optString("operator").takeIf { it.isNotBlank() && it != name }?.let { extra += it }
                }
                else -> {
                    when (tags.optString("fee")) { "yes" -> extra += "Paid"; "no" -> extra += "Free" }
                    tags.optString("capacity").takeIf { it.isNotBlank() }?.let { extra += "$it spaces" }
                    when (tags.optString("parking")) { "multi-storey" -> extra += "Multi-storey"; "underground" -> extra += "Underground" }
                }
            }
            out += Nearby(Place(name, tags.optString("addr:street"), pos), Geo.dist(c, pos), extra.joinToString(" · "))
        }
        return out.sortedBy { it.dist }.take(40)
    }
}
