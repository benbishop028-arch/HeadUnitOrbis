package com.headunit.launcher

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat

class CalEvent(val title: String, val begin: Long, val end: Long, val where: String, val allDay: Boolean)

object CalendarData {
    fun has(ctx: Context) = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun upcoming(ctx: Context, days: Int): List<CalEvent> {
        if (!has(ctx)) return emptyList()
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now - 3_600_000L)
        ContentUris.appendId(b, now + days * 86_400_000L)
        val out = ArrayList<CalEvent>()
        try {
            ctx.contentResolver.query(
                b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY),
                null, null, CalendarContract.Instances.BEGIN + " ASC",
            )?.use { c ->
                while (c.moveToNext() && out.size < 80) {
                    val end = c.getLong(2)
                    if (end < now) continue
                    out += CalEvent(c.getString(0) ?: "(no title)", c.getLong(1), end, c.getString(3) ?: "", c.getInt(4) == 1)
                }
            }
        } catch (e: Exception) { /* no calendar provider */ }
        return out
    }
}
