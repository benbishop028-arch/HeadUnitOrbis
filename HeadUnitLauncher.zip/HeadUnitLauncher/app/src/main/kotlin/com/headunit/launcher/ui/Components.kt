package com.headunit.launcher.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.animation.togetherWith
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.clickable
import androidx.compose.ui.composed
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.headunit.launcher.MapBinding
import kotlin.math.cos
import kotlin.math.sin

/** Click with a small press-in scale, so buttons feel responsive. Put it first in the chain to scale the whole button. */
fun Modifier.pressClick(onClick: () -> Unit): Modifier = this.composed {
    val src = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by androidx.compose.animation.core.animateFloatAsState(if (pressed) 0.93f else 1f, androidx.compose.animation.core.tween(90), label = "press")
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    this.graphicsLayer { scaleX = s; scaleY = s }.clickable(interactionSource = src, indication = null, onClick = {
        try { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
        onClick()
    })
}

@Composable
fun VCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit) {
    val c = LocalVw.current
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(c.panel)
            .border(1.dp, c.line.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        content = content,
    )
}

fun Color.lighten(f: Float) = Color(red + (1f - red) * f, green + (1f - green) * f, blue + (1f - blue) * f, alpha)
fun Color.darken(f: Float) = Color(red * (1f - f), green * (1f - f), blue * (1f - f), alpha)

/** Flat inset tile for rows that sit on a VCard, same as the menu tiles. */
@Composable
fun Modifier.inset(radius: androidx.compose.ui.unit.Dp = 16.dp, tint: Color? = null): Modifier {
    val c = LocalVw.current
    val shape = RoundedCornerShape(radius)
    return this.clip(shape).background(if (tint != null) tint.copy(alpha = 0.16f) else c.tile)
}

/** Floating panel surface (search suggestions, nearby lists, overlays). */
@Composable
fun Modifier.glass(radius: androidx.compose.ui.unit.Dp = 22.dp): Modifier {
    val c = LocalVw.current
    return this.clip(RoundedCornerShape(radius)).background(c.panel.copy(alpha = 0.98f))
}

/** Small quiet section label. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier, trailing: String? = null) {
    val c = LocalVw.current
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(text.uppercase(), color = c.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.9.sp, modifier = Modifier.weight(1f, fill = trailing != null))
        if (trailing != null) Text(trailing, color = c.sub, fontSize = 12.sp)
    }
}

/** Dark rounded tile holding a coloured glyph, like the menu tiles. */
@Composable
fun IconBadge(icon: ImageVector, tint: Color, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    val c = LocalVw.current
    Box(
        modifier.size(size).clip(RoundedCornerShape(size * 0.22f)).background(c.tile),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

/** Page title: big headline with an optional subtitle. */
@Composable
fun PageTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    Column(modifier) {
        Text(title, color = c.onBg, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp)
        if (subtitle != null) Text(subtitle, color = c.onBgSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun RoundBtn(
    icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier,
    active: Boolean = false, size: Dp = 50.dp, tint: Color? = null,
) {
    val c = LocalVw.current
    Box(
        modifier
            .pressClick(onClick)
            .size(size)
            .clip(CircleShape)
            .background(if (active) c.accent else c.surface.copy(alpha = 0.94f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint ?: if (active) Color.White else c.text, modifier = Modifier.size(size * 0.5f))
    }
}

/** Text that rolls vertically to its new value instead of snapping. */
@Composable
fun RollText(
    text: String, color: Color, fontSize: androidx.compose.ui.unit.TextUnit, modifier: Modifier = Modifier,
    fontWeight: FontWeight? = null,
) {
    androidx.compose.animation.AnimatedContent(
        targetState = text,
        modifier = modifier.clipToBounds(),
        transitionSpec = {
            (androidx.compose.animation.slideInVertically { it / 2 } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(170))) togetherWith
                (androidx.compose.animation.slideOutVertically { -it / 2 } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)))
        },
        label = "roll",
    ) { t -> Text(t, color = color, fontSize = fontSize, fontWeight = fontWeight, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis) }
}

/** Speed colour that warms from white to amber as you near the limit (red once over it); null when there is no reason to tint. */
@Composable
fun speedTint(engine: com.headunit.launcher.NavEngine): Color? {
    if (engine.overLimit) return Bad
    val lim = engine.speedLimit ?: return null
    val sp = engine.fix?.speed ?: return null
    if (engine.limitEstimated || lim <= 0) return null
    val r = (sp / lim).toFloat()
    if (r < 0.85f) return null
    return androidx.compose.ui.graphics.lerp(LocalVw.current.text, Warn, ((r - 0.85f) / 0.12f).coerceIn(0f, 1f))
}

/** Flat round button used for transport and keypad controls. */
@Composable
fun TileBtn(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 56.dp, bg: Color? = null, tint: Color? = null) {
    val c = LocalVw.current
    Box(modifier.pressClick(onClick).size(size).clip(CircleShape).background(bg ?: c.tile), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint ?: c.text, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Pill(
    text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, selectedColor: Color? = null,
) {
    val c = LocalVw.current
    val sel = selectedColor ?: c.accent
    val bg by androidx.compose.animation.animateColorAsState(if (selected) sel else c.tile, androidx.compose.animation.core.tween(160), label = "pill")
    val fg = if (selected) (if (sel.luminance() > 0.6f) Color(0xFF14171C) else Color.White) else c.text
    Box(
        modifier
            .pressClick(onClick)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** Friendly placeholder for a page or list with nothing in it yet. */
@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String? = null, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    Column(modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = c.sub, modifier = Modifier.size(32.dp))
        }
        Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
        if (sub != null) Text(sub, color = c.sub, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 4.dp, start = 24.dp, end = 24.dp))
    }
}

/** Softly pulsing placeholder shape shown while data loads. */
@Composable
fun Skeleton(modifier: Modifier = Modifier, radius: Dp = 10.dp) {
    val c = LocalVw.current
    val a by androidx.compose.animation.core.rememberInfiniteTransition(label = "skeleton").animateFloat(
        0.10f, 0.22f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "skeletonA",
    )
    Box(modifier.clip(RoundedCornerShape(radius)).background(c.sub.copy(alpha = a)))
}

@Composable
fun MapHost(map: MapBinding, modifier: Modifier = Modifier, cornerDp: Int = 0) {
    val dens by androidx.compose.runtime.rememberUpdatedState(androidx.compose.ui.platform.LocalDensity.current.density)
    val tint = LocalVw.current.mapTint
    Box(modifier) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            FrameLayout(ctx).apply {
                if (cornerDp > 0) {
                                        outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, cornerDp * dens)
                        }
                    }
                    clipToOutline = true
                }
                (map.mapView.parent as? ViewGroup)?.removeView(map.mapView)
                addView(map.mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        },
        update = { it.invalidateOutline() },
        onRelease = { it.removeAllViews() },
    )
    // colour wash so the map matches the chosen look; touches pass straight through to the map
    if (tint.alpha > 0f) Box(Modifier.fillMaxSize().clip(RoundedCornerShape(cornerDp.dp)).background(tint))
    }
}

/** Turn arrow drawn from the manoeuvre name (no image assets needed). */
@Composable
fun ManeuverArrow(maneuver: String, angle: Float, modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val s = size.minDimension / 48f
        val sw = 5f * s
        val u = maneuver.uppercase()
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        if (u.startsWith("ARRIVE")) {
            val flag = Path().apply { moveTo(14 * s, 42 * s); lineTo(14 * s, 6 * s) }
            drawPath(flag, color, style = stroke)
            val f = Path().apply { moveTo(14 * s, 8 * s); lineTo(38 * s, 8 * s); lineTo(32 * s, 16 * s); lineTo(38 * s, 24 * s); lineTo(14 * s, 24 * s); close() }
            drawPath(f, color)
            return@Canvas
        }
        if (u == "MAKE_UTURN" || u == "ROUNDABOUT_BACK") {
            val path = Path().apply {
                moveTo(32 * s, 44 * s); lineTo(32 * s, 20 * s)
                arcTo(Rect(Offset(16 * s, 8 * s), Size(16 * s, 24 * s)), 0f, -180f, false)
                lineTo(16 * s, 30 * s)
            }
            drawPath(path, color, style = stroke)
            val head = Path().apply { moveTo(8 * s, 28 * s); lineTo(24 * s, 28 * s); lineTo(16 * s, 40 * s); close() }
            drawPath(head, color)
            return@Canvas
        }
        if (u.startsWith("ROUNDABOUT")) {
            // ring with the road you enter on and the exit you take
            val cx = 24f; val cy = 26f; val rr = 8f
            drawCircle(color, rr * s, p(cx, cy), style = Stroke(width = 3.5f * s))
            drawLine(color, p(24f, 46f), p(24f, cy + rr), sw, StrokeCap.Round)
            val ar = Math.toRadians(angle.toDouble())
            val dx = sin(ar).toFloat(); val dy = -cos(ar).toFloat()
            val ex = cx + dx * (rr + 11f); val ey = cy + dy * (rr + 11f)
            drawLine(color, p(cx + dx * rr, cy + dy * rr), p(ex, ey), sw, StrokeCap.Round)
            val qx = -dy; val qy = dx
            val tip = p(ex + dx * 6f, ey + dy * 6f)
            val h1 = p(ex - dx * 3f + qx * 5.5f, ey - dy * 3f + qy * 5.5f)
            val h2 = p(ex - dx * 3f - qx * 5.5f, ey - dy * 3f - qy * 5.5f)
            drawPath(Path().apply { moveTo(tip.x, tip.y); lineTo(h1.x, h1.y); lineTo(h2.x, h2.y); close() }, color)
            return@Canvas
        }
        val r = Math.toRadians(angle.toDouble())
        val x1 = 24f; val y1 = 28f; val len = 16f
        val ux = sin(r).toFloat(); val uy = -cos(r).toFloat()
        val x2 = x1 + ux * len; val y2 = y1 + uy * len
        if (u.startsWith("ROUNDABOUT")) drawCircle(color, 6f * s, p(24f, 38f), style = Stroke(width = 3f * s))
        val shaft = Path().apply { moveTo(24 * s, 44 * s); lineTo(x1 * s, y1 * s); lineTo(x2 * s, y2 * s) }
        drawPath(shaft, color, style = stroke)
        val px = -uy; val py = ux
        val hl = 11f; val hw = 9f
        val tip = p(x2 + ux * hl * 0.6f, y2 + uy * hl * 0.6f)
        val b1 = p(x2 - ux * hl * 0.4f + px * hw * 0.55f, y2 - uy * hl * 0.4f + py * hw * 0.55f)
        val b2 = p(x2 - ux * hl * 0.4f - px * hw * 0.55f, y2 - uy * hl * 0.4f - py * hw * 0.55f)
        val head = Path().apply { moveTo(tip.x, tip.y); lineTo(b1.x, b1.y); lineTo(b2.x, b2.y); close() }
        drawPath(head, color)
    }
}

val NoPad = PaddingValues(0.dp)

/** Row of small level dots (seat heat, fan). */
@Composable
fun Dots(level: Int, max: Int, on: Color, off: Color, modifier: Modifier = Modifier, dot: Dp = 4.dp) {
    Row(modifier, horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(3.dp)) {
        for (i in 1..max) Box(Modifier.size(dot).clip(CircleShape).background(if (i <= level) on else off))
    }
}

/** Centre "home" key of the bottom bar: rounded square with a ring, glowing in the ambient colour. */
@Composable
fun HomeKey(glow: Color, line: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.pressClick(onClick).size(62.dp).clip(RoundedCornerShape(14.dp))
            .drawBehind {
                drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.55f), Color.Transparent)), radius = size.minDimension * 0.9f)
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(34.dp)) {
            drawRoundRect(line, cornerRadius = CornerRadius(8f * density), style = Stroke(width = 2f * density))
        }
    }
}

/** Defrost glyphs drawn by hand: window outline with three wavy heat lines. */
@Composable
fun DefrostIcon(front: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(28.dp)) {
        val w = size.width; val h = size.height
        val sw = 2f * density
        val outline = Path().apply {
            if (front) { moveTo(w * 0.05f, h * 0.85f); lineTo(w * 0.22f, h * 0.12f); lineTo(w * 0.78f, h * 0.12f); lineTo(w * 0.95f, h * 0.85f); close() }
            else { moveTo(w * 0.06f, h * 0.2f); lineTo(w * 0.94f, h * 0.2f); lineTo(w * 0.94f, h * 0.8f); lineTo(w * 0.06f, h * 0.8f); close() }
        }
        drawPath(outline, color, style = Stroke(width = sw, join = StrokeJoin.Round))
        for (i in 0..2) {
            val x = w * (0.32f + 0.18f * i)
            val wave = Path().apply {
                moveTo(x, h * 0.7f); cubicTo(x - w * 0.06f, h * 0.55f, x + w * 0.06f, h * 0.45f, x, h * 0.3f)
            }
            drawPath(wave, color, style = Stroke(width = sw * 0.8f, cap = StrokeCap.Round))
        }
    }
}

/** Colourful ring used for "Ambient light". */
@Composable
fun AmbientGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cols = listOf(Color(0xFFFF3B4D), Color(0xFFFFB020), Color(0xFF2BD66B), Color(0xFF2D8CFF), Color(0xFFA855F7))
        val stroke = size.minDimension * 0.2f
        val inset = stroke / 2
        cols.forEachIndexed { i, col ->
            drawArc(col, i * 72f - 90f, 70f, false, topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke), style = Stroke(width = stroke, cap = StrokeCap.Butt))
        }
    }
}

/** Draggable / tappable progress bar. [onSeek] gets the new position as a 0..1 fraction. */
@Composable
fun SeekBar(frac: Float, enabled: Boolean, onSeek: (Float) -> Unit, modifier: Modifier = Modifier, fill: Color? = null, track: Color? = null) {
    val c = LocalVw.current
    var drag by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Float?>(null) }
    var w by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(1) }
    val shown = (drag ?: frac).coerceIn(0f, 1f)
    Box(
        modifier.height(26.dp)
            .onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { o -> onSeek((o.x / w).coerceIn(0f, 1f)) }
            }
            .pointerInput(enabled) {
                if (enabled) detectHorizontalDragGestures(
                    onDragStart = { o -> drag = (o.x / w).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let(onSeek); drag = null },
                    onDragCancel = { drag = null },
                ) { change, _ -> change.consume(); drag = (change.position.x / w).coerceIn(0f, 1f) }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(track ?: c.line))
        Box(Modifier.fillMaxWidth(shown).height(6.dp).clip(RoundedCornerShape(3.dp)).background(fill ?: c.accent))
    }
}

/** Returns a function that opens the system speech recogniser and passes back the first result. */
@Composable
fun rememberVoiceInput(prompt: String, onResult: (String) -> Unit): () -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val latest = androidx.compose.runtime.rememberUpdatedState(onResult)
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
    ) { r ->
        val text = r.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == android.app.Activity.RESULT_OK && !text.isNullOrBlank()) latest.value(text)
    }
    return {
        try {
            launcher.launch(
                android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, prompt),
            )
        } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "No voice recognition app found on this device", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

/** The shared floating-card look: soft shadow, solid surface and a hairline outline. */
@Composable
fun Modifier.floating(radius: Dp = 24.dp): Modifier {
    val c = LocalVw.current
    val shape = RoundedCornerShape(radius)
    return this.shadow(10.dp, shape).clip(shape).background(c.surface.copy(alpha = 0.97f)).border(1.dp, c.line.copy(alpha = 0.5f), shape)
}
