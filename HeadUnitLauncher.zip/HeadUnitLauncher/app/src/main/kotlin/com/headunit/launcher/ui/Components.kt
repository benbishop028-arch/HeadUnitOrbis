package com.headunit.launcher.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.headunit.launcher.MapBinding
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit) {
    val c = LocalVw.current
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(c.surface)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        content = content,
    )
}

@Composable
fun RoundBtn(
    icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier,
    active: Boolean = false, size: Dp = 50.dp, tint: Color? = null,
) {
    val c = LocalVw.current
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) c.accent else c.surface.copy(alpha = 0.94f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint ?: if (active) Color.White else c.text, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Pill(
    text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier,
) {
    val c = LocalVw.current
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) c.accent else c.surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun MapHost(map: MapBinding, modifier: Modifier = Modifier, cornerDp: Int = 0) {
    val dens by androidx.compose.runtime.rememberUpdatedState(androidx.compose.ui.platform.LocalDensity.current.density)
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FrameLayout(ctx).apply {
                if (cornerDp > 0) {
                                        outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, cornerDp * dens)
                        }
                    }
                    clipToOutline = true
                }
                (map.mapView.parent as? ViewGroup)?.removeView(map.mapView)
                addView(map.mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        },
        update = { it.invalidateOutline() },
        onRelease = { it.removeAllViews() },
    )
}

/** Turn arrow drawn from the manoeuvre name (no image assets needed). */
@Composable
fun ManeuverArrow(maneuver: String, angle: Float, modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier) {
        val s = size.minDimension / 48f
        val sw = 5f * s
        val u = maneuver.uppercase()
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        if (u.startsWith("ARRIVE")) {
            val flag = Path().apply { moveTo(14 * s, 42 * s); lineTo(14 * s, 6 * s) }
            drawPath(flag, color, style = stroke)
            val f = Path().apply { moveTo(14 * s, 8 * s); lineTo(38 * s, 8 * s); lineTo(32 * s, 16 * s); lineTo(38 * s, 24 * s); lineTo(14 * s, 24 * s); close() }
            drawPath(f, color)
            return@Canvas
        }
        if (u == "MAKE_UTURN" || u == "ROUNDABOUT_BACK") {
            val path = Path().apply {
                moveTo(32 * s, 44 * s); lineTo(32 * s, 20 * s)
                arcTo(Rect(Offset(16 * s, 8 * s), Size(16 * s, 24 * s)), 0f, -180f, false)
                lineTo(16 * s, 30 * s)
            }
            drawPath(path, color, style = stroke)
            val head = Path().apply { moveTo(8 * s, 28 * s); lineTo(24 * s, 28 * s); lineTo(16 * s, 40 * s); close() }
            drawPath(head, color)
            return@Canvas
        }
        val r = Math.toRadians(angle.toDouble())
        val x1 = 24f; val y1 = 28f; val len = 16f
        val ux = sin(r).toFloat(); val uy = -cos(r).toFloat()
        val x2 = x1 + ux * len; val y2 = y1 + uy * len
        if (u.startsWith("ROUNDABOUT")) drawCircle(color, 6f * s, p(24f, 38f), style = Stroke(width = 3f * s))
        val shaft = Path().apply { moveTo(24 * s, 44 * s); lineTo(x1 * s, y1 * s); lineTo(x2 * s, y2 * s) }
        drawPath(shaft, color, style = stroke)
        val px = -uy; val py = ux
        val hl = 11f; val hw = 9f
        val tip = p(x2 + ux * hl * 0.6f, y2 + uy * hl * 0.6f)
        val b1 = p(x2 - ux * hl * 0.4f + px * hw * 0.55f, y2 - uy * hl * 0.4f + py * hw * 0.55f)
        val b2 = p(x2 - ux * hl * 0.4f - px * hw * 0.55f, y2 - uy * hl * 0.4f - py * hw * 0.55f)
        val head = Path().apply { moveTo(tip.x, tip.y); lineTo(b1.x, b1.y); lineTo(b2.x, b2.y); close() }
        drawPath(head, color)
    }
}

val NoPad = PaddingValues(0.dp)

/** Row of small level dots (seat heat, fan). */
@Composable
fun Dots(level: Int, max: Int, on: Color, off: Color, modifier: Modifier = Modifier, dot: Dp = 4.dp) {
    Row(modifier, horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(3.dp)) {
        for (i in 1..max) Box(Modifier.size(dot).clip(CircleShape).background(if (i <= level) on else off))
    }
}

/** Centre "home" key of the bottom bar: rounded square with a ring, glowing in the ambient colour. */
@Composable
fun HomeKey(glow: Color, line: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
            .drawBehind {
                drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.55f), Color.Transparent)), radius = size.minDimension * 0.9f)
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(30.dp)) {
            drawRoundRect(line, cornerRadius = CornerRadius(8f * density), style = Stroke(width = 2f * density))
            drawCircle(line, size.minDimension * 0.17f, style = Stroke(width = 2f * density))
        }
    }
}

/** Defrost glyphs drawn by hand: window outline with three wavy heat lines. */
@Composable
fun DefrostIcon(front: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(28.dp)) {
        val w = size.width; val h = size.height
        val sw = 2f * density
        val outline = Path().apply {
            if (front) { moveTo(w * 0.05f, h * 0.85f); lineTo(w * 0.22f, h * 0.12f); lineTo(w * 0.78f, h * 0.12f); lineTo(w * 0.95f, h * 0.85f); close() }
            else { moveTo(w * 0.06f, h * 0.2f); lineTo(w * 0.94f, h * 0.2f); lineTo(w * 0.94f, h * 0.8f); lineTo(w * 0.06f, h * 0.8f); close() }
        }
        drawPath(outline, color, style = Stroke(width = sw, join = StrokeJoin.Round))
        for (i in 0..2) {
            val x = w * (0.32f + 0.18f * i)
            val wave = Path().apply {
                moveTo(x, h * 0.7f); cubicTo(x - w * 0.06f, h * 0.55f, x + w * 0.06f, h * 0.45f, x, h * 0.3f)
            }
            drawPath(wave, color, style = Stroke(width = sw * 0.8f, cap = StrokeCap.Round))
        }
    }
}

/** Colourful ring used for "Ambient light". */
@Composable
fun AmbientGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cols = listOf(Color(0xFFFF3B4D), Color(0xFFFFB020), Color(0xFF2BD66B), Color(0xFF2D8CFF), Color(0xFFA855F7))
        val stroke = size.minDimension * 0.2f
        val inset = stroke / 2
        cols.forEachIndexed { i, col ->
            drawArc(col, i * 72f - 90f, 70f, false, topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke), style = Stroke(width = stroke, cap = StrokeCap.Butt))
        }
    }
}
