package com.headunit.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Fix(val pos: LL, val heading: Double, val speed: Double, val alt: Double, val acc: Double = 0.0)
class QuickEta(val name: String, val place: Place, val minutes: Int, val delayMin: Int)
class TurnInfo(val dist: Double, val street: String, val maneuver: String, val thenManeuver: String?, val thenText: String, val lanes: LaneSec? = null)
class IncidentAhead(val label: String, val dist: Double, val delaySec: Int)
class EtaInfo(val arrive: String, val dist: Double, val secs: Double, val delayMin: Int)
private class Snap(val dist: Double, val i: Int, val progress: Double, val pt: LL)

class NavEngine(private val ctx: Context, val prefs: Prefs, val map: MapBinding) : LocationListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ---- observable state ----
    var fix by mutableStateOf<Fix?>(null)
    var routes by mutableStateOf<List<Route>>(emptyList())
    var routeFrac by mutableStateOf(0f)
    var active by mutableIntStateOf(0)
    var dest by mutableStateOf<Place?>(null)
    var turn by mutableStateOf<TurnInfo?>(null)
    var eta by mutableStateOf<EtaInfo?>(null)
    var following by mutableStateOf(true)
    var tilt3d by mutableStateOf(true)
    var simMode by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var previewing by mutableStateOf(false)
    var northUp by mutableStateOf(false)
    var results by mutableStateOf<List<Place>>(emptyList())
    var alternatives by mutableStateOf(false)
    var weather by mutableStateOf<Weather.Now?>(null)
    var zoomOffset by mutableDoubleStateOf(0.0)

    // saved places, departure planner, road info
    val places = PlaceStore(prefs)
    val trips = TripStore(prefs)
    var pendingSave by mutableStateOf<String?>(null)
    var departMin by mutableIntStateOf(0)
    var departAtMs by mutableLongStateOf(0L)
    var speedLimit by mutableStateOf<Double?>(null)     // m/s
    var cameraDist by mutableStateOf<Int?>(null)
    var incidentAhead by mutableStateOf<IncidentAhead?>(null)
    private var incAt = 0L
    private var incMatches: List<Triple<Incident, Double, String>> = emptyList()
    private val incAlerted = HashSet<String>()
    var nearby by mutableStateOf<List<Nearby>>(emptyList())
    var nearbyKind by mutableStateOf<String?>(null)
    var nearbyBusy by mutableStateOf(false)

    // trip computer (real GPS only)
    var tripDist by mutableDoubleStateOf(0.0)
    var tripMax by mutableDoubleStateOf(0.0)
    var tripMoving by mutableDoubleStateOf(0.0)
    var tripStart by mutableStateOf(System.currentTimeMillis())

    // extras
    val habits = HabitStore(prefs)
    val hooks = HookStore(prefs)
    var quickEtas by mutableStateOf<List<QuickEta>>(emptyList())
    var overLimit by mutableStateOf(false)
    var via by mutableStateOf<List<Place>>(emptyList())
    var stopMode by mutableStateOf(false)
    var destRain by mutableStateOf<String?>(null)
    private var quickAt = 0L
    private var lastBeep = 0L
    private var breakNext = 7200L
    private var tripPts = ArrayList<LL>()
    private var awayFromHome = false
    private var homeFiredAt = 0L

    val route: Route? get() = routes.getOrNull(active)
    val imperial: Boolean get() = prefs.s("distunit", if (defaultUnits() == "imperial") "mi" else "km") == "mi"
    val voiceOn: Boolean get() = prefs.b("voice", true)

    private fun defaultUnits() = if (Locale.getDefault().country in setOf("GB", "US", "LR", "MM")) "imperial" else "metric"

    val apiKey: String
        get() = prefs.s("apikey", "").ifBlank { BuildConfig.TOMTOM_API_KEY }.trim()
    val hasKey: Boolean get() = apiKey.isNotEmpty() && !apiKey.startsWith("YOUR_")

    // ---- internals ----
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val said = HashSet<String>()
    private var lastIdx = 0
    private var offCount = 0
    private var lastReroute = 0L
    private var lastDraw = 0L
    private var simJob: Job? = null
    private var simDist = 0.0
    private var lastRaw: LL? = null
    private var lastGpsTime = 0L
    private var msgToken = 0
    private var lm: LocationManager? = null
    private var weatherAt = 0L
    private var limitAt = 0L
    private var limitPos: LL? = null
    private var camAt = 0L
    private var camPos: LL? = null
    private var cameras: List<LL> = emptyList()
    private val camAlerted = HashSet<LL>()
    private var drove = false
    private var stillSince = 0L
    private var posSavedAt = 0L
    private var tripOn = false
    private var tripT0 = 0L
    private var tripDistance = 0.0
    private var tripMoveSec = 0L
    private var tripTop = 0.0
    private var tripLast: LL? = null
    private var tripDest = ""

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.getDefault()
            }
        }
        map.onLongPress = { p -> startRoute(Place("Dropped pin", "", p)) }
        map.onUserGesture = { if (following) { following = false } }
        map.onError = { msg -> if (hasKey) toast("Map: $msg") else toast("No TomTom key: using the free OpenStreetMap style") }
    }

    fun shutdown() {
        stopLocation(); simJob?.cancel(); tts?.shutdown()
    }

    fun toast(msg: String, ms: Long = 4000) {
        message = msg
        val token = ++msgToken
        scope.launch { delay(ms); if (token == msgToken) message = null }
    }

    // ---- style ----
    fun styleUrl(dark: Boolean): String {
        val traffic = prefs.b("traffic", true)
        return if (hasKey && prefs.s("mapstyle", "tomtom") == "tomtom") TomTomRest.styleUrl(apiKey, dark, traffic)
        else if (dark) "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json"
        else "https://tiles.openfreemap.org/styles/liberty"
    }

    fun applyStyle(dark: Boolean) = map.setStyleUrl(styleUrl(dark))

    // ---- location ----
    @SuppressLint("MissingPermission")
    fun startLocation() {
        if (lm != null) return
        val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = m
        try {
            if (m.allProviders.contains(LocationManager.GPS_PROVIDER))
                m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            if (m.allProviders.contains(LocationManager.NETWORK_PROVIDER))
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this, Looper.getMainLooper())
            (m.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: m.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))
                ?.let { handleLocation(it, true) }
        } catch (e: SecurityException) {
            lm = null
            toast("Location permission is needed for navigation")
        } catch (e: Exception) {
            lm = null
            android.util.Log.w("NavEngine", "startLocation failed", e)
        }
    }

    fun stopLocation() {
        try { lm?.removeUpdates(this) } catch (_: Exception) {}
        lm = null
    }

    override fun onLocationChanged(l: Location) = handleLocation(l, false)

    private fun handleLocation(l: Location, first: Boolean) {
        try { handleLocationInner(l, first) } catch (e: Exception) { android.util.Log.w("NavEngine", "location handling failed", e) }
    }

    private fun handleLocationInner(l: Location, first: Boolean) {
        run {
            val t = System.currentTimeMillis()
            if (t - posSavedAt > 600_000) {
                posSavedAt = t
                prefs.put("lastlat", Math.round(l.latitude * 10) / 10.0)
                prefs.put("lastlon", Math.round(l.longitude * 10) / 10.0)
            }
        }
        if (simMode != 0) return
        val now = System.currentTimeMillis()
        if (l.provider == LocationManager.GPS_PROVIDER) lastGpsTime = now
        else if (now - lastGpsTime < 10000) return
        val cur = LL(l.latitude, l.longitude)
        var h = fix?.heading ?: 0.0
        if (l.hasBearing() && l.hasSpeed() && l.speed > 1.0f) h = l.bearing.toDouble()
        else lastRaw?.let { if (Geo.dist(it, cur) > 6) h = Geo.bearing(it, cur) }
        val prev = lastRaw
        if (prev == null || Geo.dist(prev, cur) > 6) lastRaw = cur
        val speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0
        if (prev != null && speed > 0.8) {
            val d = Geo.dist(prev, cur)
            if (d in 3.0..200.0) { tripDist += d; tripMoving += 1.0 }
        }
        if (speed > tripMax) tripMax = speed
        val firstFix = fix == null
        onPosition(Fix(cur, h, speed, if (l.hasAltitude()) l.altitude else 0.0, if (l.hasAccuracy()) l.accuracy.toDouble() else 0.0), firstFix || first)
        try { extrasTick(cur, now) } catch (e: Exception) { }
        if (firstFix) {
            map.cameraTo(cur, null, if (tilt3d) 55.0 else 0.0, 15.5, 0, 0.0)
        }
        if (now - weatherAt > 20 * 60 * 1000L) {
            weatherAt = now
            scope.launch { weather = withContext(Dispatchers.IO) { Weather.fetch(cur) } ?: weather }
        }
    }

    // ---- extras: journey times, rain at destination, stops, arriving home ----
    private fun loadRain(to: Place, routeSecs: Double) {
        destRain = null
        scope.launch {
            val f = withContext(Dispatchers.IO) { Weather.forecast(to.pos) } ?: return@launch
            val idx = Math.round(routeSecs / 3600.0).toInt().coerceIn(0, f.hours.size - 1)
            val h = f.hours.getOrNull(idx) ?: return@launch
            val wet = h.code in 51..67 || h.code in 80..82 || h.code in 95..99
            val snow = h.code in 71..77 || h.code in 85..86
            if (h.rain >= 50 || wet || snow) destRain = (if (snow) "Snow" else "Rain") + " likely at arrival (${h.rain}%)"
        }
    }

    fun addStop(p: Place) {
        val d = dest ?: return
        via = via + p
        stopMode = false
        clearNearby()
        toast("Stop added: ${p.name}", 2500)
        startRoute(d, departMin, true)
    }

    private fun extrasTick(cur: LL, now: Long) {
        // journey times to Home / Work (every 5 min, only when not already navigating)
        if (now - quickAt > 300_000 && route == null && hasKey) {
            quickAt = now
            val targets = listOfNotNull(places.slot("home")?.let { "Home" to it }, places.slot("work")?.let { "Work" to it })
                .filter { Geo.dist(cur, it.second.pos) > 400 }
            if (targets.isEmpty()) quickEtas = emptyList()
            else scope.launch {
                val out = ArrayList<QuickEta>()
                for ((n, pl) in targets) {
                    try {
                        val r = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, cur, pl.pos, false) }.firstOrNull() ?: continue
                        out += QuickEta(n, pl, Math.round(r.time / 60.0).toInt(), Math.round(r.delay / 60.0).toInt())
                    } catch (e: Exception) { }
                }
                quickEtas = out
            }
        }
        // arriving home: fire a webhook once when you get back
        val home = places.slot("home")
        if (home != null) {
            val d = Geo.dist(cur, home.pos)
            if (d > 1500) awayFromHome = true
            else if (d < 200 && awayFromHome && now - homeFiredAt > 3_600_000) {
                awayFromHome = false; homeFiredAt = now
                val idx = prefs.s("homehook", "-1").toIntOrNull() ?: -1
                val h = hooks.all().getOrNull(idx)
                if (h != null) scope.launch {
                    val ok = withContext(Dispatchers.IO) { hooks.fire(h) }
                    toast(if (ok) "${h.name}: done" else "${h.name}: failed", 3000)
                }
            }
        }
    }

    fun resetTrip() { tripDist = 0.0; tripMax = 0.0; tripMoving = 0.0; tripStart = System.currentTimeMillis() }

    // ---- search + routing ----
    fun search(q: String) {
        if (q.length < 2) { results = emptyList(); return }
        if (!hasKey) { toast("Search needs a TomTom API key (Settings)"); return }
        val near = fix?.pos ?: map.center()
        scope.launch {
            try {
                results = withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, q, near) }
                if (results.isEmpty()) toast("No matches. Try adding a town or postcode.")
            } catch (e: Exception) { toast("Search failed: ${e.message}", 6000) }
        }
    }

    fun pickPlace(p: Place) {
        val slot = pendingSave
        if (slot != null) {
            places.setSlot(slot, p)
            pendingSave = null
            results = emptyList()
            toast("${if (slot == "home") "Home" else "Work"} saved: ${p.name}", 3500)
        } else startRoute(p)
    }

    fun setDeparture(minutes: Int) {
        val d = dest ?: return
        startRoute(d, minutes, true)
    }

    fun startRoute(to: Place, departInMin: Int = 0, keepVia: Boolean = false) {
        if (!keepVia) via = emptyList()
        if (!hasKey) { toast("Routing needs a TomTom API key (Settings)"); return }
        val from = fix?.pos ?: map.center() ?: return
        if (fix == null) toast("No GPS fix yet: routing from the map centre. Use the demo drive to simulate.", 5000)
        busy = true
        scope.launch {
            try {
                val departMs = if (departInMin > 0) System.currentTimeMillis() + departInMin * 60_000L else 0L
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, from, to.pos, true, departMs, via.map { it.pos }) }
                if (rs.isEmpty()) throw IllegalStateException("No route found")
                if (departInMin > 0 && !TomTomRest.departApplied) toast("Departure time not supported here: showing live traffic", 4000)
                departMin = departInMin
                departAtMs = if (TomTomRest.departApplied) departMs else 0L
                if (to.name != "Dropped pin") places.addRecent(to)
                if (!keepVia) habits.record(to)
                loadRain(to, rs[0].time)
                clearNearby()
                results = emptyList()
                stopSim()
                dest = to; routes = rs; active = 0
                said.clear(); offCount = 0; lastIdx = 0
                turn = null; eta = null; routeFrac = 0f
                map.setDest(to.pos)
                drawRoutes()
                following = false
                previewing = true
                val allPts = rs.take(3).flatMap { r -> r.pts.filterIndexed { i, _ -> i % 8 == 0 } + r.pts.last() }
                delay(350)
                map.fit(allPts)
            } catch (e: Exception) {
                toast("Route failed: ${e.message}", 6000)
            } finally { busy = false }
        }
    }

    fun selectRoute(i: Int) {
        if (i !in routes.indices) return
        active = i; lastIdx = 0
        drawRoutes()
        val r = routes[i]
        map.fit(r.pts.filterIndexed { n, _ -> n % 6 == 0 } + r.pts.last())
    }

    fun beginNavigation() {
        if (!previewing) return
        previewing = false
        said.clear(); lastIdx = 0; zoomOffset = 0.0
        following = true
        val f = fix
        if (f != null) onPosition(f, true)
        else { updateGuidance(0.0); toast("No GPS fix yet. Use the play button for a demo drive.", 5000) }
    }

    private fun drawRoutes() {
        val r = route ?: return
        map.setRoute(r.pts, routes.filterIndexed { i, _ -> i != active }.map { it.pts })
    }

    fun cycleRoute() {
        if (routes.size < 2) { toast("No alternative routes. Switch on 'Alternatives' first."); return }
        active = (active + 1) % routes.size
        said.clear(); lastIdx = 0
        drawRoutes()
        fix?.let { onPosition(it, true) } ?: updateGuidance(0.0)
    }

    fun toggleAlternatives() {
        alternatives = !alternatives
        toast(if (alternatives) "Alternative routes on" else "Alternative routes off", 2500)
        val d = dest
        if (d != null) startRoute(d, 0, true)
    }

    private fun reroute() {
        val d = dest ?: return
        val f = fix ?: return
        if (System.currentTimeMillis() - lastReroute < 10000) return
        lastReroute = System.currentTimeMillis()
        toast("Rerouting…", 2000)
        scope.launch {
            try {
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, f.pos, d.pos, false, 0L, via.map { it.pos }) }
                if (rs.isNotEmpty()) { routes = rs; active = 0; said.clear(); offCount = 0; lastIdx = 0; drawRoutes() }
            } catch (e: Exception) { toast("Reroute failed: ${e.message}", 4000) }
        }
    }

    fun endRoute() {
        incMatches = emptyList(); incidentAhead = null; incAt = 0L; incAlerted.clear()
        via = emptyList(); stopMode = false; destRain = null
        routes = emptyList(); active = 0; dest = null; turn = null; eta = null; lastIdx = 0; previewing = false; routeFrac = 0f
        departMin = 0; departAtMs = 0L
        map.setRoute(emptyList(), emptyList()); map.setDest(null)
        stopSim()
        tts?.stop()
        map.setTilt(if (tilt3d) 55.0 else 0.0)
    }

    // ---- camera controls ----
    fun recenter() {
        following = true
        zoomOffset = 0.0
        val f = fix
        if (f != null) onPosition(f, true) else toast("No GPS fix yet")
    }

    fun toggleNorthUp() {
        northUp = !northUp
        if (northUp) map.resetNorth() else fix?.let { onPosition(it, true) }
    }

    fun toggleTilt() {
        tilt3d = !tilt3d
        map.setTilt(if (tilt3d) 55.0 else 0.0)
    }

    fun zoom(delta: Double) {
        if (following && fix != null) { zoomOffset = (zoomOffset + delta).coerceIn(-4.0, 3.0); fix?.let { onPosition(it, true) } }
        else map.zoomBy(delta)
    }


    // ---- speed limit, speed cameras, parked car (real GPS + OpenStreetMap) ----
    private fun updateRoadInfo(p: Fix) {
        val now = System.currentTimeMillis()
        run {
            val lim = speedLimit
            val tolUnits = prefs.s("warntol", "5").toIntOrNull() ?: 5
            val tol = tolUnits * (if (imperial) 0.44704 else 0.27778)
            val over = prefs.b("speedwarn", true) && lim != null && p.speed > lim + tol && p.speed > 4.0
            overLimit = over
            if (over && now - lastBeep > 9000) {
                lastBeep = now
                try { android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 80).startTone(android.media.ToneGenerator.TONE_PROP_BEEP2, 250) } catch (e: Exception) { }
            }
        }
        val lp = limitPos
        if (now - limitAt > 12000 && (lp == null || Geo.dist(lp, p.pos) > 40) && (p.speed > 0.5 || lp == null)) {
            limitAt = now; limitPos = p.pos
            scope.launch { speedLimit = withContext(Dispatchers.IO) { Overpass.speedLimit(p.pos) } }
        }
        if (!prefs.b("cameras", true)) { cameraDist = null; return }
        val cp = camPos
        if (now - camAt > 120000 && (cp == null || Geo.dist(cp, p.pos) > 1500)) {
            camAt = now; camPos = p.pos
            scope.launch { cameras = withContext(Dispatchers.IO) { Overpass.cameras(p.pos, 3000) } }
        }
        var best: LL? = null
        var bestD = 1e9
        if (p.speed > 4.0) {
            for (c in cameras) {
                val d = Geo.dist(p.pos, c)
                if (d > 450 || d >= bestD) continue
                val diff = abs(((Geo.bearing(p.pos, c) - p.heading + 540.0) % 360.0) - 180.0)
                if (diff < 45) { best = c; bestD = d }
            }
        }
        cameraDist = if (best != null) bestD.toInt() else null
        if (best != null) {
            if (camAlerted.size > 100) camAlerted.clear()
            if (camAlerted.add(best)) { toast("Speed camera ahead", 4000); speak("Speed camera ahead") }
        }
    }

    private fun trackParking(p: Fix) {
        if (simMode != 0) return
        val now = System.currentTimeMillis()
        // ---- trip recording ----
        if (tripOn) {
            val last = tripLast
            if (last != null) {
                val d = Geo.dist(last, p.pos)
                if (d in 2.0..250.0) tripDistance += d
            }
            tripLast = p.pos
            if (p.speed > 1.0) tripMoveSec += 1
            if (p.speed > tripTop) tripTop = p.speed
            val lp = tripPts.lastOrNull()
            if ((lp == null || Geo.dist(lp, p.pos) > 80) && tripPts.size < 3000) tripPts.add(p.pos)
            if (tripMoveSec >= breakNext && prefs.b("breakremind", true)) {
                val hrs = breakNext / 3600
                breakNext += 7200
                toast("You have been driving for $hrs hours. Time for a break?", 8000)
                speak("You have been driving for $hrs hours. Consider taking a break.")
                if (route == null) loadNearby("fuel", false)
            }
        } else if (p.speed > 3.0) {
            tripOn = true; tripT0 = now; tripDistance = 0.0; tripMoveSec = 0; tripTop = p.speed; tripLast = p.pos
            breakNext = 7200L; tripPts = arrayListOf(p.pos)
        }
        // ---- parked car + end of trip ----
        if (p.speed > 4.0) { drove = true; stillSince = 0L }
        else if (p.speed < 0.8 && drove) {
            if (stillSince == 0L) stillSince = now
            else if (now - stillSince > 120_000) {
                if (tripOn && tripDistance > 300) {
                    trips.add(Trip(tripT0, stillSince, tripDistance, tripMoveSec, tripTop, tripDest))
                    Tracks.append(ctx, tripPts)
                    Milestones.check(prefs, trips.all().sumOf { it.dist } / 1000.0)?.let { toast(it, 6000) }
                }
                tripOn = false
                drove = false; stillSince = 0L
                places.setParked(Place("My car", "Parked here", p.pos))
                toast("Parked location saved", 3000)
            }
        }
        if (dest != null) tripDest = dest?.name.orEmpty()
    }

    /** Finds [q] and starts routing there (used for calendar appointments). */
    fun routeToText(q: String, then: () -> Unit) {
        if (!hasKey) { toast("Search needs a TomTom API key (Settings)"); return }
        scope.launch {
            try {
                val p = withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, q, fix?.pos ?: map.center()) }.firstOrNull()
                if (p == null) toast("Could not find \"$q\"", 3500) else { then(); startRoute(p) }
            } catch (e: Exception) { toast("Search failed: ${e.message}", 4000) }
        }
    }

    /** Finds a place by text and returns it with the driving time in minutes from here. */
    suspend fun travelTo(q: String): Pair<Place, Int>? = withContext(Dispatchers.IO) {
        try {
            val from = fix?.pos ?: return@withContext null
            val pl = TomTomRest.geocode(apiKey, q, from).firstOrNull() ?: return@withContext null
            val r = TomTomRest.routes(apiKey, from, pl.pos, false).firstOrNull() ?: return@withContext null
            Pair(pl, Math.round(r.time / 60.0).toInt())
        } catch (e: Exception) { null }
    }

    fun parkHere() {
        val f = fix ?: run { toast("No GPS fix yet"); return }
        places.setParked(Place("My car", "Parked here", f.pos))
        toast("Parked location saved", 3000)
    }

    // ---- nearby fuel / charging / parking ----
    fun clearNearby() { nearby = emptyList(); nearbyKind = null; nearbyBusy = false; stopMode = false }

    private fun distToRoute(r: Route, p: LL): Double {
        var best = 1e9
        var i = lastIdx.coerceIn(0, max(0, r.pts.size - 1))
        while (i < r.pts.size) { best = min(best, Geo.dist(r.pts[i], p)); i += 3 }
        return best
    }

    fun loadNearby(kind: String, nearDest: Boolean) {
        val centre = (if (nearDest) dest?.pos else null) ?: fix?.pos ?: map.center() ?: run { toast("No position yet"); return }
        val origin = fix?.pos ?: centre
        val rt = route
        val alongRoute = rt != null && !nearDest && kind != "parking"
        val radius = if (nearDest) 900 else if (alongRoute) 12000 else if (kind == "parking") 2000 else 6000
        nearbyKind = kind; nearbyBusy = true; nearby = emptyList()
        scope.launch {
            try {
                val raw = withContext(Dispatchers.IO) { Overpass.nearby(kind, centre, radius) }
                val kept = if (alongRoute && rt != null) raw.filter { distToRoute(rt, it.place.pos) < 1500 } else raw
                nearby = kept.map { it.copy(dist = Geo.dist(origin, it.place.pos)) }.sortedBy { it.dist }.take(12)
                if (nearby.isEmpty()) toast("Nothing found nearby", 3000)
            } catch (e: Exception) { toast("Search failed: ${e.message}", 4000) }
            finally { nearbyBusy = false }
        }
    }

    // ---- guidance ----
    private fun snap(r: Route, p: LL): Snap {
        val pts = r.pts
        var bd = 1e12; var bi = 0; var bt = 0.0
        val k = cos(Geo.rad(p.lat)) * 111320.0
        val k2 = 110574.0
        fun scan(a: Int, b: Int) {
            for (i in a until min(b, pts.size - 1)) {
                val ax = (pts[i].lon - p.lon) * k; val ay = (pts[i].lat - p.lat) * k2
                val bx = (pts[i + 1].lon - p.lon) * k; val by = (pts[i + 1].lat - p.lat) * k2
                val dx = bx - ax; val dy = by - ay
                val l2 = dx * dx + dy * dy
                var t = if (l2 > 0) -(ax * dx + ay * dy) / l2 else 0.0
                t = t.coerceIn(0.0, 1.0)
                val d = hypot(ax + dx * t, ay + dy * t)
                if (d < bd) { bd = d; bi = i; bt = t }
            }
        }
        scan(max(0, lastIdx - 20), lastIdx + 500)
        if (bd > 60) scan(0, pts.size)
        lastIdx = bi
        val seg = r.cum[bi + 1] - r.cum[bi]
        val a = pts[bi]; val b = pts[bi + 1]
        return Snap(bd, bi, r.cum[bi] + bt * seg, LL(a.lat + (b.lat - a.lat) * bt, a.lon + (b.lon - a.lon) * bt))
    }

    private fun onPosition(p: Fix, force: Boolean) {
        fix = p
        try { updateRoadInfo(p); trackParking(p) } catch (e: Exception) { android.util.Log.w("NavEngine", "road info failed", e) }
        map.setMe(p.pos, p.heading)
        if (previewing) return
        val r = route
        if (r == null || r.pts.size < 2) {
            if (following) followCamera(p, false)
            return
        }
        val s = snap(r, p.pos)
        if (s.dist > 70) { if (++offCount >= 4) reroute() } else offCount = 0
        val now = System.currentTimeMillis()
        if (force || now - lastDraw > 1500) {
            lastDraw = now
            map.setMainOnly(listOf(s.pt) + r.pts.subList(s.i + 1, r.pts.size))
        }
        updateGuidance(s.progress)
        if (following) followCamera(p, true)
    }

    /** Zoom that adapts: closer when a turn is near or the destination is close, wider on fast roads with a long way to go. */
    private fun autoZoom(sp: Double, navigating: Boolean): Double {
        var z = if (sp < 6) 17.3 else if (sp < 14) 16.6 else if (sp < 24) 15.9 else if (sp < 31) 15.2 else 14.6
        if (navigating) {
            val t = turn
            if (t != null) {
                val near = ((700.0 - t.dist) / 700.0).coerceIn(0.0, 1.0)     // 1 = at the turn
                z += 1.1 * near
                if (sp > 18) z -= 0.7 * ((t.dist - 2500.0) / 2500.0).coerceIn(0.0, 1.0)   // long straight stretch
            }
            val e = eta
            if (e != null && e.dist < 500) z = max(z, 17.6)
        }
        return z.coerceIn(13.5, 18.0)
    }

    private fun followCamera(p: Fix, navigating: Boolean) {
        val sp = p.speed
        val bearing = if (northUp) 0.0 else if (navigating || sp > 2.0) p.heading else null
        val pad = if (tilt3d && (navigating || sp > 2.0)) 0.36 else 0.0
        map.cameraTo(p.pos, bearing, if (tilt3d) 60.0 else 0.0, autoZoom(sp, navigating) + zoomOffset, 1000, pad)
    }

    private fun incidentLabel(i: Incident): String = when (i.cat) {
        "roadWorks" -> "Roadworks"; "roadClosed" -> "Road closed"; "accident" -> "Accident"
        "jam" -> "Traffic jam"; "laneClosed" -> "Lane closed"; "danger" -> "Hazard"
        else -> i.text.ifBlank { "Incident" }
    }

    private fun checkIncidents(r: Route, progress: Double) {
        if (!hasKey || simMode != 0 || !prefs.b("incidents", true)) { incidentAhead = null; return }
        val now = System.currentTimeMillis()
        if (now - incAt > 180_000) {
            incAt = now
            scope.launch {
                val found = withContext(Dispatchers.IO) {
                    try {
                        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
                        var any = false
                        for (n in r.pts.indices) {
                            if (r.cum[n] < progress - 200 || r.cum[n] > progress + 40_000) continue
                            val q = r.pts[n]; any = true
                            minLat = min(minLat, q.lat); maxLat = max(maxLat, q.lat); minLon = min(minLon, q.lon); maxLon = max(maxLon, q.lon)
                        }
                        if (!any) emptyList() else {
                            val list = TomTomRest.incidents(apiKey, minLon - 0.01, minLat - 0.01, maxLon + 0.01, maxLat + 0.01)
                            val out = ArrayList<Triple<Incident, Double, String>>()
                            for (inc in list) {
                                var bestOff = -1.0; var bestD = 70.0
                                val q = inc.pts.first()
                                for (n in r.pts.indices) {
                                    if (r.cum[n] < progress - 200 || r.cum[n] > progress + 40_000) continue
                                    val d = Geo.dist(r.pts[n], q)
                                    if (d < bestD) { bestD = d; bestOff = r.cum[n] }
                                }
                                if (bestOff >= 0) out += Triple(inc, bestOff, incidentLabel(inc))
                            }
                            out
                        }
                    } catch (e: Exception) { null }
                }
                if (found != null) incMatches = found
            }
        }
        val next = incMatches.filter { it.second > progress - 30 }.minByOrNull { it.second }
        if (next == null) { incidentAhead = null; return }
        val d = max(0.0, next.second - progress)
        if (d > 15_000) { incidentAhead = null; return }
        incidentAhead = IncidentAhead(next.third, d, next.first.delaySec)
        if (d < 8000 && incAlerted.add(next.first.id)) {
            val mins = next.first.delaySec / 60
            val extra = if (mins >= 2) ", about $mins minutes delay" else ""
            toast("${next.third} ahead, ${Geo.fmtDist(d, imperial)}$extra", 6000)
            speak("${next.third} ahead in ${Geo.spoken(d, imperial)}$extra")
        }
    }

    private fun updateGuidance(progress: Double) {
        val r = route ?: return
        try { checkIncidents(r, progress) } catch (e: Exception) { }
        fix?.let { f -> if (via.isNotEmpty() && Geo.dist(f.pos, via[0].pos) < 80) { toast("Stop reached: ${via[0].name}", 3000); via = via.drop(1) } }
        val rem = max(0.0, r.len - progress)
        val frac = if (r.len > 0) rem / r.len else 0.0
        val secs = r.time * frac
        val delayMin = Math.round(r.delay * frac / 60.0).toInt()
        val arrive = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (secs * 1000).toLong()))
        eta = EtaInfo(arrive, rem, secs, delayMin)
        routeFrac = (1.0 - frac).toFloat().coerceIn(0f, 1f)

        val ins = r.steps
        var k = ins.indexOfFirst { it.off > progress + 8 }
        if (k < 0) k = ins.size - 1
        if (k >= 0) {
            val cur = ins[k]
            val d = max(0.0, cur.off - progress)
            val arriving = cur.maneuver.uppercase().startsWith("ARRIVE")
            val nxt = ins.getOrNull(k + 1)
            val street = if (arriving) (dest?.name ?: "Destination") else cur.street.ifBlank { cur.msg.ifBlank { Geo.maneuverText(cur.maneuver) } }
            turn = TurnInfo(
                d, street, cur.maneuver, nxt?.maneuver,
                if (nxt != null) "Then " + Geo.maneuverText(nxt.maneuver) + (if (nxt.street.isNotBlank()) " onto ${nxt.street}" else "") else "",
                if (d < 1000 && !arriving) r.lanes.firstOrNull { progress < it.end + 5 && abs(it.end - cur.off) < 90 } else null,
            )
            val word = Geo.maneuverText(cur.maneuver)
            val tail = if (arriving || cur.street.isBlank()) "" else " onto ${cur.street}"
            if (d <= 520 && d > 200 && said.add("${k}f"))
                speak(if (arriving) "In ${Geo.spoken(d, imperial)}, you will arrive" else "In ${Geo.spoken(d, imperial)}, $word$tail")
            if (d <= 120 && said.add("${k}n"))
                speak(if (arriving) "You have arrived" else word.replaceFirstChar { it.uppercase() } + tail)
        }
        if (rem < 25 && said.add("end")) {
            toast("You have arrived", 5000)
            scope.launch { delay(4000); endRoute() }
        }
    }

    fun speakForce(text: String) {
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "read")
    }

    fun speak(text: String) {
        if (!voiceOn || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
    }

    // ---- demo drive ----
    fun cycleSim() {
        val r = route
        if (r == null) { toast("Pick a destination first, then start the demo drive"); return }
        when (simMode) {
            0 -> { simMode = 1; startSim(r) }
            1 -> simMode = 4
            else -> stopSim()
        }
    }

    private fun startSim(r: Route) {
        simJob?.cancel()
        simDist = fix?.let { snap(r, it.pos).progress } ?: 0.0
        following = true
        simJob = scope.launch {
            while (true) {
                val cur = route ?: break
                simDist = min(cur.len, simDist + 16.0 * simMode)
                val (pt, hd) = pointAt(cur, simDist)
                val td = turn?.dist ?: 1000.0
                val demoSpeed = if (td < 150) 7.0 else if (td < 400) 13.0 else if (td < 1200) 20.0 else 27.0
                onPosition(Fix(pt, hd, demoSpeed, 0.0), false)
                if (simDist >= cur.len) break
                delay(1000)
            }
            simMode = 0
        }
    }

    fun stopSim() { simJob?.cancel(); simJob = null; simMode = 0 }

    private fun pointAt(r: Route, d: Double): Pair<LL, Double> {
        val c = r.cum
        var lo = 0; var hi = c.size - 1
        while (lo < hi - 1) { val m = (lo + hi) ushr 1; if (c[m] <= d) lo = m else hi = m }
        val seg = (c[hi] - c[lo]).takeIf { it > 0 } ?: 1.0
        val t = ((d - c[lo]) / seg).coerceIn(0.0, 1.0)
        val a = r.pts[lo]; val b = r.pts[hi]
        return Pair(LL(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t), Geo.bearing(a, b))
    }
}
