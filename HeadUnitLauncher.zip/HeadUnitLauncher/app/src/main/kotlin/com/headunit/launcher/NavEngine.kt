package com.headunit.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Fix(val pos: LL, val heading: Double, val speed: Double, val alt: Double)
class TurnInfo(val dist: Double, val street: String, val maneuver: String, val thenManeuver: String?, val thenText: String)
class EtaInfo(val arrive: String, val dist: Double, val secs: Double, val delayMin: Int)
private class Snap(val dist: Double, val i: Int, val progress: Double, val pt: LL)

class NavEngine(private val ctx: Context, val prefs: Prefs, val map: MapBinding) : LocationListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ---- observable state ----
    var fix by mutableStateOf<Fix?>(null)
    var routes by mutableStateOf<List<Route>>(emptyList())
    var routeFrac by mutableStateOf(0f)
    var active by mutableIntStateOf(0)
    var dest by mutableStateOf<Place?>(null)
    var turn by mutableStateOf<TurnInfo?>(null)
    var eta by mutableStateOf<EtaInfo?>(null)
    var following by mutableStateOf(true)
    var tilt3d by mutableStateOf(true)
    var simMode by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var previewing by mutableStateOf(false)
    var northUp by mutableStateOf(false)
    var results by mutableStateOf<List<Place>>(emptyList())
    var alternatives by mutableStateOf(false)
    var weather by mutableStateOf<Weather.Now?>(null)
    var zoomOffset by mutableDoubleStateOf(0.0)

    // trip computer (real GPS only)
    var tripDist by mutableDoubleStateOf(0.0)
    var tripMax by mutableDoubleStateOf(0.0)
    var tripMoving by mutableDoubleStateOf(0.0)
    var tripStart by mutableStateOf(System.currentTimeMillis())

    val route: Route? get() = routes.getOrNull(active)
    val imperial: Boolean get() = prefs.s("distunit", if (defaultUnits() == "imperial") "mi" else "km") == "mi"
    val voiceOn: Boolean get() = prefs.b("voice", true)

    private fun defaultUnits() = if (Locale.getDefault().country in setOf("GB", "US", "LR", "MM")) "imperial" else "metric"

    val apiKey: String
        get() = prefs.s("apikey", "").ifBlank { BuildConfig.TOMTOM_API_KEY }.trim()
    val hasKey: Boolean get() = apiKey.isNotEmpty() && !apiKey.startsWith("YOUR_")

    // ---- internals ----
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val said = HashSet<String>()
    private var lastIdx = 0
    private var offCount = 0
    private var lastReroute = 0L
    private var lastDraw = 0L
    private var simJob: Job? = null
    private var simDist = 0.0
    private var lastRaw: LL? = null
    private var lastGpsTime = 0L
    private var msgToken = 0
    private var lm: LocationManager? = null
    private var weatherAt = 0L

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.getDefault()
            }
        }
        map.onLongPress = { p -> startRoute(Place("Dropped pin", "", p)) }
        map.onUserGesture = { if (following) { following = false } }
        map.onError = { msg -> if (hasKey) toast("Map: $msg") else toast("No TomTom key: using the free OpenStreetMap style") }
    }

    fun shutdown() {
        stopLocation(); simJob?.cancel(); tts?.shutdown()
    }

    fun toast(msg: String, ms: Long = 4000) {
        message = msg
        val token = ++msgToken
        scope.launch { delay(ms); if (token == msgToken) message = null }
    }

    // ---- style ----
    fun styleUrl(dark: Boolean): String {
        val traffic = prefs.b("traffic", true)
        return if (hasKey && prefs.s("mapstyle", "tomtom") == "tomtom") TomTomRest.styleUrl(apiKey, dark, traffic)
        else if (dark) "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json"
        else "https://tiles.openfreemap.org/styles/liberty"
    }

    fun applyStyle(dark: Boolean) = map.setStyleUrl(styleUrl(dark))

    // ---- location ----
    @SuppressLint("MissingPermission")
    fun startLocation() {
        if (lm != null) return
        val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = m
        try {
            if (m.allProviders.contains(LocationManager.GPS_PROVIDER))
                m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            if (m.allProviders.contains(LocationManager.NETWORK_PROVIDER))
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this, Looper.getMainLooper())
            (m.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: m.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))
                ?.let { handleLocation(it, true) }
        } catch (e: SecurityException) {
            lm = null
            toast("Location permission is needed for navigation")
        } catch (e: Exception) {
            lm = null
            android.util.Log.w("NavEngine", "startLocation failed", e)
        }
    }

    fun stopLocation() {
        try { lm?.removeUpdates(this) } catch (_: Exception) {}
        lm = null
    }

    override fun onLocationChanged(l: Location) = handleLocation(l, false)

    private fun handleLocation(l: Location, first: Boolean) {
        try { handleLocationInner(l, first) } catch (e: Exception) { android.util.Log.w("NavEngine", "location handling failed", e) }
    }

    private fun handleLocationInner(l: Location, first: Boolean) {
        if (simMode != 0) return
        val now = System.currentTimeMillis()
        if (l.provider == LocationManager.GPS_PROVIDER) lastGpsTime = now
        else if (now - lastGpsTime < 10000) return
        val cur = LL(l.latitude, l.longitude)
        var h = fix?.heading ?: 0.0
        if (l.hasBearing() && l.hasSpeed() && l.speed > 1.0f) h = l.bearing.toDouble()
        else lastRaw?.let { if (Geo.dist(it, cur) > 6) h = Geo.bearing(it, cur) }
        val prev = lastRaw
        if (prev == null || Geo.dist(prev, cur) > 6) lastRaw = cur
        val speed = if (l.hasSpeed()) l.speed.toDouble() else 0.0
        if (prev != null && speed > 0.8) {
            val d = Geo.dist(prev, cur)
            if (d in 3.0..200.0) { tripDist += d; tripMoving += 1.0 }
        }
        if (speed > tripMax) tripMax = speed
        val firstFix = fix == null
        onPosition(Fix(cur, h, speed, if (l.hasAltitude()) l.altitude else 0.0), firstFix || first)
        if (firstFix) {
            map.cameraTo(cur, null, if (tilt3d) 55.0 else 0.0, 15.5, 0, 0.0)
        }
        if (now - weatherAt > 20 * 60 * 1000L) {
            weatherAt = now
            scope.launch { weather = withContext(Dispatchers.IO) { Weather.fetch(cur) } ?: weather }
        }
    }

    fun resetTrip() { tripDist = 0.0; tripMax = 0.0; tripMoving = 0.0; tripStart = System.currentTimeMillis() }

    // ---- search + routing ----
    fun search(q: String) {
        if (q.length < 2) { results = emptyList(); return }
        if (!hasKey) { toast("Search needs a TomTom API key (Settings)"); return }
        val near = fix?.pos ?: map.center()
        scope.launch {
            try {
                results = withContext(Dispatchers.IO) { TomTomRest.geocode(apiKey, q, near) }
                if (results.isEmpty()) toast("No matches. Try adding a town or postcode.")
            } catch (e: Exception) { toast("Search failed: ${e.message}", 6000) }
        }
    }

    fun startRoute(to: Place) {
        if (!hasKey) { toast("Routing needs a TomTom API key (Settings)"); return }
        val from = fix?.pos ?: map.center() ?: return
        if (fix == null) toast("No GPS fix yet: routing from the map centre. Use the demo drive to simulate.", 5000)
        busy = true
        scope.launch {
            try {
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, from, to.pos, true) }
                if (rs.isEmpty()) throw IllegalStateException("No route found")
                results = emptyList()
                stopSim()
                dest = to; routes = rs; active = 0
                said.clear(); offCount = 0; lastIdx = 0
                turn = null; eta = null; routeFrac = 0f
                map.setDest(to.pos)
                drawRoutes()
                following = false
                previewing = true
                val allPts = rs.take(3).flatMap { r -> r.pts.filterIndexed { i, _ -> i % 8 == 0 } + r.pts.last() }
                delay(350)
                map.fit(allPts)
            } catch (e: Exception) {
                toast("Route failed: ${e.message}", 6000)
            } finally { busy = false }
        }
    }

    fun selectRoute(i: Int) {
        if (i !in routes.indices) return
        active = i; lastIdx = 0
        drawRoutes()
        val r = routes[i]
        map.fit(r.pts.filterIndexed { n, _ -> n % 6 == 0 } + r.pts.last())
    }

    fun beginNavigation() {
        if (!previewing) return
        previewing = false
        said.clear(); lastIdx = 0; zoomOffset = 0.0
        following = true
        val f = fix
        if (f != null) onPosition(f, true)
        else { updateGuidance(0.0); toast("No GPS fix yet. Use the play button for a demo drive.", 5000) }
    }

    private fun drawRoutes() {
        val r = route ?: return
        map.setRoute(r.pts, routes.filterIndexed { i, _ -> i != active }.map { it.pts })
    }

    fun cycleRoute() {
        if (routes.size < 2) { toast("No alternative routes. Switch on 'Alternatives' first."); return }
        active = (active + 1) % routes.size
        said.clear(); lastIdx = 0
        drawRoutes()
        fix?.let { onPosition(it, true) } ?: updateGuidance(0.0)
    }

    fun toggleAlternatives() {
        alternatives = !alternatives
        toast(if (alternatives) "Alternative routes on" else "Alternative routes off", 2500)
        val d = dest
        if (d != null) startRoute(d)
    }

    private fun reroute() {
        val d = dest ?: return
        val f = fix ?: return
        if (System.currentTimeMillis() - lastReroute < 10000) return
        lastReroute = System.currentTimeMillis()
        toast("Rerouting…", 2000)
        scope.launch {
            try {
                val rs = withContext(Dispatchers.IO) { TomTomRest.routes(apiKey, f.pos, d.pos, false) }
                if (rs.isNotEmpty()) { routes = rs; active = 0; said.clear(); offCount = 0; lastIdx = 0; drawRoutes() }
            } catch (e: Exception) { toast("Reroute failed: ${e.message}", 4000) }
        }
    }

    fun endRoute() {
        routes = emptyList(); active = 0; dest = null; turn = null; eta = null; lastIdx = 0; previewing = false; routeFrac = 0f
        map.setRoute(emptyList(), emptyList()); map.setDest(null)
        stopSim()
        tts?.stop()
        map.setTilt(if (tilt3d) 55.0 else 0.0)
    }

    // ---- camera controls ----
    fun recenter() {
        following = true
        zoomOffset = 0.0
        val f = fix
        if (f != null) onPosition(f, true) else toast("No GPS fix yet")
    }

    fun toggleNorthUp() {
        northUp = !northUp
        if (northUp) map.resetNorth() else fix?.let { onPosition(it, true) }
    }

    fun toggleTilt() {
        tilt3d = !tilt3d
        map.setTilt(if (tilt3d) 55.0 else 0.0)
    }

    fun zoom(delta: Double) {
        if (following && fix != null) { zoomOffset = (zoomOffset + delta).coerceIn(-4.0, 3.0); fix?.let { onPosition(it, true) } }
        else map.zoomBy(delta)
    }

    // ---- guidance ----
    private fun snap(r: Route, p: LL): Snap {
        val pts = r.pts
        var bd = 1e12; var bi = 0; var bt = 0.0
        val k = cos(Geo.rad(p.lat)) * 111320.0
        val k2 = 110574.0
        fun scan(a: Int, b: Int) {
            for (i in a until min(b, pts.size - 1)) {
                val ax = (pts[i].lon - p.lon) * k; val ay = (pts[i].lat - p.lat) * k2
                val bx = (pts[i + 1].lon - p.lon) * k; val by = (pts[i + 1].lat - p.lat) * k2
                val dx = bx - ax; val dy = by - ay
                val l2 = dx * dx + dy * dy
                var t = if (l2 > 0) -(ax * dx + ay * dy) / l2 else 0.0
                t = t.coerceIn(0.0, 1.0)
                val d = hypot(ax + dx * t, ay + dy * t)
                if (d < bd) { bd = d; bi = i; bt = t }
            }
        }
        scan(max(0, lastIdx - 20), lastIdx + 500)
        if (bd > 60) scan(0, pts.size)
        lastIdx = bi
        val seg = r.cum[bi + 1] - r.cum[bi]
        val a = pts[bi]; val b = pts[bi + 1]
        return Snap(bd, bi, r.cum[bi] + bt * seg, LL(a.lat + (b.lat - a.lat) * bt, a.lon + (b.lon - a.lon) * bt))
    }

    private fun onPosition(p: Fix, force: Boolean) {
        fix = p
        map.setMe(p.pos, p.heading)
        if (previewing) return
        val r = route
        if (r == null || r.pts.size < 2) {
            if (following) followCamera(p, false)
            return
        }
        val s = snap(r, p.pos)
        if (s.dist > 70) { if (++offCount >= 4) reroute() } else offCount = 0
        val now = System.currentTimeMillis()
        if (force || now - lastDraw > 1500) {
            lastDraw = now
            map.setMainOnly(listOf(s.pt) + r.pts.subList(s.i + 1, r.pts.size))
        }
        updateGuidance(s.progress)
        if (following) followCamera(p, true)
    }

    /** Zoom that adapts: closer when a turn is near or the destination is close, wider on fast roads with a long way to go. */
    private fun autoZoom(sp: Double, navigating: Boolean): Double {
        var z = if (sp < 6) 17.3 else if (sp < 14) 16.6 else if (sp < 24) 15.9 else if (sp < 31) 15.2 else 14.6
        if (navigating) {
            val t = turn
            if (t != null) {
                val near = ((700.0 - t.dist) / 700.0).coerceIn(0.0, 1.0)     // 1 = at the turn
                z += 1.1 * near
                if (sp > 18) z -= 0.7 * ((t.dist - 2500.0) / 2500.0).coerceIn(0.0, 1.0)   // long straight stretch
            }
            val e = eta
            if (e != null && e.dist < 500) z = max(z, 17.6)
        }
        return z.coerceIn(13.5, 18.0)
    }

    private fun followCamera(p: Fix, navigating: Boolean) {
        val sp = p.speed
        val bearing = if (northUp) 0.0 else if (navigating || sp > 2.0) p.heading else null
        val pad = if (tilt3d && (navigating || sp > 2.0)) 0.36 else 0.0
        map.cameraTo(p.pos, bearing, if (tilt3d) 60.0 else 0.0, autoZoom(sp, navigating) + zoomOffset, 1000, pad)
    }

    private fun updateGuidance(progress: Double) {
        val r = route ?: return
        val rem = max(0.0, r.len - progress)
        val frac = if (r.len > 0) rem / r.len else 0.0
        val secs = r.time * frac
        val delayMin = Math.round(r.delay * frac / 60.0).toInt()
        val arrive = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + (secs * 1000).toLong()))
        eta = EtaInfo(arrive, rem, secs, delayMin)
        routeFrac = (1.0 - frac).toFloat().coerceIn(0f, 1f)

        val ins = r.steps
        var k = ins.indexOfFirst { it.off > progress + 8 }
        if (k < 0) k = ins.size - 1
        if (k >= 0) {
            val cur = ins[k]
            val d = max(0.0, cur.off - progress)
            val arriving = cur.maneuver.uppercase().startsWith("ARRIVE")
            val nxt = ins.getOrNull(k + 1)
            val street = if (arriving) (dest?.name ?: "Destination") else cur.street.ifBlank { cur.msg.ifBlank { Geo.maneuverText(cur.maneuver) } }
            turn = TurnInfo(
                d, street, cur.maneuver, nxt?.maneuver,
                if (nxt != null) "Then " + Geo.maneuverText(nxt.maneuver) + (if (nxt.street.isNotBlank()) " onto ${nxt.street}" else "") else "",
            )
            val word = Geo.maneuverText(cur.maneuver)
            val tail = if (arriving || cur.street.isBlank()) "" else " onto ${cur.street}"
            if (d <= 520 && d > 200 && said.add("${k}f"))
                speak(if (arriving) "In ${Geo.spoken(d, imperial)}, you will arrive" else "In ${Geo.spoken(d, imperial)}, $word$tail")
            if (d <= 120 && said.add("${k}n"))
                speak(if (arriving) "You have arrived" else word.replaceFirstChar { it.uppercase() } + tail)
        }
        if (rem < 25 && said.add("end")) {
            toast("You have arrived", 5000)
            scope.launch { delay(4000); endRoute() }
        }
    }

    fun speak(text: String) {
        if (!voiceOn || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
    }

    // ---- demo drive ----
    fun cycleSim() {
        val r = route
        if (r == null) { toast("Pick a destination first, then start the demo drive"); return }
        when (simMode) {
            0 -> { simMode = 1; startSim(r) }
            1 -> simMode = 4
            else -> stopSim()
        }
    }

    private fun startSim(r: Route) {
        simJob?.cancel()
        simDist = fix?.let { snap(r, it.pos).progress } ?: 0.0
        following = true
        simJob = scope.launch {
            while (true) {
                val cur = route ?: break
                simDist = min(cur.len, simDist + 16.0 * simMode)
                val (pt, hd) = pointAt(cur, simDist)
                val td = turn?.dist ?: 1000.0
                val demoSpeed = if (td < 150) 7.0 else if (td < 400) 13.0 else if (td < 1200) 20.0 else 27.0
                onPosition(Fix(pt, hd, demoSpeed, 0.0), false)
                if (simDist >= cur.len) break
                delay(1000)
            }
            simMode = 0
        }
    }

    fun stopSim() { simJob?.cancel(); simJob = null; simMode = 0 }

    private fun pointAt(r: Route, d: Double): Pair<LL, Double> {
        val c = r.cum
        var lo = 0; var hi = c.size - 1
        while (lo < hi - 1) { val m = (lo + hi) ushr 1; if (c[m] <= d) lo = m else hi = m }
        val seg = (c[hi] - c[lo]).takeIf { it > 0 } ?: 1.0
        val t = ((d - c[lo]) / seg).coerceIn(0.0, 1.0)
        val a = r.pts[lo]; val b = r.pts[hi]
        return Pair(LL(a.lat + (b.lat - a.lat) * t, a.lon + (b.lon - a.lon) * t), Geo.bearing(a, b))
    }
}
