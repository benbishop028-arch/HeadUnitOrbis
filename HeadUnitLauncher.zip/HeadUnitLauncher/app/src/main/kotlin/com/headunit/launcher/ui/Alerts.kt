package com.headunit.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CarCrash
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AlertInfo

private fun alertColor(kind: String): Color = when (kind) {
    "camera", "limit" -> Bad
    "rain" -> NavBlue
    else -> Warn
}

private fun alertLabel(kind: String): String = when (kind) {
    "camera" -> "SPEED CAMERA"
    "limit" -> "SPEED LIMIT"
    "incident" -> "HAZARD AHEAD"
    "rain" -> "WEATHER"
    "break" -> "TAKE A BREAK"
    else -> "ALERT"
}

private fun alertIcon(a: AlertInfo): ImageVector {
    val t = a.text.lowercase()
    return when (a.kind) {
        "camera" -> Icons.Rounded.CameraAlt
        "incident" -> when {
            t.contains("work") -> Icons.Rounded.Construction
            t.contains("accident") || t.contains("crash") || t.contains("collision") -> Icons.Rounded.CarCrash
            else -> Icons.Rounded.PriorityHigh
        }
        "rain" -> if (t.startsWith("snow")) Icons.Rounded.AcUnit else Icons.Rounded.WaterDrop
        "break" -> Icons.Rounded.Coffee
        else -> Icons.Rounded.Notifications
    }
}

/** A road-sign style badge for an alert: speed-limit roundel, warning triangle, or a coloured disc. */
@Composable
fun AlertSign(a: AlertInfo, size: Dp) {
    val col = alertColor(a.kind)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        when (a.kind) {
            "limit" -> {
                val n = Regex("\\d+").find(a.text)?.value ?: ""
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.White).border(size * 0.09f, Bad, CircleShape), contentAlignment = Alignment.Center) {
                    Text(n, color = Color.Black, fontSize = (size.value * (if (n.length >= 3) 0.30f else 0.40f)).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            "camera", "incident" -> {
                Canvas(Modifier.fillMaxSize()) {
                    val w = this.size.width
                    val h = this.size.height
                    val p = Path().apply {
                        moveTo(w * 0.5f, h * 0.08f)
                        lineTo(w * 0.95f, h * 0.90f)
                        lineTo(w * 0.05f, h * 0.90f)
                        close()
                    }
                    drawPath(p, Color.White)
                    drawPath(p, Bad, style = Stroke(w * 0.09f, join = StrokeJoin.Round))
                }
                Icon(alertIcon(a), null, tint = Color.Black, modifier = Modifier.size(size * 0.40f).offset(y = size * 0.10f))
            }
            else -> {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(col.copy(alpha = 0.18f)).border(2.dp, col, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(alertIcon(a), null, tint = col, modifier = Modifier.size(size * 0.54f))
                }
            }
        }
    }
}

/** Large alert banner with a road-sign badge and a countdown bar. */
@Composable
fun AlertBanner(a: AlertInfo, modifier: Modifier = Modifier) {
    val col = alertColor(a.kind)
    val prog = remember(a) { Animatable(1f) }
    LaunchedEffect(a) { prog.animateTo(0f, tween(a.ms.toInt().coerceAtLeast(500), easing = LinearEasing)) }
    val shape = RoundedCornerShape(30.dp)
    Column(
        modifier.widthIn(min = 430.dp, max = 640.dp).shadow(16.dp, shape).clip(shape)
            .background(Color(0xF2121922)).border(1.5.dp, col.copy(alpha = 0.7f), shape),
    ) {
        Row(Modifier.padding(start = 16.dp, end = 26.dp, top = 14.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            AlertSign(a, 76.dp)
            Column(Modifier.padding(start = 18.dp)) {
                Text(alertLabel(a.kind), color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text(a.text, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(prog.value).fillMaxHeight().background(col))
        }
    }
}
