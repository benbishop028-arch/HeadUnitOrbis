package com.headunit.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlin.math.roundToInt

/** What an item looks like while the bar is being edited: a widget preview or a round shortcut button. */
@Composable
private fun EditItemBody(id: String, prefs: Prefs, apps: AppsRepo, soundMode: Int) {
    val c = LocalVw.current
    if (id in BarInfoIds) BarWidgetPreview(id, prefs, apps)
    else Box(Modifier.size(54.dp).clip(CircleShape).background(c.onBg.copy(alpha = 0.07f)), contentAlignment = Alignment.Center) {
        val app = if (id.startsWith("app:")) apps.find(id.removePrefix("app:")) else null
        when {
            app != null -> Image(app.icon, null, Modifier.size(38.dp), contentScale = ContentScale.Fit)
            id.startsWith("call:") -> {
                val nm = id.substringAfter('|', "")
                if (nm.isNotBlank()) Text(nm.take(1).uppercase(), color = c.onBg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                else Icon(Icons.Rounded.Call, null, tint = c.onBg, modifier = Modifier.size(24.dp))
            }
            else -> Icon(slotIcon(id, soundMode), null, tint = c.onBg, modifier = Modifier.size(28.dp))
        }
    }
}

/**
 * The bottom bar while Settings > Bottom bar is open. Every widget and shortcut that is switched on is shown (with sample values),
 * can be dragged along the bar, or across to the other side of the home key, and has a red cross to remove it.
 * The music player, if it is switched on, always stays next to the home key.
 */
@Composable
internal fun BoxWithConstraintsScope.BarEditContent(cfg: BarCfg, prefs: Prefs, apps: AppsRepo, engine: NavEngine, amb: Color, homeLine: Color) {
    val c = LocalVw.current
    val soundMode = engine.soundMode
    // the music player only sits on the full-screen map's bar
    val mini = if (cfg.map) prefs.s("mini", "right") else "off"
    val lane = maxWidth / 2 - 62.dp - 28.dp

    fun initial(side: String): List<String> = if (side == "left") barLayout(cfg).first else barLayout(cfg).second

    val left = remember { mutableStateListOf<String>().also { it.addAll(initial("left")) } }
    val right = remember { mutableStateListOf<String>().also { it.addAll(initial("right")) } }
    var dragId by remember { mutableStateOf<String?>(null) }
    var pointer by remember { mutableStateOf(Offset.Zero) }      // window coordinates
    var grab by remember { mutableStateOf(Offset.Zero) }         // where inside the item it was picked up
    var origin by remember { mutableStateOf(Offset.Zero) }       // top-left of the bar, in window coordinates
    var barWidth by remember { mutableStateOf(1f) }
    val bounds = remember { mutableStateMapOf<String, Rect>() }

    // pick up changes made elsewhere in the settings (switching a widget on, adding a shortcut, resetting the order)
    val sig = listOf(cfg.s("bar2L", "#"), cfg.s("bar2R", "#"), mini, cfg.map.toString()).joinToString("|")
    LaunchedEffect(sig) {
        if (dragId == null) { left.clear(); left.addAll(initial("left")); right.clear(); right.addAll(initial("right")) }
    }

    fun commit() = setBarLayout(cfg, left.toList(), right.toList())

    fun remove(id: String) {
        left.remove(id); right.remove(id)
        commit()
    }

    // live reordering while an item is being dragged
    fun moveDragged() {
        val id = dragId ?: return
        val p = pointer
        val toRight = p.x > origin.x + barWidth / 2f
        val src = if (id in left) left else right
        val dst = if (toRight) right else left
        val idx = dst.filter { it != id }.count { t -> (bounds[t]?.center?.x ?: Float.MAX_VALUE) < p.x }
        if (src !== dst || dst.indexOf(id) != idx) { src.remove(id); dst.add(idx.coerceIn(0, dst.size), id) }
    }

    @Composable
    fun Item(t: String) {
        Box(
            Modifier.alpha(if (dragId == t) 0.25f else 1f)
                .onGloballyPositioned { val p = it.positionInWindow(); bounds[t] = Rect(p, it.size.toSize()) },
        ) {
            Box(Modifier.padding(top = 8.dp, end = 8.dp)) { EditItemBody(t, prefs, apps, soundMode) }
            Box(
                Modifier.align(Alignment.TopEnd).size(22.dp).clip(CircleShape).background(Color(0xFFE53935)).clickable { remove(t) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Close, "Remove", tint = Color.White, modifier = Modifier.size(14.dp)) }
        }
    }

    @Composable
    fun MusicStub() {
        Row(
            Modifier.height(60.dp).width(150.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, c.onBgSub.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = c.onBgSub, modifier = Modifier.size(20.dp))
            Text("Music player", color = c.onBgSub, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
        }
    }

    Box(
        Modifier.fillMaxSize()
            .onGloballyPositioned { origin = it.positionInWindow(); barWidth = it.size.width.toFloat() }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { off ->
                        val w = origin + off
                        val hit = bounds.entries.firstOrNull { it.value.contains(w) && (it.key in left || it.key in right) }?.key
                        dragId = hit
                        pointer = w
                        if (hit != null) grab = w - (bounds[hit]?.topLeft ?: w)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (dragId != null) { pointer = origin + change.position; moveDragged() }
                    },
                    onDragEnd = { dragId = null; commit() },
                    onDragCancel = { dragId = null; commit() },
                )
            },
    ) {
        Row(
            Modifier.align(Alignment.CenterStart).padding(start = 16.dp, bottom = 4.dp).widthIn(max = lane),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            for (t in left) key(t) { Item(t) }
            if (mini == "left") MusicStub()
        }
        HomeKey(amb, homeLine, { }, Modifier.align(Alignment.Center).padding(bottom = 4.dp))
        Row(
            Modifier.align(Alignment.CenterEnd).padding(end = 16.dp, bottom = 4.dp).widthIn(max = lane),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (mini == "right") MusicStub()
            for (t in right) key(t) { Item(t) }
        }
        // the item being moved follows the finger
        val carried = dragId
        if (carried != null) Box(
            Modifier.offset { IntOffset((pointer.x - grab.x - origin.x).roundToInt(), (pointer.y - grab.y - origin.y).roundToInt()) }.alpha(0.95f),
        ) { EditItemBody(carried, prefs, apps, soundMode) }
    }
}
