package com.headunit.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlin.math.roundToInt

/** One draggable thing on the bar: a widget (a named tile) or a shortcut (a round icon). */
@Composable
private fun ReorderTile(id: String, prefs: Prefs, apps: AppsRepo, soundMode: Int) {
    val c = LocalVw.current
    if (id in BarInfoIds) {
        Box(
            Modifier.width(112.dp).height(52.dp).clip(RoundedCornerShape(14.dp)).background(c.accent.copy(alpha = 0.16f))
                .border(1.dp, c.accent.copy(alpha = 0.7f), RoundedCornerShape(14.dp)).padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(BarInfoNames[id] ?: id, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    } else {
        Box(Modifier.size(52.dp).clip(CircleShape).background(c.text.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) {
            val app = if (id.startsWith("app:")) apps.find(id.removePrefix("app:")) else null
            when {
                app != null -> Image(app.icon, null, Modifier.size(36.dp), contentScale = ContentScale.Fit)
                id.startsWith("call:") -> {
                    val nm = id.substringAfter('|', "")
                    if (nm.isNotBlank()) Text(nm.take(1).uppercase(), color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    else Icon(Icons.Rounded.Call, null, tint = c.text, modifier = Modifier.size(24.dp))
                }
                else -> Icon(slotIcon(id, soundMode), null, tint = c.text, modifier = Modifier.size(26.dp))
            }
        }
    }
}

/**
 * Drag the widgets and shortcuts of the bottom bar into the order you want, or across to the other side.
 * Only widgets that are switched on are shown. The result is saved when you let go and when you press Done.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BarReorderDialog(prefs: Prefs, apps: AppsRepo, engine: NavEngine, onDismiss: () -> Unit) {
    val c = LocalVw.current
    val soundMode = engine.soundMode

    fun initial(side: String): List<String> {
        val autoSide = if (prefs.s("mini", "right") == "left") "right" else "left"
        val ws = BarInfoIds.filter { barWidgetOn(prefs, it) }.filter { id ->
            val v = prefs.s("barside_$id", "auto"); (if (v == "left" || v == "right") v else autoSide) == side
        }
        val (sl, sr) = barSideSlots(prefs)
        val ss = if (side == "left") sl else sr
        val natural = if (side == "left") ss + ws.reversed() else ws + ss
        val order = prefs.s(if (side == "left") "barorderL" else "barorderR", "").split(",").filter { it.isNotBlank() }
        return natural.sortedBy { t -> order.indexOf(t).let { if (it < 0) 1000 + natural.indexOf(t) else it } }
    }

    val left = remember { mutableStateListOf<String>().also { it.addAll(initial("left")) } }
    val right = remember { mutableStateListOf<String>().also { it.addAll(initial("right")) } }
    var dragId by remember { mutableStateOf<String?>(null) }
    var pointer by remember { mutableStateOf(Offset.Zero) }      // window coordinates
    var grab by remember { mutableStateOf(Offset.Zero) }         // where inside the tile it was picked up
    var origin by remember { mutableStateOf(Offset.Zero) }       // top-left of the drag area, in window coordinates
    var leftRect by remember { mutableStateOf(Rect.Zero) }
    var rightRect by remember { mutableStateOf(Rect.Zero) }
    val bounds = remember { mutableStateMapOf<String, Rect>() }

    fun commit() {
        prefs.put("barslotsL", left.filter { it !in BarInfoIds }.joinToString(","))
        prefs.put("barslotsR", right.filter { it !in BarInfoIds }.joinToString(","))
        left.filter { it in BarInfoIds }.forEach { prefs.put("barside_$it", "left") }
        right.filter { it in BarInfoIds }.forEach { prefs.put("barside_$it", "right") }
        prefs.put("barorderL", left.joinToString(","))
        prefs.put("barorderR", right.joinToString(","))
    }

    // live reordering while a tile is being dragged
    fun moveDragged() {
        val id = dragId ?: return
        val p = pointer
        val toRight = when {
            rightRect.contains(p) -> true
            leftRect.contains(p) -> false
            else -> p.x > (leftRect.right + rightRect.left) / 2f
        }
        val src = if (id in left) left else right
        val dst = if (toRight) right else left
        val others = dst.filter { it != id }
        var idx = 0
        if (others.isNotEmpty()) {
            var best = others[0]; var bestD = Float.MAX_VALUE
            for (t in others) {
                val r = bounds[t] ?: continue
                val dx = r.center.x - p.x; val dy = r.center.y - p.y
                val d = dx * dx + dy * dy
                if (d < bestD) { bestD = d; best = t }
            }
            val r = bounds[best]
            val ni = others.indexOf(best)
            idx = if (r != null && p.x < r.center.x) ni else ni + 1
        }
        if (src !== dst || dst.indexOf(id) != idx) { src.remove(id); dst.add(idx.coerceIn(0, dst.size), id) }
    }

    Dialog(onDismissRequest = { commit(); onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(24.dp)).background(c.surface).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Reorder the bottom bar", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Pill("Reset order", false, {
                    prefs.put("barorderL", ""); prefs.put("barorderR", "")
                    left.clear(); left.addAll(initial("left")); right.clear(); right.addAll(initial("right"))
                })
                Box(Modifier.width(8.dp))
                Pill("Done", true, { commit(); onDismiss() })
            }
            Text(
                "Press and drag a widget or shortcut to move it. Drop it on the other side to move it across. Only widgets that are switched on appear here.",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
            )
            Box(
                Modifier.fillMaxWidth()
                    .onGloballyPositioned { origin = it.positionInWindow() }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { off ->
                                val w = origin + off
                                val hit = bounds.entries.firstOrNull { it.value.contains(w) && (it.key in left || it.key in right) }?.key
                                dragId = hit
                                pointer = w
                                if (hit != null) grab = w - (bounds[hit]?.topLeft ?: w)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                if (dragId != null) { pointer = origin + change.position; moveDragged() }
                            },
                            onDragEnd = { dragId = null; commit() },
                            onDragCancel = { dragId = null; commit() },
                        )
                    },
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (side in listOf("left", "right")) {
                        val list = if (side == "left") left else right
                        Column(Modifier.weight(1f)) {
                            Text(if (side == "left") "Left side" else "Right side", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
                            FlowRow(
                                Modifier.fillMaxWidth().heightIn(min = 90.dp).clip(RoundedCornerShape(18.dp)).background(c.tile).padding(10.dp)
                                    .onGloballyPositioned { val p = it.positionInWindow(); val r = Rect(p, it.size.toSize()); if (side == "left") leftRect = r else rightRect = r },
                                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                for (t in list) key(t) {
                                    Box(
                                        Modifier.alpha(if (dragId == t) 0.25f else 1f)
                                            .onGloballyPositioned { val p = it.positionInWindow(); bounds[t] = Rect(p, it.size.toSize()) },
                                    ) { ReorderTile(t, prefs, apps, soundMode) }
                                }
                            }
                        }
                        if (side == "left") Box(Modifier.padding(top = 22.dp).size(52.dp).clip(CircleShape).border(2.dp, c.text.copy(alpha = 0.5f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Home, "Home key", tint = c.text.copy(alpha = 0.7f), modifier = Modifier.size(24.dp))
                        }
                    }
                }
                // the item being carried follows the finger
                val carried = dragId
                if (carried != null) Box(
                    Modifier.offset { IntOffset((pointer.x - grab.x - origin.x).roundToInt(), (pointer.y - grab.y - origin.y).roundToInt()) }.alpha(0.95f),
                ) { ReorderTile(carried, prefs, apps, soundMode) }
            }
        }
    }
}
