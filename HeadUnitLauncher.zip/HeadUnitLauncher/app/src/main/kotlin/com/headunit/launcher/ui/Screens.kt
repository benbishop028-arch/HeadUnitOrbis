package com.headunit.launcher.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.headunit.launcher.nav.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppEntry(val label: String, val intent: Intent, val icon: Drawable)

private fun Context.loadApps(music: Boolean): List<AppEntry> {
    val q = Intent(Intent.ACTION_MAIN).addCategory(if (music) Intent.CATEGORY_APP_MUSIC else Intent.CATEGORY_LAUNCHER)
    return packageManager.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != packageName }
        .map {
            AppEntry(
                label = it.loadLabel(packageManager).toString(),
                intent = Intent(Intent.ACTION_MAIN).setClassName(it.activityInfo.packageName, it.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                icon = it.loadIcon(packageManager),
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
private fun PageTitle(text: String) =
    Text(text, color = Color.White, fontSize = 30.sp, modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 12.dp))

@Composable
private fun AppGrid(music: Boolean, emptyText: String) {
    val ctx = LocalContext.current
    val apps by produceState(emptyList<AppEntry>(), music) { value = withContext(Dispatchers.IO) { ctx.loadApps(music) } }
    if (apps.isEmpty()) {
        Text(emptyText, color = TextDim, fontSize = 20.sp, modifier = Modifier.padding(28.dp))
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(130.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 240.dp), // keeps clear of the PiP map
    ) {
        items(apps) { a ->
            Column(
                Modifier.padding(8.dp).clip(RoundedCornerShape(16.dp)).clickable { ctx.startActivity(a.intent) }.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val bmp = remember(a) { a.icon.toBitmap(112, 112).asImageBitmap() }
                Image(bmp, a.label, Modifier.size(64.dp))
                Spacer(Modifier.height(8.dp))
                Text(a.label, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun AppsScreen() = Column(Modifier.fillMaxSize().background(Rail)) {
    PageTitle("Apps"); AppGrid(music = false, emptyText = "No apps found")
}

@Composable
fun MediaScreen() = Column(Modifier.fillMaxSize().background(Rail)) {
    PageTitle("Media"); AppGrid(music = true, emptyText = "No music apps installed")
}

@Composable
private fun BigAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.width(420.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick).padding(24.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(36.dp))
        Spacer(Modifier.width(20.dp))
        Text(label, color = Color.White, fontSize = 22.sp)
    }
}

private fun Context.go(i: Intent) = runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

@Composable
fun CallScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(Rail), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PageTitle("Call")
        Column(Modifier.padding(start = 28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            BigAction(Icons.Filled.Dialpad, "Dial pad") { ctx.go(Intent(Intent.ACTION_DIAL)) }
            BigAction(Icons.Filled.Contacts, "Contacts") { ctx.go(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)) }
            BigAction(Icons.Filled.History, "Recent calls") { ctx.go(Intent(Intent.ACTION_VIEW).setType(CallLog.Calls.CONTENT_TYPE)) }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as Application
    var level by remember { mutableIntStateOf(Prefs.consentLevel(app)) }
    Column(Modifier.fillMaxSize().background(Rail)) {
        PageTitle("Settings")
        Column(Modifier.padding(start = 28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            BigAction(Icons.Filled.Wifi, "Wi-Fi") { ctx.go(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            BigAction(Icons.Filled.Bluetooth, "Bluetooth") { ctx.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            BigAction(Icons.Filled.Brightness6, "Display") { ctx.go(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            BigAction(Icons.Filled.Home, "Default home app") { ctx.go(Intent(Settings.ACTION_HOME_SETTINGS)) }
            BigAction(Icons.Filled.Settings, "System settings") { ctx.go(Intent(Settings.ACTION_SETTINGS)) }
            Column(Modifier.width(420.dp).clip(RoundedCornerShape(16.dp)).background(Panel).padding(24.dp)) {
                Text("Share navigation telemetry with TomTom", color = Color.White, fontSize = 20.sp)
                Text("Applies after the launcher restarts", color = TextDim, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                listOf("Off", "Location only", "Full").forEachIndexed { i, label ->
                    Row(Modifier.fillMaxWidth().clickable { level = i; Prefs.setConsentLevel(app, i) }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = level == i, onClick = { level = i; Prefs.setConsentLevel(app, i) })
                        Text(label, color = Color.White, fontSize = 18.sp)
                    }
                }
            }
        }
    }
}
