package com.headunit.launcher

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.media.CamcorderProfile
import android.media.MediaRecorder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import kotlin.math.*

// ------------------------------------------------------------------ webhooks (smart home)
class Hook(val name: String, val url: String)

class HookStore(private val prefs: Prefs) {
    fun all(): List<Hook> {
        val s = prefs.s("hooks", "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { val o = a.getJSONObject(it); Hook(o.getString("n"), o.getString("u")) }
        } catch (e: Exception) { emptyList() }
    }

    private fun write(list: List<Hook>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("n", it.name).put("u", it.url)) }
        prefs.put("hooks", a.toString())
    }

    fun add(name: String, url: String) = write(all() + Hook(name, url))
    fun remove(i: Int) = write(all().filterIndexed { n, _ -> n != i })

    /** Fires the URL. A "POST " prefix makes it a POST request. Returns true on a 2xx answer. */
    fun fire(h: Hook): Boolean = try {
        val post = h.url.startsWith("POST ", true)
        val c = URL(h.url.removePrefix("POST ").removePrefix("post ").trim()).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.requestMethod = if (post) "POST" else "GET"
        if (post) { c.doOutput = true; c.outputStream.use { it.write(ByteArray(0)) } }
        c.responseCode in 200..299
    } catch (e: Exception) { false }
}

// ------------------------------------------------------------------ habits: learn where you usually go and when
class HabitStore(private val prefs: Prefs) {
    private class Rec(val name: String, val sub: String, val lat: Double, val lon: Double, val t: Long)

    private fun all(): List<Rec> {
        val s = prefs.s("habits", "")
        if (s.isBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { val o = a.getJSONObject(it); Rec(o.getString("n"), o.optString("s"), o.getDouble("a"), o.getDouble("o"), o.getLong("t")) }
        } catch (e: Exception) { emptyList() }
    }

    fun record(p: Place) {
        if (p.name == "Dropped pin" || p.name == "My car") return
        val list = (all() + Rec(p.name, p.sub, p.pos.lat, p.pos.lon, System.currentTimeMillis())).takeLast(250)
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("n", it.name).put("s", it.sub).put("a", it.lat).put("o", it.lon).put("t", it.t)) }
        prefs.put("habits", a.toString())
    }

    private fun minutes(t: Long): Int { val c = Calendar.getInstance().apply { timeInMillis = t }; return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }
    private fun weekend(t: Long): Boolean { val d = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.DAY_OF_WEEK); return d == Calendar.SATURDAY || d == Calendar.SUNDAY }

    /** A place you have driven to at least 3 times on the same kind of day within 45 minutes of now. */
    fun suggest(now: Long): Place? {
        val cutoff = now - 90L * 86_400_000L
        val near = all().filter { it.t > cutoff && weekend(it.t) == weekend(now) && abs(minutes(it.t) - minutes(now)) <= 45 }
        val groups = near.groupBy { "${Math.round(it.lat * 500)}:${Math.round(it.lon * 500)}" }
        val best = groups.values.maxByOrNull { it.size } ?: return null
        if (best.size < 3) return null
        val r = best.last()
        val avg = best.map { minutes(it.t) }.average().toInt()
        return Place(r.name, "Usually around %02d:%02d".format(avg / 60, avg % 60), LL(r.lat, r.lon))
    }
}

// ------------------------------------------------------------------ driven tracks (stored in a file, not in prefs)
object Tracks {
    private fun file(ctx: Context) = File(ctx.filesDir, "tracks.txt")

    fun append(ctx: Context, pts: List<LL>) {
        if (pts.size < 5) return
        try {
            val f = file(ctx)
            if (f.exists() && f.length() > 1_500_000) {
                val lines = f.readLines()
                f.writeText(lines.drop(lines.size / 2).dropWhile { it != "T" }.joinToString("\n") + "\n")
            }
            val sb = StringBuilder("T\n")
            pts.forEach { sb.append(String.format(java.util.Locale.US, "%.4f,%.4f\n", it.lat, it.lon)) }
            f.appendText(sb.toString())
        } catch (e: Exception) { /* storage problems are not worth crashing for */ }
    }

    fun readAll(ctx: Context): List<List<LL>> {
        val out = ArrayList<List<LL>>()
        try {
            var cur = ArrayList<LL>()
            file(ctx).forEachLine { l ->
                if (l == "T") { if (cur.size > 1) out += cur; cur = ArrayList() }
                else {
                    val p = l.split(",")
                    if (p.size == 2) { val a = p[0].toDoubleOrNull(); val b = p[1].toDoubleOrNull(); if (a != null && b != null) cur.add(LL(a, b)) }
                }
            }
            if (cur.size > 1) out += cur
        } catch (e: Exception) { }
        return out
    }

    fun clear(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }
}

// ------------------------------------------------------------------ milestones
object Milestones {
    private val steps = listOf(100, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000)

    fun reached(totalKm: Double): List<Int> = steps.filter { totalKm >= it }

    /** Returns a message when a new milestone has just been reached. */
    fun check(prefs: Prefs, totalKm: Double): String? {
        val got = reached(totalKm).size
        val saved = prefs.s("milestone", "0").toIntOrNull() ?: 0
        if (got > saved) {
            prefs.put("milestone", got.toString())
            if (saved == 0 && got > 1) return null
            return "Milestone: ${steps[got - 1]} km driven with this launcher"
        }
        return null
    }
}

// ------------------------------------------------------------------ fuel cost estimate from the fuel log
fun FuelStore.costPerKm(): Double? {
    val e = all()
    if (e.size < 2) return null
    val litresAll = e.sumOf { it.litres }
    if (litresAll <= 0) return null
    val price = e.sumOf { it.cost } / litresAll
    var litres = 0.0; var km = 0.0
    for (i in 0 until e.size - 1) {
        val a = e[i]; val b = e[i + 1]
        if (a.odo > 0 && b.odo > 0 && a.odo > b.odo) { km += a.odo - b.odo; litres += a.litres }
    }
    if (km < 50) return null
    return price * litres / km
}

// ------------------------------------------------------------------ nearby interesting places (Wikipedia)
class Landmark(val title: String, val text: String, val pos: LL, val dist: Double)

object Wiki {
    fun nearby(p: LL, radiusM: Int = 6000): List<Landmark> = try {
        val url = "https://en.wikipedia.org/w/api.php?action=query&format=json&generator=geosearch" +
            "&ggscoord=${p.lat}%7C${p.lon}&ggsradius=$radiusM&ggslimit=14&prop=extracts%7Ccoordinates" +
            "&exintro=1&explaintext=1&exchars=380&exlimit=max&colimit=max"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "DriveLauncher/1.0")
        val pages = JSONObject(c.inputStream.bufferedReader().readText()).optJSONObject("query")?.optJSONObject("pages")
        val out = ArrayList<Landmark>()
        if (pages != null) {
            val keys = pages.keys()
            while (keys.hasNext()) {
                val o = pages.getJSONObject(keys.next())
                val co = o.optJSONArray("coordinates")?.optJSONObject(0) ?: continue
                val pos = LL(co.getDouble("lat"), co.getDouble("lon"))
                val text = o.optString("extract").trim()
                if (text.length < 40) continue
                out += Landmark(o.optString("title"), text, pos, Geo.dist(p, pos))
            }
        }
        out.sortedBy { it.dist }
    } catch (e: Exception) { emptyList() }
}

// ------------------------------------------------------------------ sky: moon phase and the ISS
class IssInfo(val groundKm: Double, val elevation: Double, val bearing: Double, val altKm: Double)

object Sky {
    private const val SYNODIC = 29.530588853

    fun moonAge(nowMs: Long): Double {
        val jd = nowMs / 86_400_000.0 + 2440587.5
        return ((jd - 2451550.1) % SYNODIC + SYNODIC) % SYNODIC
    }

    fun moonIllumination(nowMs: Long): Double = (1 - cos(2 * PI * moonAge(nowMs) / SYNODIC)) / 2

    fun moonName(nowMs: Long): String {
        val a = moonAge(nowMs)
        return when {
            a < 1.0 || a > SYNODIC - 1.0 -> "New moon"
            a < 6.4 -> "Waxing crescent"
            a < 8.4 -> "First quarter"
            a < 13.8 -> "Waxing gibbous"
            a < 15.8 -> "Full moon"
            a < 21.1 -> "Waning gibbous"
            a < 23.1 -> "Last quarter"
            else -> "Waning crescent"
        }
    }

    fun iss(me: LL): IssInfo? = try {
        val c = URL("https://api.wheretheiss.at/v1/satellites/25544").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        val pos = LL(j.getDouble("latitude"), j.getDouble("longitude"))
        val alt = j.getDouble("altitude")
        val re = 6371.0
        val ground = Geo.dist(me, pos) / 1000.0
        val ang = ground / re
        val elev = Math.toDegrees(atan2(cos(ang) - re / (re + alt), sin(ang)))
        IssInfo(ground, elev, Geo.bearing(me, pos), alt)
    } catch (e: Exception) { null }
}

// ------------------------------------------------------------------ dash cam (loop recording with the device camera)
object DashCam {
    var recording by mutableStateOf(false)
    var status by mutableStateOf("Not recording")
    var clips by mutableIntStateOf(0)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var cam: Camera? = null
    private var rec: MediaRecorder? = null

    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "dashcam").apply { mkdirs() }

    fun refresh(ctx: Context) { clips = dir(ctx).listFiles()?.size ?: 0 }

    fun deleteAll(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() }; refresh(ctx) }

    @Suppress("DEPRECATION")
    fun start(ctx: Context, segmentMin: Int = 3, keep: Int = 10) {
        if (recording) return
        recording = true
        status = "Starting…"
        job = scope.launch {
            try {
                if (Camera.getNumberOfCameras() < 1) { status = "No camera found on this device"; recording = false; return@launch }
                val c = Camera.open(0)
                cam = c
                c.setPreviewTexture(SurfaceTexture(10))
                c.startPreview()
                val profile = when {
                    CamcorderProfile.hasProfile(0, CamcorderProfile.QUALITY_720P) -> CamcorderProfile.get(0, CamcorderProfile.QUALITY_720P)
                    CamcorderProfile.hasProfile(0, CamcorderProfile.QUALITY_480P) -> CamcorderProfile.get(0, CamcorderProfile.QUALITY_480P)
                    else -> CamcorderProfile.get(0, CamcorderProfile.QUALITY_LOW)
                }
                while (recording) {
                    val f = File(dir(ctx), "clip_" + System.currentTimeMillis() + ".mp4")
                    c.unlock()
                    val r = MediaRecorder()
                    rec = r
                    r.setCamera(c)
                    r.setVideoSource(MediaRecorder.VideoSource.CAMERA)
                    r.setOutputFormat(profile.fileFormat)
                    r.setVideoEncoder(profile.videoCodec)
                    r.setVideoSize(profile.videoFrameWidth, profile.videoFrameHeight)
                    r.setVideoFrameRate(profile.videoFrameRate)
                    r.setVideoEncodingBitRate(profile.videoBitRate)
                    r.setOutputFile(f.absolutePath)
                    r.prepare()
                    r.start()
                    status = "Recording"
                    var left = segmentMin * 60
                    while (recording && left > 0) { delay(1000); left-- }
                    try { r.stop() } catch (e: Exception) { }
                    r.release(); rec = null
                    c.lock()
                    val files = dir(ctx).listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
                    if (files.size > keep) files.take(files.size - keep).forEach { it.delete() }
                    refresh(ctx)
                }
            } catch (e: Exception) {
                status = "Camera error: " + (e.message ?: "unavailable")
            } finally {
                release()
                recording = false
                if (!status.startsWith("Camera") && !status.startsWith("No camera")) status = "Not recording"
                refresh(ctx)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun release() {
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        try { cam?.stopPreview(); cam?.release() } catch (e: Exception) { }
        cam = null
    }

    fun stop() { recording = false }
}
