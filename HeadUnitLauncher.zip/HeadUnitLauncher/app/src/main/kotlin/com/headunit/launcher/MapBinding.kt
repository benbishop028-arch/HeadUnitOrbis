package com.headunit.launcher

import kotlin.math.max
import kotlin.math.min
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

/** Owns the single native MapView so it can move between the Home preview and the full Navigation page. */
class MapBinding(private val ctx: Context) : DefaultLifecycleObserver {
    val mapView: MapView
    var map: MapLibreMap? = null
        private set
    private var style: Style? = null
    private var wantedStyle: String? = null
    private var loadedStyle: String? = null

    private var main: List<LL> = emptyList()
    private var alts: List<List<LL>> = emptyList()
    private var dest: LL? = null
    private var me: LL? = null
    private var meHeading = 0.0

    var onLongPress: ((LL) -> Unit)? = null
    var onUserGesture: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    private var satellite = false
    private var buildings3d = true
    private val origVisible = HashMap<String, Boolean>()
    var tiltNow = 0.0
        private set

    init {
        MapLibre.getInstance(ctx)
        val opts = MapLibreMapOptions.createFromAttributes(ctx)
            .textureMode(true)
            .attributionEnabled(true)
            .logoEnabled(false)
            .camera(CameraPosition.Builder().target(LatLng(51.5072, -0.1276)).zoom(14.0).tilt(55.0).build())
        mapView = MapView(ctx, opts)
        mapView.onCreate(null)
        mapView.addOnDidFailLoadingMapListener { msg -> onError?.invoke(msg ?: "Map failed to load") }
        mapView.getMapAsync { m ->
            map = m
            m.setMaxPitchPreference(75.0)
            m.uiSettings.isCompassEnabled = false
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = true
            m.addOnMapLongClickListener { p ->
                onLongPress?.invoke(LL(p.latitude, p.longitude)); true
            }
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) onUserGesture?.invoke()
            }
            wantedStyle?.let { loadStyle(it) }
        }
    }

    // ---- lifecycle ----
    override fun onStart(owner: LifecycleOwner) = mapView.onStart()
    override fun onResume(owner: LifecycleOwner) = mapView.onResume()
    override fun onPause(owner: LifecycleOwner) = mapView.onPause()
    override fun onStop(owner: LifecycleOwner) = mapView.onStop()
    override fun onDestroy(owner: LifecycleOwner) = mapView.onDestroy()

    // ---- style ----
    fun setStyleUrl(url: String) {
        wantedStyle = url
        if (map != null && url != loadedStyle) loadStyle(url)
    }

    private fun loadStyle(url: String) {
        val m = map ?: return
        loadedStyle = url
        style = null
        m.setStyle(if (url.startsWith("{")) Style.Builder().fromJson(url) else Style.Builder().fromUri(url)) { st ->
            style = st
            install(st)
        }
    }

    /** Waze-style arrow: fat rounded chevron, blue fill, thick white outline and a soft shadow. Points up; rotated by heading. */
    private fun arrowBitmap(): Bitmap {
        val n = 128
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path().apply {
            moveTo(64f, 14f)
            quadTo(70f, 14f, 74f, 22f)
            lineTo(100f, 92f)
            quadTo(104f, 104f, 92f, 100f)
            lineTo(64f, 84f)
            lineTo(36f, 100f)
            quadTo(24f, 104f, 28f, 92f)
            lineTo(54f, 22f)
            quadTo(58f, 14f, 64f, 14f)
            close()
        }
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x00000000; style = Paint.Style.FILL; setShadowLayer(10f, 0f, 5f, 0x80000000.toInt())
        }
        c.drawPath(path, shadow)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 12f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, edge)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = android.graphics.LinearGradient(0f, 14f, 0f, 104f, 0xFF3AA0FF.toInt(), 0xFF1263E0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        }
        c.drawPath(path, fill)
        return bmp
    }

    private fun empty() = FeatureCollection.fromFeatures(ArrayList<Feature>())

    private fun install(st: Style) {
        st.addSource(GeoJsonSource("dl-alts", empty()))
        st.addSource(GeoJsonSource("dl-route", empty()))
        st.addSource(GeoJsonSource("dl-dest", empty()))
        st.addSource(GeoJsonSource("dl-me", empty()))
        st.addSource(GeoJsonSource("dl-lanes", empty()))
        laneImgs.clear()
        st.addLayer(
            LineLayer("dl-alts-line", "dl-alts").withProperties(
                PropertyFactory.lineColor("#8fa3bd"), PropertyFactory.lineWidth(7f), PropertyFactory.lineOpacity(0.85f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-glow", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor()), PropertyFactory.lineWidth(20f), PropertyFactory.lineBlur(12f),
                PropertyFactory.lineOpacity(0.4f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-casing", "dl-route").withProperties(
                PropertyFactory.lineColor("#eaf2ff"), PropertyFactory.lineWidth(11.5f), PropertyFactory.lineOpacity(0.92f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-line", "dl-route").withProperties(
                PropertyFactory.lineColor(sevColor()), PropertyFactory.lineWidth(8f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        for ((id, on) in listOf("dl-lanes-off" to 0, "dl-lanes-on" to 1)) {
            st.addLayer(
                SymbolLayer(id, "dl-lanes").withFilter(Expression.eq(Expression.get("on"), Expression.literal(on))).withProperties(
                    PropertyFactory.iconImage(Expression.get("img")),
                    PropertyFactory.iconRotate(Expression.get("rot")),
                    PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                    PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true),
                    PropertyFactory.iconSize(Expression.interpolate(Expression.exponential(2), Expression.zoom(), Expression.stop(15, 0.06f), Expression.stop(20, 1.9f))),
                )
            )
        }
        st.addLayer(
            CircleLayer("dl-dest-dot", "dl-dest").withProperties(
                PropertyFactory.circleRadius(10f), PropertyFactory.circleColor("#ff3b30"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3f),
            )
        )
        st.addLayer(
            CircleLayer("dl-me-halo", "dl-me").withProperties(
                PropertyFactory.circleRadius(15f), PropertyFactory.circleColor("#2e8bff"), PropertyFactory.circleOpacity(0.25f),
            )
        )
        st.addImage("dl-arrow", arrowBitmap())
        st.addLayer(
            SymbolLayer("dl-me-arrow", "dl-me").withProperties(
                PropertyFactory.iconImage("dl-arrow"),
                PropertyFactory.iconRotate(Expression.get("h")),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconPitchAlignment(Property.ICON_PITCH_ALIGNMENT_MAP),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconSize(1.0f),
            )
        )
        // remember which style layers were visible originally, so toggles never reveal hidden ones
        origVisible.clear()
        for (l in st.layers) origVisible[l.id] = l.visibility.value != Property.NONE
        applyView()
        pushAll()
    }

    fun setView(sat: Boolean, b3d: Boolean) {
        satellite = sat
        buildings3d = b3d
        applyView()
    }

    /** Satellite imagery under the labels, and 3D building on/off. Safe to call repeatedly. */
    private fun applyView() {
        val st = style ?: return
        val has = st.getLayer("dl-sat") != null
        if (satellite && !has) {
            val ts = TileSet("2.2.0", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}")
            ts.maxZoom = 19f
            ts.attribution = "Imagery © Esri"
            st.addSource(RasterSource("dl-sat-src", ts, 256))
            st.addLayerAt(RasterLayer("dl-sat", "dl-sat-src"), 0)
        } else if (!satellite && has) {
            st.removeLayer("dl-sat")
            st.removeSource("dl-sat-src")
        }
        for (l in st.layers) {
            val id = l.id
            if (id.startsWith("dl-")) continue
            val orig = origVisible[id] ?: true
            val keep = l is SymbolLayer || id.contains("traffic", true) || id.contains("flow", true)
            val show = if (l is FillExtrusionLayer) orig && !satellite && buildings3d else orig && (!satellite || keep)
            l.setProperties(PropertyFactory.visibility(if (show) Property.VISIBLE else Property.NONE))
        }
    }

    private fun line(p: List<LL>): Feature =
        Feature.fromGeometry(LineString.fromLngLats(p.map { Point.fromLngLat(it.lon, it.lat) }))

    private fun lineSev(p: List<LL>, level: Int): Feature {
        val f = line(p)
        f.addNumberProperty("sev", level)
        return f
    }

    private var mainSev: IntArray? = null
    private var mainOff = 0

    /** Route colour: blue normally, amber where traffic is slow, red where it is heavy. */
    private fun sevColor(): Expression = Expression.switchCase(
        Expression.eq(Expression.get("sev"), Expression.literal(2)), Expression.color(android.graphics.Color.parseColor("#FF4D4D")),
        Expression.eq(Expression.get("sev"), Expression.literal(1)), Expression.color(android.graphics.Color.parseColor("#FFB020")),
        Expression.color(android.graphics.Color.parseColor("#4CC9FF")),
    )

    private fun pushAll() {
        pushRoute(); pushDest(); pushMe()
    }

    private fun src(id: String): GeoJsonSource? = style?.getSourceAs<GeoJsonSource>(id)

    private fun setLine(pts: List<LL>) {
        val s = src("dl-route") ?: return
        if (pts.size < 2) { s.setGeoJson(empty()); return }
        val sev = mainSev
        if (sev == null || sev.isEmpty()) { s.setGeoJson(FeatureCollection.fromFeatures(arrayListOf(lineSev(pts, 0)))); return }
        fun level(j: Int) = if (mainOff + j in sev.indices) sev[mainOff + j] else 0
        val feats = ArrayList<Feature>()
        var start = 0
        var cur = level(0)
        for (j in 1 until pts.size - 1) {
            val l = level(j)
            if (l != cur) { feats += lineSev(pts.subList(start, j + 1), cur); start = j; cur = l }
        }
        feats += lineSev(pts.subList(start, pts.size), cur)
        s.setGeoJson(FeatureCollection.fromFeatures(feats))
    }

    private fun pushRoute() {
        setLine(main)
        src("dl-alts")?.setGeoJson(FeatureCollection.fromFeatures(ArrayList(alts.filter { it.size >= 2 }.map { line(it) })))
    }

    private fun pushDest() {
        val s = src("dl-dest") ?: return
        val d = dest
        if (d != null) s.setGeoJson(Feature.fromGeometry(Point.fromLngLat(d.lon, d.lat))) else s.setGeoJson(empty())
    }

    private fun pushMe() {
        val s = src("dl-me") ?: return
        val p = me
        if (p != null) {
            val f = Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))
            f.addNumberProperty("h", meHeading)
            s.setGeoJson(f)
        } else s.setGeoJson(empty())
    }

    // ---- lane arrows painted on the road ----
    class LaneMark(val pt: LL, val bearing: Double, val dir: String, val on: Boolean)
    private val laneImgs = HashSet<String>()
    private var lanePulse: android.animation.ValueAnimator? = null

    private fun laneBitmap(dir: String, on: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(64, 80, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val ang = when (dir) {
            "SLIGHT_LEFT" -> -45f; "LEFT" -> -90f; "SHARP_LEFT" -> -135f; "LEFT_U_TURN" -> -180f
            "SLIGHT_RIGHT" -> 45f; "RIGHT" -> 90f; "SHARP_RIGHT" -> 135f; "RIGHT_U_TURN" -> 180f
            else -> 0f
        }
        fun draw(p: Paint) {
            c.drawLine(32f, 74f, 32f, 44f, p)
            c.save(); c.rotate(ang, 32f, 44f)
            c.drawLine(32f, 44f, 32f, 18f, p)
            c.drawLine(32f, 18f, 22f, 28f, p)
            c.drawLine(32f, 18f, 42f, 28f, p)
            c.restore()
        }
        val out = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 14f; color = 0x99000000.toInt() }
        draw(out)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 9f
            color = if (on) 0xFF6FC3FF.toInt() else 0xB8FFFFFF.toInt()
        }
        draw(fill)
        return bmp
    }

    fun setLanes(marks: List<LaneMark>) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val st = style ?: return@post
            val feats = ArrayList<Feature>()
            for (m in marks) {
                val name = "ln-${m.dir}-${if (m.on) 1 else 0}"
                if (laneImgs.add(name)) st.addImage(name, laneBitmap(m.dir, m.on))
                val f = Feature.fromGeometry(Point.fromLngLat(m.pt.lon, m.pt.lat))
                f.addStringProperty("img", name)
                f.addNumberProperty("rot", m.bearing)
                f.addNumberProperty("on", if (m.on) 1 else 0)
                feats.add(f)
            }
            st.getSourceAs<GeoJsonSource>("dl-lanes")?.setGeoJson(FeatureCollection.fromFeatures(feats))
            val layer = st.getLayerAs<SymbolLayer>("dl-lanes-on")
            lanePulse?.cancel(); lanePulse = null
            if (feats.isEmpty()) { layer?.setProperties(PropertyFactory.iconOpacity(1f)); return@post }
            lanePulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 600; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                addUpdateListener { layer?.setProperties(PropertyFactory.iconOpacity(0.45f + 0.55f * (it.animatedValue as Float))) }
                start()
            }
        }
    }

    // ---- data from the engine ----
    fun setRoute(mainPts: List<LL>, altPts: List<List<LL>>, sev: IntArray? = null) { main = mainPts; alts = altPts; mainSev = sev; mainOff = 0; pushRoute() }
    private var pulseAnim: android.animation.ValueAnimator? = null

    /** Pulses the glow under the route line (used when a turn is close). */
    fun setTurnPulse(on: Boolean) {
        if (on == (pulseAnim != null)) return
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            pulseAnim?.cancel(); pulseAnim = null
            val layer = style?.getLayerAs<LineLayer>("dl-route-glow")
            if (!on) {
                layer?.setProperties(PropertyFactory.lineOpacity(0.4f), PropertyFactory.lineWidth(20f))
            } else {
                pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 650; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE
                    addUpdateListener {
                        val v = it.animatedValue as Float
                        layer?.setProperties(PropertyFactory.lineOpacity(0.35f + 0.55f * v), PropertyFactory.lineWidth(18f + 16f * v))
                    }
                    start()
                }
            }
        }
    }

    fun setMainOnly(mainPts: List<LL>, sev: IntArray? = null, firstSeg: Int = 0) { main = mainPts; mainSev = sev; mainOff = firstSeg; setLine(main) }
    fun setDest(p: LL?) { dest = p; pushDest() }
    private var meAnim: android.animation.ValueAnimator? = null
    private var lastMePush = 0L

    /** Moves the arrow smoothly from where it is now to [p] over [durationMs] (one GPS interval). */
    fun setMe(p: LL?, heading: Double = 0.0, durationMs: Long = 1000) {
        meAnim?.cancel()
        val from = me
        if (p == null || from == null || durationMs <= 0 || Geo.dist(from, p) > 300) {
            me = p; meHeading = heading; pushMe(); return
        }
        val fromH = meHeading
        val dH = ((heading - fromH + 540.0) % 360.0) - 180.0
        meAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { a ->
                val t = a.animatedFraction.toDouble()
                me = LL(from.lat + (p.lat - from.lat) * t, from.lon + (p.lon - from.lon) * t)
                meHeading = (fromH + dH * t + 360.0) % 360.0
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastMePush >= 30 || t >= 1.0) { lastMePush = now; pushMe() }
            }
            start()
        }
    }

    // ---- camera ----
    fun center(): LL? = map?.cameraPosition?.target?.let { LL(it.latitude, it.longitude) }

    fun cameraTo(c: LL, bearing: Double?, tilt: Double, zoom: Double, ms: Int, topPadFraction: Double, leftPadFraction: Double = 0.0) {
        val m = map ?: return
        val h = mapView.height
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom)
            .padding(mapView.width * leftPadFraction, h * topPadFraction, 0.0, 0.0)
        if (bearing != null) b.bearing(bearing)
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.newCameraPosition(b.build()), ms, false)
    }

    fun setTilt(tilt: Double) {
        val m = map ?: return
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.tiltTo(tilt), 500)
    }

    fun zoomBy(delta: Double) {
        map?.easeCamera(CameraUpdateFactory.zoomBy(delta), 250)
    }

    fun resetNorth() {
        val m = map ?: return
        m.easeCamera(CameraUpdateFactory.bearingTo(0.0), 400)
    }

    /** Smoothly zooms out (flat, north-up) so every point sits in the area above the route-preview panel. */
    fun fit(points: List<LL>) {
        val m = map ?: return
        if (points.size < 2) return
        val d = mapView.resources.displayMetrics.density.toDouble()
        val w = mapView.width / d
        val h = mapView.height / d
        if (w < 50 || h < 50) return
        fun mx(lon: Double) = (lon + 180.0) / 360.0
        fun my(lat: Double): Double {
            val r = Math.toRadians(lat.coerceIn(-85.0, 85.0))
            return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0
        }
        val xs = points.map { mx(it.lon) }; val ys = points.map { my(it.lat) }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        // visible area (dp): the bottom half is covered by the preview panel
        val pl = w * 0.07; val pr = w * 0.07; val pt = h * 0.10; val pb = h * 0.60
        val aw = w - pl - pr; val ah = h - pt - pb
        val fx = max(x1 - x0, 1e-7); val fy = max(y1 - y0, 1e-7)
        val z = min(Math.log(aw / (512.0 * fx)), Math.log(ah / (512.0 * fy))) / Math.log(2.0)
        val zoom = z.coerceIn(2.0, 17.0)
        val world = 512.0 * Math.pow(2.0, zoom)
        // bounds centre should land in the middle of the visible area, not the middle of the map
        val cx = (x0 + x1) / 2 + (w / 2 - (pl + aw / 2)) / world
        val cy = (y0 + y1) / 2 + (h / 2 - (pt + ah / 2)) / world
        val lon = cx * 360.0 - 180.0
        val lat = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1 - 2 * cy))))
        tiltNow = 0.0
        val cp = CameraPosition.Builder().target(LatLng(lat, lon)).zoom(zoom).tilt(0.0).bearing(0.0)
            .padding(0.0, 0.0, 0.0, 0.0).build()
        m.easeCamera(CameraUpdateFactory.newCameraPosition(cp), 1600)
    }
}
