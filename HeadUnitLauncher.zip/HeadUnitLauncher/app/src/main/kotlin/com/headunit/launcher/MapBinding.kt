package com.headunit.launcher

import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

/** Owns the single native MapView so it can move between the Home preview and the full Navigation page. */
class MapBinding(private val ctx: Context) : DefaultLifecycleObserver {
    val mapView: MapView
    var map: MapLibreMap? = null
        private set
    private var style: Style? = null
    private var wantedStyle: String? = null
    private var loadedStyle: String? = null

    private var main: List<LL> = emptyList()
    private var alts: List<List<LL>> = emptyList()
    private var dest: LL? = null
    private var me: LL? = null

    var onLongPress: ((LL) -> Unit)? = null
    var onUserGesture: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var tiltNow = 0.0
        private set

    init {
        MapLibre.getInstance(ctx)
        val opts = MapLibreMapOptions.createFromAttributes(ctx)
            .textureMode(true)
            .attributionEnabled(true)
            .logoEnabled(false)
            .camera(CameraPosition.Builder().target(LatLng(51.5072, -0.1276)).zoom(14.0).tilt(55.0).build())
        mapView = MapView(ctx, opts)
        mapView.onCreate(null)
        mapView.addOnDidFailLoadingMapListener { msg -> onError?.invoke(msg ?: "Map failed to load") }
        mapView.getMapAsync { m ->
            map = m
            m.setMaxPitchPreference(75.0)
            m.uiSettings.isCompassEnabled = true
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = true
            m.addOnMapLongClickListener { p ->
                onLongPress?.invoke(LL(p.latitude, p.longitude)); true
            }
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) onUserGesture?.invoke()
            }
            wantedStyle?.let { loadStyle(it) }
        }
    }

    // ---- lifecycle ----
    override fun onStart(owner: LifecycleOwner) = mapView.onStart()
    override fun onResume(owner: LifecycleOwner) = mapView.onResume()
    override fun onPause(owner: LifecycleOwner) = mapView.onPause()
    override fun onStop(owner: LifecycleOwner) = mapView.onStop()
    override fun onDestroy(owner: LifecycleOwner) = mapView.onDestroy()

    // ---- style ----
    fun setStyleUrl(url: String) {
        wantedStyle = url
        if (map != null && url != loadedStyle) loadStyle(url)
    }

    private fun loadStyle(url: String) {
        val m = map ?: return
        loadedStyle = url
        style = null
        m.setStyle(Style.Builder().fromUri(url)) { st ->
            style = st
            install(st)
        }
    }

    private fun empty() = FeatureCollection.fromFeatures(ArrayList<Feature>())

    private fun install(st: Style) {
        st.addSource(GeoJsonSource("dl-alts", empty()))
        st.addSource(GeoJsonSource("dl-route", empty()))
        st.addSource(GeoJsonSource("dl-dest", empty()))
        st.addSource(GeoJsonSource("dl-me", empty()))
        st.addLayer(
            LineLayer("dl-alts-line", "dl-alts").withProperties(
                PropertyFactory.lineColor("#8fa3bd"), PropertyFactory.lineWidth(7f), PropertyFactory.lineOpacity(0.85f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-glow", "dl-route").withProperties(
                PropertyFactory.lineColor("#4cc9ff"), PropertyFactory.lineWidth(20f), PropertyFactory.lineBlur(12f),
                PropertyFactory.lineOpacity(0.4f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-casing", "dl-route").withProperties(
                PropertyFactory.lineColor("#0a2c4d"), PropertyFactory.lineWidth(13f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            LineLayer("dl-route-line", "dl-route").withProperties(
                PropertyFactory.lineColor("#4cc9ff"), PropertyFactory.lineWidth(8f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
            )
        )
        st.addLayer(
            CircleLayer("dl-dest-dot", "dl-dest").withProperties(
                PropertyFactory.circleRadius(10f), PropertyFactory.circleColor("#ff3b30"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3f),
            )
        )
        st.addLayer(
            CircleLayer("dl-me-halo", "dl-me").withProperties(
                PropertyFactory.circleRadius(20f), PropertyFactory.circleColor("#2e8bff"), PropertyFactory.circleOpacity(0.25f),
            )
        )
        st.addLayer(
            CircleLayer("dl-me-dot", "dl-me").withProperties(
                PropertyFactory.circleRadius(9f), PropertyFactory.circleColor("#2e8bff"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3.5f),
            )
        )
        pushAll()
    }

    private fun line(p: List<LL>): Feature =
        Feature.fromGeometry(LineString.fromLngLats(p.map { Point.fromLngLat(it.lon, it.lat) }))

    private fun pushAll() {
        pushRoute(); pushDest(); pushMe()
    }

    private fun src(id: String): GeoJsonSource? = style?.getSourceAs<GeoJsonSource>(id)

    private fun pushRoute() {
        src("dl-route")?.setGeoJson(if (main.size >= 2) line(main) else empty())
        src("dl-alts")?.setGeoJson(FeatureCollection.fromFeatures(ArrayList(alts.filter { it.size >= 2 }.map { line(it) })))
    }

    private fun pushDest() {
        val s = src("dl-dest") ?: return
        val d = dest
        if (d != null) s.setGeoJson(Feature.fromGeometry(Point.fromLngLat(d.lon, d.lat))) else s.setGeoJson(empty())
    }

    private fun pushMe() {
        val s = src("dl-me") ?: return
        val p = me
        if (p != null) s.setGeoJson(Feature.fromGeometry(Point.fromLngLat(p.lon, p.lat))) else s.setGeoJson(empty())
    }

    // ---- data from the engine ----
    fun setRoute(mainPts: List<LL>, altPts: List<List<LL>>) { main = mainPts; alts = altPts; pushRoute() }
    fun setMainOnly(mainPts: List<LL>) { main = mainPts; src("dl-route")?.setGeoJson(if (main.size >= 2) line(main) else empty()) }
    fun setDest(p: LL?) { dest = p; pushDest() }
    fun setMe(p: LL?) { me = p; pushMe() }

    // ---- camera ----
    fun center(): LL? = map?.cameraPosition?.target?.let { LL(it.latitude, it.longitude) }

    fun cameraTo(c: LL, bearing: Double?, tilt: Double, zoom: Double, ms: Int, topPadFraction: Double) {
        val m = map ?: return
        val h = mapView.height
        m.setPadding(0, (h * topPadFraction).toInt(), 0, 0)
        val b = CameraPosition.Builder().target(LatLng(c.lat, c.lon)).tilt(tilt).zoom(zoom)
        if (bearing != null) b.bearing(bearing)
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.newCameraPosition(b.build()), ms, false)
    }

    fun setTilt(tilt: Double) {
        val m = map ?: return
        tiltNow = tilt
        m.easeCamera(CameraUpdateFactory.tiltTo(tilt), 500)
    }

    fun zoomBy(delta: Double) {
        map?.easeCamera(CameraUpdateFactory.zoomBy(delta), 250)
    }

    fun resetNorth() {
        val m = map ?: return
        m.easeCamera(CameraUpdateFactory.bearingTo(0.0), 400)
    }

    fun fit(points: List<LL>) {
        val m = map ?: return
        if (points.size < 2) return
        m.setPadding(0, 0, 0, 0)
        val b = LatLngBounds.Builder().includes(points.map { LatLng(it.lat, it.lon) }).build()
        tiltNow = 0.0
        m.easeCamera(CameraUpdateFactory.newLatLngBounds(b, 140, 200, 140, 180), 800)
        m.easeCamera(CameraUpdateFactory.tiltTo(0.0), 800)
    }
}
