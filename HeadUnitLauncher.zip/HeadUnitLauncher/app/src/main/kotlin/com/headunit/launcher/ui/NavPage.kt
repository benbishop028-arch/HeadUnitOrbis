package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.remember
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EvStation
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Work
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Geo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.Place
import com.headunit.launcher.NavEngine
import kotlinx.coroutines.delay

@Composable
fun NavOverlays(engine: NavEngine) {
    val c = LocalVw.current
    var q by rememberSaveable { mutableStateOf("") }
    var layers by remember { mutableStateOf(false) }
    var tipVisible by remember { mutableStateOf(true) }
    val voiceSearch = rememberVoiceInput("Say a destination") { q = it; engine.search(it) }
    var searchOpen by remember { mutableStateOf(true) }
    var searchFocused by remember { mutableStateOf(false) }
    var tapped by remember { mutableStateOf(false) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    // collapse to a round search button after 5 s of not being used
    LaunchedEffect(searchOpen, q, searchFocused, engine.results.size, engine.previewing, engine.route, engine.nearbyKind, engine.pendingSave, tapped) {
        if (searchOpen && q.isEmpty() && !searchFocused && engine.results.isEmpty() && engine.nearbyKind == null && engine.pendingSave == null) {
            delay(if (tapped) 12000 else 5000); searchOpen = false
        }
    }
    LaunchedEffect(searchOpen) {
        if (searchOpen && tapped) { delay(120); try { focus.requestFocus() } catch (_: Exception) {} }
    }
    LaunchedEffect(Unit) { delay(5000); tipVisible = false }
    LaunchedEffect(q) {
        if (q.length >= 3) { delay(500); engine.search(q) } else if (q.isEmpty()) engine.results = emptyList()
    }

    Box(Modifier.fillMaxSize().padding(top = 6.dp, bottom = 6.dp)) {

        val routing = engine.route != null && !engine.previewing
        val previewing = engine.previewing
        // left column: search / turn card
        Column(Modifier.align(Alignment.TopStart).padding(start = if (routing) 38.dp else 14.dp, top = 14.dp, end = 14.dp, bottom = 14.dp).width(if (routing) 384.dp else 360.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!routing && !previewing) {
                val sw by animateDpAsState(if (searchOpen) 360.dp else 56.dp, tween(280), label = "searchW")
                Box(Modifier.width(sw).height(56.dp).clip(RoundedCornerShape(28.dp)).background(c.surface)) {
                    if (searchOpen) {
                        TextField(
                            value = q, onValueChange = { q = it },
                            placeholder = { Text("Search address or place") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            trailingIcon = {
                                if (q.isNotEmpty()) Icon(Icons.Rounded.Close, null, Modifier.clickable { q = ""; engine.results = emptyList() })
                                else Icon(Icons.Rounded.Mic, "Voice search", Modifier.clickable { tapped = true; voiceSearch() })
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { engine.search(q) }),
                            shape = RoundedCornerShape(50),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = c.surface, unfocusedContainerColor = c.surface,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            ),
                            modifier = Modifier.fillMaxSize().focusRequester(focus).onFocusChanged { searchFocused = it.isFocused },
                        )
                    } else {
                        Box(Modifier.fillMaxSize().clickable { tapped = true; searchOpen = true }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Search, "Search", tint = c.text, modifier = Modifier.size(26.dp))
                        }
                    }
                }
                if (engine.results.isNotEmpty()) {
                    LazyColumn(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface).fillMaxWidth()) {
                        items(engine.results) { p ->
                            Column(Modifier.fillMaxWidth().clickable { q = ""; engine.pickPlace(p) }.padding(horizontal = 18.dp, vertical = 11.dp)) {
                                Text(p.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(p.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                } else if (q.isEmpty() && searchOpen) {
                    AnimatedVisibility(tipVisible, exit = fadeOut()) { Text(
                        "Tip: long-press anywhere on the map to drop a pin and route there.",
                        color = c.text, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(c.surface.copy(alpha = 0.9f)).padding(10.dp),
                    ) }
                }
            } else {
                engine.turn?.let { t ->
                    Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Blue)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(64.dp))
                            Column(Modifier.padding(start = 14.dp)) {
                                Text(Geo.fmtDist(t.dist, engine.imperial), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Text(t.street, color = Color.White, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (t.thenManeuver != null) {
                            Row(Modifier.fillMaxWidth().background(BlueSoft).padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                ManeuverArrow(t.thenManeuver, Geo.maneuverAngle(t.thenManeuver), Modifier.size(26.dp))
                                Text(t.thenText, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp))
                            }
                        }
                    }
                }
            }
            if (!routing && !previewing && searchOpen && q.isEmpty() && engine.results.isEmpty() && engine.nearbyKind == null) {
                QuickPanel(engine) { try { focus.requestFocus() } catch (_: Exception) {} }
            }
            if (engine.nearbyKind != null && !previewing) NearbyCard(engine)
        }

        // right: round buttons
        if (!previewing) Row(Modifier.align(Alignment.CenterEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextBtn(if (engine.tilt3d) "3D" else "2D", engine.tilt3d) { engine.toggleTilt() }
                RoundBtn(Icons.Rounded.Explore, { engine.toggleNorthUp() }, active = engine.northUp, size = 44.dp)
                RoundBtn(if (engine.voiceOn) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff, { engine.prefs.put("voice", !engine.voiceOn) }, size = 44.dp)
                RoundBtn(Icons.Rounded.Layers, { layers = !layers }, active = layers, size = 44.dp)
                RoundBtn(Icons.Rounded.PlayArrow, { engine.cycleSim() }, active = engine.simMode != 0, size = 44.dp)
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RoundBtn(Icons.Rounded.MyLocation, { engine.recenter() }, active = engine.following, size = 56.dp)
                RoundBtn(Icons.Rounded.Add, { engine.zoom(1.0) }, size = 56.dp)
                RoundBtn(Icons.Rounded.Remove, { engine.zoom(-1.0) }, size = 56.dp)
            }
        }
        if (layers && !previewing) Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 150.dp).clip(RoundedCornerShape(20.dp)).background(c.surface.copy(alpha = 0.97f)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Map layers", color = c.sub, fontSize = 13.sp)
            LayerRow("Satellite", engine.prefs.b("satellite", false)) { engine.prefs.put("satellite", it) }
            LayerRow("Traffic", engine.prefs.b("traffic", true)) { engine.prefs.put("traffic", it) }
            LayerRow("3D buildings", engine.prefs.b("buildings3d", true)) { engine.prefs.put("buildings3d", it) }
            Text("Find nearby", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Fuel", engine.nearbyKind == "fuel", { engine.loadNearby("fuel", false); layers = false })
                Pill("EV", engine.nearbyKind == "charging", { engine.loadNearby("charging", false); layers = false })
                Pill("Parking", engine.nearbyKind == "parking", { engine.loadNearby("parking", false); layers = false })
            }
            if (engine.dest != null) Pill("Parking at destination", false, { engine.loadNearby("parking", true); layers = false })
        }
        if (engine.simMode != 0) {
            Text("DEMO ${engine.simMode}x", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).clip(RoundedCornerShape(50)).background(Warn).padding(horizontal = 10.dp, vertical = 4.dp))
        }

        // route progress bar on the left edge
        if (routing) {
            val pr by animateFloatAsState(engine.routeFrac, tween(900), label = "prog")
            Box(Modifier.align(Alignment.CenterStart).padding(start = 12.dp, top = 12.dp, bottom = 12.dp).fillMaxHeight().width(12.dp).clip(RoundedCornerShape(6.dp)).background(c.surface.copy(alpha = 0.9f))) {
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(pr.coerceIn(0.02f, 1f)).clip(RoundedCornerShape(6.dp)).background(Blue))
            }
        }

        // speed, speed limit and camera warning
        val spdFix = engine.fix
        if (!previewing && spdFix != null && (spdFix.speed > 0.5 || routing || engine.simMode != 0)) {
            val imp = engine.imperial
            val k = if (imp) 2.23694 else 3.6
            val spd = Math.round(spdFix.speed * k).toInt()
            val lim = engine.speedLimit
            val limShown = lim?.let { (Math.round(it * k / 5.0) * 5).toInt() }
            val over = lim != null && spdFix.speed > lim + 0.8
            Column(
                Modifier.align(Alignment.BottomStart).padding(start = if (routing) 38.dp else 14.dp, bottom = if (engine.eta != null) 84.dp else 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                engine.cameraDist?.let { d ->
                    Text("Camera ${Geo.fmtDist(d.toDouble(), imp)}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(Bad).padding(horizontal = 10.dp, vertical = 5.dp))
                }
                if (limShown != null) {
                    Box(Modifier.size(52.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White)
                        .border(5.dp, Bad, androidx.compose.foundation.shape.CircleShape), contentAlignment = Alignment.Center) {
                        Text("$limShown", color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Column(
                    Modifier.size(64.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.surface.copy(alpha = 0.95f)),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Text("$spd", color = if (over) Bad else c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(if (imp) "mph" else "km/h", color = c.sub, fontSize = 10.sp)
                }
            }
        }

        // bottom ETA bar
        if (!previewing) engine.eta?.let { e ->
            Row(
                Modifier.align(Alignment.BottomStart).padding(start = 38.dp, bottom = 14.dp).clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.97f)).padding(start = 26.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp),
            ) {
                Column { Text(e.arrive, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("arrival", color = c.sub, fontSize = 11.sp) }
                Column { Text(Geo.fmtDur(e.secs), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("time", color = c.sub, fontSize = 11.sp) }
                Column { Text(Geo.fmtDist(e.dist, engine.imperial), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("distance", color = c.sub, fontSize = 11.sp) }
                if (e.delayMin >= 1) Text("+${e.delayMin} min", color = if (e.delayMin >= 10) Bad else Warn, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (engine.routes.size > 1) Text("Route ${engine.active + 1}/${engine.routes.size}", color = c.sub, fontSize = 13.sp)
                RoundBtn(Icons.Rounded.Close, { engine.endRoute() }, size = 48.dp, active = true, tint = Color.White)
            }
        }

        if (previewing) RoutePreview(engine)

        if (engine.busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = c.accent)
    }
}

private fun viaOf(r: com.headunit.launcher.Route): String {
    var best = ""
    var bl = 0.0
    for (i in r.steps.indices) {
        val len = (r.steps.getOrNull(i + 1)?.off ?: r.len) - r.steps[i].off
        if (len > bl && r.steps[i].street.isNotBlank()) { bl = len; best = r.steps[i].street }
    }
    return best
}

/** Journey overview: route options plus a Start button that fills up and starts by itself after 5 s. */
@Composable
private fun BoxScope.RoutePreview(engine: NavEngine) {
    val c = LocalVw.current
    val rs = engine.routes.take(3)
    if (rs.isEmpty()) return
    val fastest = rs.indices.minByOrNull { rs[it].time } ?: 0
    val shortest = rs.indices.minByOrNull { rs[it].len } ?: 0
    val progress = remember { Animatable(0f) }
    LaunchedEffect(engine.active, engine.routes) {
        progress.snapTo(0f)
        progress.animateTo(1f, tween(10000, easing = LinearEasing))
        engine.beginNavigation()
    }
    val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val baseMs = if (engine.departAtMs > 0) engine.departAtMs else System.currentTimeMillis()
    Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 10.dp, vertical = 4.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.97f)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("Leave", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 10.dp))
        for ((label, m) in listOf("Now" to 0, "+15 min" to 15, "+30 min" to 30, "+1 h" to 60, "+2 h" to 120)) {
            Pill(label, engine.departMin == m, { if (engine.departMin != m) engine.setDeparture(m) })
        }
    }
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(26.dp)).background(c.surface.copy(alpha = 0.97f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.width(150.dp)) {
            Text("Destination", color = c.sub, fontSize = 12.sp)
            Text(engine.dest?.name ?: "", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val d = engine.dest
            if (d != null) Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val fav = engine.places.isFavourite(d)
                Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favourite", tint = if (fav) Warn else c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.toast(if (engine.places.toggleFavourite(d)) "Saved to favourites" else "Removed from favourites", 2000) })
                Icon(Icons.Rounded.Home, "Set as home", tint = c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.places.setSlot("home", d); engine.toast("Home set to ${d.name}", 2500) })
                Icon(Icons.Rounded.Work, "Set as work", tint = c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.places.setSlot("work", d); engine.toast("Work set to ${d.name}", 2500) })
            }
        }
        rs.forEachIndexed { i, r ->
            val sel = i == engine.active
            val shape = RoundedCornerShape(18.dp)
            val label = if (i == fastest) "Fastest" else if (i == shortest) "Shortest" else "Alternative"
            Column(
                Modifier.weight(1f).clip(shape).background(if (sel) c.accent.copy(alpha = 0.18f) else c.surface2)
                    .then(if (sel) Modifier.border(2.dp, c.accent, shape) else Modifier)
                    .clickable { engine.selectRoute(i) }.padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text(label, color = if (sel) c.accent else c.sub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(Geo.fmtDur(r.time), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${Geo.fmtDist(r.len, engine.imperial)} · arrive ${fmt.format(java.util.Date(baseMs + (r.time * 1000).toLong()))}", color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val via = viaOf(r)
                val delayMin = Math.round(r.delay / 60.0).toInt()
                Text(
                    if (delayMin >= 1) "+$delayMin min traffic" else if (via.isNotEmpty()) "via $via" else "No delays",
                    color = if (delayMin >= 10) Bad else if (delayMin >= 1) Warn else c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            Modifier.width(210.dp).height(72.dp).clip(RoundedCornerShape(36.dp)).background(c.accent.copy(alpha = 0.30f))
                .clickable { engine.beginNavigation() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(progress.value).background(c.accent))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Start navigation", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Starting in ${kotlin.math.ceil((1f - progress.value) * 10f).toInt()} s", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        RoundBtn(Icons.Rounded.Close, { engine.endRoute() }, size = 46.dp)
    }
    }
}

@Composable
private fun TextBtn(label: String, active: Boolean, onClick: () -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape)
            .background(if (active) c.accent else c.surface.copy(alpha = 0.94f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (active) Color.White else c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun LayerRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalVw.current
    Row(Modifier.width(230.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(on, onChange)
    }
}

@Composable
private fun QuickChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalVw.current
    Row(
        modifier.clip(RoundedCornerShape(50)).background(c.surface2).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = c.accent, modifier = Modifier.size(18.dp))
        Text(label, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
    }
}

/** Shortcuts shown under the search bar: home, work, parked car, nearby places, favourites and recents. */
@Composable
private fun QuickPanel(engine: NavEngine, focusSearch: () -> Unit) {
    val c = LocalVw.current
    val home = engine.places.slot("home")
    val work = engine.places.slot("work")
    val car = engine.places.parked()
    val favs = engine.places.favourites()
    val recents = engine.places.recents().filter { r -> favs.none { Geo.dist(it.pos, r.pos) < 60 } }
    val saved: List<Pair<Place, Boolean>> = favs.map { it to true } + recents.take(4).map { it to false }
    Column(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface.copy(alpha = 0.96f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickChip(Icons.Rounded.Home, if (home != null) "Home" else "Set home", Modifier.weight(1f)) {
                if (home != null) engine.startRoute(home) else { engine.pendingSave = "home"; engine.toast("Search for your home address", 3500); focusSearch() }
            }
            QuickChip(Icons.Rounded.Work, if (work != null) "Work" else "Set work", Modifier.weight(1f)) {
                if (work != null) engine.startRoute(work) else { engine.pendingSave = "work"; engine.toast("Search for your work address", 3500); focusSearch() }
            }
            QuickChip(Icons.Rounded.DirectionsCar, "My car", Modifier.weight(1f)) {
                if (car != null) engine.startRoute(car) else engine.toast("No parked location saved yet. It saves itself after you park.", 3500)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickChip(Icons.Rounded.LocalGasStation, "Fuel", Modifier.weight(1f)) { engine.loadNearby("fuel", false) }
            QuickChip(Icons.Rounded.EvStation, "EV", Modifier.weight(1f)) { engine.loadNearby("charging", false) }
            QuickChip(Icons.Rounded.LocalParking, "Parking", Modifier.weight(1f)) { engine.loadNearby("parking", false) }
        }
        if (saved.isNotEmpty()) {
            LazyColumn(Modifier.heightIn(max = 170.dp)) {
                items(saved) { (p, fav) ->
                    Row(Modifier.fillMaxWidth().clickable { engine.startRoute(p) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.History, null, tint = if (fav) Warn else c.sub, modifier = Modifier.size(20.dp))
                        Column(Modifier.padding(start = 10.dp)) {
                            Text(p.name, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (p.sub.isNotBlank()) Text(p.sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NearbyCard(engine: NavEngine) {
    val c = LocalVw.current
    val title = when (engine.nearbyKind) { "fuel" -> "Fuel stations"; "charging" -> "Charging points"; else -> "Car parks" }
    Column(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface.copy(alpha = 0.97f)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (engine.nearbyBusy) CircularProgressIndicator(Modifier.size(18.dp), color = c.accent, strokeWidth = 2.dp)
            Icon(Icons.Rounded.Close, "Close", tint = c.sub, modifier = Modifier.padding(start = 12.dp).size(22.dp).clickable { engine.clearNearby() })
        }
        LazyColumn(Modifier.heightIn(max = 200.dp).padding(top = 6.dp)) {
            items(engine.nearby) { n ->
                Column(Modifier.fillMaxWidth().clickable { engine.startRoute(n.place) }.padding(vertical = 8.dp)) {
                    Text(n.place.name, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Geo.fmtDist(n.dist, engine.imperial) + (if (n.extra.isNotBlank()) " · " + n.extra else ""), color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
