package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.remember
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import com.headunit.launcher.costPerKm
import androidx.compose.foundation.layout.widthIn
import com.headunit.launcher.LaneSec
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EvStation
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Work
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Geo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.Place
import com.headunit.launcher.NavEngine
import com.headunit.launcher.ArrivalInfo
import kotlinx.coroutines.delay

@Composable
fun NavOverlays(engine: NavEngine) {
    val warnPulse by androidx.compose.animation.core.rememberInfiniteTransition(label = "warn").animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(tween(500), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "warnV",
    )
    val shareEta = rememberShareEta(engine)
    val c = LocalVw.current
    var q by rememberSaveable { mutableStateOf("") }
    var layers by remember { mutableStateOf(false) }
    var tipVisible by remember { mutableStateOf(true) }
    val voiceSearch = rememberVoiceInput("Say a destination") { q = it; engine.search(it) }
    var searchOpen by remember { mutableStateOf(true) }
    var searchFocused by remember { mutableStateOf(false) }
    var tapped by remember { mutableStateOf(false) }
    val typingLocked = (engine.fix?.speed ?: 0.0) > 3.0 && engine.prefs.b("drivelock", true)
    var wantFocus by remember { mutableStateOf(false) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(searchOpen) {
        if (searchOpen && wantFocus) { delay(120); try { focus.requestFocus() } catch (_: Exception) {}; wantFocus = false }
    }
    LaunchedEffect(Unit) { delay(5000); tipVisible = false }
    LaunchedEffect(q) {
        if (q.length >= 3) { delay(500); engine.search(q) } else if (q.isEmpty()) engine.results = emptyList()
    }

    Box(Modifier.fillMaxSize().padding(top = 6.dp, bottom = 6.dp)) {

        val routing = engine.route != null && !engine.previewing
        val previewing = engine.previewing
        // left column: search / turn card
        Column(Modifier.align(Alignment.TopStart).padding(start = 14.dp, top = 14.dp, end = 14.dp, bottom = 14.dp).width(if (routing) 384.dp else 360.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!routing && !previewing) {
                val sw by animateDpAsState(if (searchOpen) 306.dp else 60.dp, tween(280), label = "searchW")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.width(sw).height(60.dp).shadow(10.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(c.surface).border(1.dp, c.line.copy(alpha = 0.5f), RoundedCornerShape(30.dp))) {
                    if (searchOpen) {
                        TextField(
                            value = q, onValueChange = { q = it },
                            enabled = !typingLocked,
                            placeholder = { Text(if (typingLocked) "Tap the mic to search while driving" else "Where to?", fontSize = if (typingLocked) 15.sp else 18.sp) },
                            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = c.accent) },
                            trailingIcon = {
                                if (q.isNotEmpty()) Icon(Icons.Rounded.Close, null, Modifier.clickable { q = ""; engine.results = emptyList() })
                                else Icon(Icons.Rounded.Mic, "Voice search", tint = c.accent, modifier = Modifier.clickable { tapped = true; voiceSearch() })
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { engine.search(q) }),
                            shape = RoundedCornerShape(30.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = c.surface, unfocusedContainerColor = c.surface, disabledContainerColor = c.surface,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent,
                                disabledPlaceholderColor = c.sub, disabledLeadingIconColor = c.accent, disabledTrailingIconColor = c.accent,
                            ),
                            modifier = Modifier.fillMaxSize().focusRequester(focus).onFocusChanged { searchFocused = it.isFocused },
                        )
                    } else {
                        Box(Modifier.fillMaxSize().clickable { tapped = true; wantFocus = true; searchOpen = true }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Search, "Search", tint = c.accent, modifier = Modifier.size(28.dp))
                        }
                    }
                }
                Box(
                    Modifier.size(44.dp).shadow(6.dp, androidx.compose.foundation.shape.CircleShape).clip(androidx.compose.foundation.shape.CircleShape).background(c.surface).border(1.dp, c.line.copy(alpha = 0.5f), androidx.compose.foundation.shape.CircleShape)
                        .clickable {
                            if (searchOpen) { q = ""; engine.results = emptyList(); searchOpen = false }
                            else { searchOpen = true }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(if (searchOpen) Icons.Rounded.ChevronLeft else Icons.Rounded.ChevronRight, if (searchOpen) "Collapse search" else "Expand search", tint = c.text, modifier = Modifier.size(26.dp))
                }
                }
                if (engine.results.isNotEmpty()) {
                    LazyColumn(Modifier.shadow(10.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.surface).border(1.dp, c.line.copy(alpha = 0.5f), RoundedCornerShape(24.dp)).fillMaxWidth()) {
                        items(engine.results) { p ->
                            Row(Modifier.fillMaxWidth().clickable { q = ""; engine.pickPlace(p) }.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Place, null, tint = c.accent, modifier = Modifier.size(22.dp))
                                }
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text(p.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(p.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                } else if (q.isEmpty() && searchOpen) {
                    AnimatedVisibility(tipVisible, exit = fadeOut()) { Text(
                        "Tip: long-press anywhere on the map to drop a pin and route there.",
                        color = c.text, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(c.surface.copy(alpha = 0.9f)).padding(10.dp),
                    ) }
                }
            } else {
                engine.turn?.let { t ->
                    // the card grows as the turn gets close, then shrinks again afterwards
                    val grow by androidx.compose.animation.core.animateFloatAsState(maxOf(if (engine.driving && engine.prefs.b("drivesimple", true)) 0.4f else 0f, ((450.0 - t.dist) / 450.0).coerceIn(0.0, 1.0).toFloat()), androidx.compose.animation.core.tween(500), label = "turnGrow")
                    Column(Modifier.widthIn(max = 330.dp).clip(RoundedCornerShape(16.dp)).background(Blue).border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))) {
                        Box(Modifier.fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = 0.10f))) {
                            Box(Modifier.fillMaxWidth(((450.0 - t.dist) / 450.0).coerceIn(0.0, 1.0).toFloat()).fillMaxHeight().background(Color(0xFF7CCBFF)))
                        }
                        Row(Modifier.padding(horizontal = 12.dp, vertical = (8 + 2 * grow).dp), verticalAlignment = Alignment.CenterVertically) {
                            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size((42 + 12 * grow).dp))
                            Column(Modifier.padding(start = 10.dp)) {
                                RollText(Geo.fmtDist(t.dist, engine.imperial), Color.White, (26 + 6 * grow).sp, fontWeight = FontWeight.Bold)
                                Text(t.street, color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (t.tag.isNotBlank()) Text(t.tag, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                if (t.sign.isNotBlank() && t.sign != t.street) Text(t.sign, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 3.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF1E7A46)).padding(horizontal = 7.dp, vertical = 2.dp))
                            }
                        }
                        t.laneAdvice?.let { Text(it, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) }
                        if (t.thenManeuver != null) {
                            Row(Modifier.fillMaxWidth().background(BlueSoft).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                ManeuverArrow(t.thenManeuver, Geo.maneuverAngle(t.thenManeuver), Modifier.size(22.dp))
                                Text(t.thenText, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp))
                            }
                        }
                    }
                }
            }
            if (!routing && !previewing && searchOpen && q.isEmpty() && engine.results.isEmpty() && engine.nearbyKind == null) {
                QuickPanel(engine) { try { focus.requestFocus() } catch (_: Exception) {} }
            }
            if (engine.nearbyKind != null && (!previewing || engine.stopMode)) NearbyCard(engine)
        }

        // right: round buttons
        if (!previewing) Row(Modifier.align(Alignment.CenterEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!(engine.driving && engine.prefs.b("drivesimple", true))) Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextBtn(if (engine.tilt3d) "3D" else "2D", engine.tilt3d) { engine.toggleTilt() }
                RoundBtn(Icons.Rounded.Explore, { engine.toggleNorthUp() }, active = engine.northUp, size = 44.dp)
                RoundBtn(when (engine.soundMode) { 0 -> Icons.Rounded.VolumeUp; 1 -> Icons.Rounded.NotificationsActive; else -> Icons.Rounded.VolumeOff }, { engine.cycleSound() }, size = 44.dp)
                RoundBtn(Icons.Rounded.Layers, { layers = !layers }, active = layers, size = 44.dp)
                if (routing) RoundBtn(Icons.Rounded.Route, { engine.overview() }, size = 44.dp)
                if (engine.prefs.b("demo", false) || engine.simMode != 0) RoundBtn(Icons.Rounded.PlayArrow, { engine.cycleSim() }, active = engine.simMode != 0, size = 44.dp)
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RoundBtn(Icons.Rounded.MyLocation, { engine.recenter() }, active = engine.following, size = 56.dp)
                RoundBtn(Icons.Rounded.Add, { engine.zoom(1.0) }, size = 56.dp)
                RoundBtn(Icons.Rounded.Remove, { engine.zoom(-1.0) }, size = 56.dp)
            }
        }
        val topPad by animateDpAsState(if (engine.alert != null) 130.dp else 14.dp, tween(250), label = "alertShift")
        if (routing && !previewing && engine.turn?.lanes == null && engine.onRoad.isNotBlank() && engine.onRoad != engine.turn?.street) {
            Text(engine.onRoad, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = topPad).widthIn(max = 320.dp).clip(RoundedCornerShape(50)).background(Color(0xCC1A222D)).border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(50)).padding(horizontal = 16.dp, vertical = 7.dp))
        }
        if (routing && !previewing && engine.prefs.b("lanestrip", true)) engine.turn?.let { t ->
            t.lanes?.let { ls ->
                Box(Modifier.align(Alignment.TopCenter).padding(top = topPad).clip(RoundedCornerShape(24.dp)).background(Color(0xE61A222D)).border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(24.dp)).padding(horizontal = 4.dp, vertical = 2.dp)) {
                    LaneRow(ls, t.maneuver, t.dist < 400.0)
                }
            }
        }
        if (layers && !previewing) Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 150.dp).clip(RoundedCornerShape(20.dp)).background(c.surface.copy(alpha = 0.97f)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Map layers", color = c.sub, fontSize = 13.sp)
            LayerRow("Satellite", engine.prefs.b("satellite", false)) { engine.prefs.put("satellite", it) }
            LayerRow("Traffic", engine.prefs.b("traffic", true)) { engine.prefs.put("traffic", it) }
            LayerRow("3D buildings", engine.prefs.b("buildings3d", true)) { engine.prefs.put("buildings3d", it) }
            Text("Find nearby", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Fuel", engine.nearbyKind == "fuel", { engine.loadNearby("fuel", false); layers = false })
                Pill("EV", engine.nearbyKind == "charging", { engine.loadNearby("charging", false); layers = false })
                Pill("Parking", engine.nearbyKind == "parking", { engine.loadNearby("parking", false); layers = false })
            }
            if (engine.dest != null) Pill("Parking at destination", false, { engine.loadNearby("parking", true); layers = false })
        }
        if (engine.simMode != 0) {
            Text("DEMO ${engine.simMode}x", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).clip(RoundedCornerShape(50)).background(Warn).padding(horizontal = 10.dp, vertical = 4.dp))
        }

        // speed limit sign, bottom right of the map
        if (!previewing && engine.speedLimit != null) SpeedLimitSign(engine, 76.dp, Modifier.align(Alignment.BottomEnd).padding(14.dp))

        // bottom-left stack: hazard badges above the arrival pill, so they never overlap
        if (!previewing) {
            val inc = engine.incidentAhead
            val cam = engine.cameraDist
            val eta = engine.eta
            if (inc != null || cam != null || eta != null) Column(
                Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if ((inc != null && engine.alert?.kind != "incident") || (cam != null && engine.alert?.kind != "camera")) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (inc != null && engine.alert?.kind != "incident") HazardBadge("incident", inc.label, Geo.fmtDist(inc.dist, engine.imperial))
                    if (cam != null && engine.alert?.kind != "camera") HazardBadge("camera", "Speed camera", Geo.fmtDist(cam.toDouble(), engine.imperial))
                }
                eta?.let { e ->
                    val pill = RoundedCornerShape(32.dp)
                    val dc = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else Good
                    val frac = engine.routeFrac.coerceIn(0f, 1f)
                    val sevArr = engine.route?.sev
                    val prog = c.accent
                    Row(
                        Modifier.shadow(14.dp, pill).clip(pill).background(c.surface.copy(alpha = 0.97f)).border(1.dp, c.line.copy(alpha = 0.5f), pill)
                            .drawBehind {
                                // whole route as a strip: blue where clear, amber/red where traffic is slow; the part already driven is dimmed
                                val th = 4.dp.toPx()
                                val nb = 40
                                val bw = size.width / nb
                                for (b in 0 until nb) {
                                    var lvl = 0
                                    if (sevArr != null && sevArr.isNotEmpty()) {
                                        val from = b * sevArr.size / nb
                                        val to = minOf(sevArr.size, maxOf(from + 1, (b + 1) * sevArr.size / nb))
                                        for (i in from until to) if (sevArr[i] > lvl) lvl = sevArr[i]
                                    }
                                    val base = when (lvl) { 2 -> Bad; 1 -> Warn; else -> prog }
                                    val done = (b + 1f) / nb <= frac
                                    drawRect(base.copy(alpha = if (done) 0.22f else 1f), Offset(b * bw, size.height - th), androidx.compose.ui.geometry.Size(bw + 0.5f, th))
                                }
                            }
                            .padding(start = 22.dp, end = 8.dp, top = 8.dp, bottom = 11.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Column {
                            Text(Geo.fmtDur(e.secs), color = dc, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text(Geo.fmtDist(e.dist, engine.imperial) + " left", color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        }
                        Box(Modifier.width(1.dp).height(36.dp).background(c.line))
                        Column {
                            Text(e.arrive, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text("arrival", color = c.sub, fontSize = 14.sp)
                        }
                        if (e.delayMin >= 1) Text("+${e.delayMin}", color = dc, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(dc.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 4.dp))
                        RoundBtn(Icons.Rounded.Share, { shareEta() }, size = 44.dp)
                        RoundBtn(Icons.Rounded.Close, { engine.endRoute() }, size = 44.dp, active = true, tint = Color.White)
                    }
                }
            }
        }

        if (previewing) RoutePreview(engine)

        engine.arrival?.let { a -> ArrivalCard(engine, a, Modifier.align(Alignment.Center)) }

        engine.faster?.let { fr ->
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp).widthIn(max = 560.dp).floating(26.dp).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                IconBadge(Icons.Rounded.Route, Good, Modifier, 44.dp)
                Column {
                    Text("Faster route found", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Saves about ${fr.savedMin} min · arrive ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(System.currentTimeMillis() + (fr.route.time * 1000).toLong()))}", color = Good, fontSize = 14.sp)
                }
                Pill("Switch", true, { engine.acceptFaster() })
                Pill("Keep", false, { engine.dismissFaster() })
            }
        }

        if (engine.busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = c.accent)
    }
}

private fun viaOf(r: com.headunit.launcher.Route): String {
    var best = ""
    var bl = 0.0
    for (i in r.steps.indices) {
        val len = (r.steps.getOrNull(i + 1)?.off ?: r.len) - r.steps[i].off
        if (len > bl && r.steps[i].street.isNotBlank()) { bl = len; best = r.steps[i].street }
    }
    return best
}

/** Journey overview: route options plus a Start button that fills up and starts by itself after 5 s. */
@Composable
private fun BoxScope.RoutePreview(engine: NavEngine) {
    val c = LocalVw.current
    val rs = engine.routes.take(3)
    if (rs.isEmpty()) return
    val fastest = rs.indices.minByOrNull { rs[it].time } ?: 0
    val shortest = rs.indices.minByOrNull { rs[it].len } ?: 0
    val progress = remember { Animatable(0f) }
    LaunchedEffect(engine.active, engine.routes) {
        progress.snapTo(0f)
        progress.animateTo(1f, tween(10000, easing = LinearEasing))
        if (!engine.stopMode) engine.beginNavigation()
    }
    val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val baseMs = if (engine.departAtMs > 0) engine.departAtMs else System.currentTimeMillis()
    Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 10.dp, vertical = 4.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    val ctxP = androidx.compose.ui.platform.LocalContext.current
    val costKm = remember(engine.routes) { com.headunit.launcher.FuelStore(engine.prefs).costPerKm() }
    val selRoute = rs.getOrNull(engine.active)
    val costText = if (costKm != null && selRoute != null) "Fuel about " + java.text.NumberFormat.getCurrencyInstance().format(costKm * selRoute.len / 1000.0) else null
    if (engine.routeWx.isNotEmpty()) {
        val fahr = isImperial(engine.prefs)
        Row(
            Modifier.floating(50.dp).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("Weather on route", color = c.sub, fontSize = 13.sp)
            engine.routeWx.forEach { w ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(wxIcon(w.code), null, tint = wxTint(w.code), modifier = Modifier.size(24.dp))
                    Column(Modifier.padding(start = 6.dp)) {
                        Text((if (fahr) Math.round(w.temp * 9 / 5 + 32) else Math.round(w.temp)).toString() + "°", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("in ${if (w.minutes >= 60) "${w.minutes / 60} h ${w.minutes % 60} min" else "${w.minutes} min"}" + (if (w.rain >= 40) " · ${w.rain}%" else ""), color = if (w.rain >= 60) Warn else c.sub, fontSize = 11.sp)
                    }
                }
            }
        }
    }
    Row(
        Modifier.floating(50.dp).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("Stops", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 10.dp))
        Pill("+ Fuel", engine.stopMode && engine.nearbyKind == "fuel", { engine.stopMode = true; engine.loadNearby("fuel", false) })
        Pill("+ Charger", engine.stopMode && engine.nearbyKind == "charging", { engine.stopMode = true; engine.loadNearby("charging", false) })
        if (engine.via.isNotEmpty()) Text(engine.via.joinToString(" › ") { it.name }, color = c.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp))
        if (costText != null) Text(costText, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp))
        engine.destRain?.let { Text(it, color = Warn, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp)) }
    }
    Row(
        Modifier.floating(50.dp).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("Leave", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 10.dp))
        for ((label, m) in listOf("Now" to 0, "+15 min" to 15, "+30 min" to 30, "+1 h" to 60, "+2 h" to 120)) {
            Pill(label, engine.departMin == m, { if (engine.departMin != m) engine.setDeparture(m) })
        }
    }
    Row(
        Modifier.fillMaxWidth().floating(28.dp).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.width(150.dp)) {
            Text("Destination", color = c.sub, fontSize = 12.sp)
            Text(engine.dest?.name ?: "", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val d = engine.dest
            if (d != null) Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val fav = engine.places.isFavourite(d)
                Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favourite", tint = if (fav) Warn else c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.toast(if (engine.places.toggleFavourite(d)) "Saved to favourites" else "Removed from favourites", 2000) })
                Icon(Icons.Rounded.Home, "Set as home", tint = c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.places.setSlot("home", d); engine.toast("Home set to ${d.name}", 2500) })
                Icon(Icons.Rounded.Work, "Set as work", tint = c.sub,
                    modifier = Modifier.size(26.dp).clickable { engine.places.setSlot("work", d); engine.toast("Work set to ${d.name}", 2500) })
            }
        }
        rs.forEachIndexed { i, r ->
            val sel = i == engine.active
            val shape = RoundedCornerShape(18.dp)
            val label = if (i == fastest) "Fastest" else if (i == shortest) "Shortest" else "Alternative"
            Column(
                Modifier.weight(1f).inset(18.dp, if (sel) c.accent else null)
                                        .clickable { engine.selectRoute(i) }.padding(horizontal = 14.dp, vertical = 9.dp),
            ) {
                Text(label.uppercase(), color = if (sel) c.accent else c.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(Geo.fmtDur(r.time), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${Geo.fmtDist(r.len, engine.imperial)} · arrive ${fmt.format(java.util.Date(baseMs + (r.time * 1000).toLong()))}", color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val via = viaOf(r)
                val delayMin = Math.round(r.delay / 60.0).toInt()
                Text(
                    if (delayMin >= 1) "+$delayMin min traffic" else if (via.isNotEmpty()) "via $via" else "No delays",
                    color = if (delayMin >= 10) Bad else if (delayMin >= 1) Warn else c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            Modifier.width(210.dp).height(72.dp).clip(RoundedCornerShape(36.dp)).background(c.accent.copy(alpha = 0.30f))
                .clickable { engine.beginNavigation() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(progress.value).background(c.accent))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Start navigation", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Starting in ${kotlin.math.ceil((1f - progress.value) * 10f).toInt()} s", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        RoundBtn(Icons.Rounded.Close, { engine.endRoute() }, size = 46.dp)
    }
    }
}

@Composable
private fun TextBtn(label: String, active: Boolean, onClick: () -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape)
            .background(if (active) c.accent else c.surface.copy(alpha = 0.94f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (active) Color.White else c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun LayerRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalVw.current
    Row(Modifier.width(230.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(on, onChange)
    }
}

@Composable
private fun QuickChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalVw.current
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.shadow(6.dp, shape).clip(shape).background(c.surface).border(1.dp, c.line.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = c.accent, modifier = Modifier.size(20.dp))
        Text(label, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
    }
}

/** Under the search pill: quick-destination chips, a suggested trip, and saved / recent places (in the style of Google Maps). */
@Composable
private fun QuickPanel(engine: NavEngine, focusSearch: () -> Unit) {
    val c = LocalVw.current
    val home = engine.places.slot("home")
    val work = engine.places.slot("work")
    val car = engine.places.parked()
    val favs = engine.places.favourites()
    val recents = engine.places.recents().filter { r -> favs.none { Geo.dist(it.pos, r.pos) < 60 } }
    val saved: List<Pair<Place, Boolean>> = favs.map { it to true } + recents.take(4).map { it to false }
    val here = engine.fix?.pos
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickChip(Icons.Rounded.Home, if (home != null) "Home" else "Set home") {
                if (home != null) engine.startRoute(home) else { engine.pendingSave = "home"; engine.toast("Search for your home address", 3500); focusSearch() }
            }
            QuickChip(Icons.Rounded.Work, if (work != null) "Work" else "Set work") {
                if (work != null) engine.startRoute(work) else { engine.pendingSave = "work"; engine.toast("Search for your work address", 3500); focusSearch() }
            }
            QuickChip(Icons.Rounded.DirectionsCar, "My car") {
                if (car != null) engine.startRoute(car) else engine.toast("No parked location saved yet. It saves itself after you park.", 3500)
            }
            QuickChip(Icons.Rounded.LocalGasStation, "Fuel") { engine.loadNearby("fuel", false) }
            QuickChip(Icons.Rounded.EvStation, "EV") { engine.loadNearby("charging", false) }
            QuickChip(Icons.Rounded.LocalParking, "Parking") { engine.loadNearby("parking", false) }
        }
        engine.resume?.let { rp ->
            Row(
                Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(Good)
                    .clickable { engine.startRoute(rp) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Route, null, tint = Color.White, modifier = Modifier.size(26.dp))
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    Text("Resume trip to ${rp.name}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("You hadn't arrived when the app closed", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
                Icon(Icons.Rounded.Close, "Dismiss", tint = Color.White, modifier = Modifier.padding(start = 8.dp).size(24.dp).clickable { engine.resume = null; engine.prefs.put("resume", "{}") })
            }
        }
        val suggestion = remember { engine.habits.suggest(System.currentTimeMillis()) }
        if (suggestion != null) Row(
            Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp)).background(c.accent)
                .clickable { engine.startRoute(suggestion) }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.History, null, tint = Color.White, modifier = Modifier.size(26.dp))
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text("Going to ${suggestion.name}?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (suggestion.sub.isNotBlank()) Text(suggestion.sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Go", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (saved.isNotEmpty()) Column(
            Modifier.fillMaxWidth().shadow(10.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.surface.copy(alpha = 0.98f))
                .border(1.dp, c.line.copy(alpha = 0.5f), RoundedCornerShape(24.dp)).padding(vertical = 8.dp),
        ) {
            SectionLabel("Saved & recent", Modifier.padding(start = 18.dp, top = 6.dp, bottom = 4.dp))
            LazyColumn(Modifier.heightIn(max = 230.dp)) {
                items(saved) { (p, fav) ->
                    Row(Modifier.fillMaxWidth().clickable { engine.startRoute(p) }.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).background((if (fav) Warn else c.sub).copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                            Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.History, null, tint = if (fav) Warn else c.sub, modifier = Modifier.size(22.dp))
                        }
                        Column(Modifier.padding(start = 12.dp).weight(1f)) {
                            Text(p.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (p.sub.isNotBlank()) Text(p.sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (here != null) Text(Geo.fmtDist(Geo.dist(here, p.pos), engine.imperial), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ArrivalStat(value: String, label: String) {
    val c = LocalVw.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = c.sub, fontSize = 12.sp)
    }
}

/** Shown for a few seconds after arriving, with how the trip went and a button to save the place. */
@Composable
private fun ArrivalCard(engine: NavEngine, a: ArrivalInfo, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    val imp = engine.imperial
    val k = if (imp) 2.23694 else 3.6
    Column(
        modifier.widthIn(min = 380.dp, max = 460.dp).floating(28.dp).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(64.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Good.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Check, null, tint = Good, modifier = Modifier.size(38.dp))
        }
        Text("You've arrived", color = c.sub, fontSize = 14.sp)
        Text(a.name, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ArrivalStat(Geo.fmtDist(a.dist, imp), "distance")
            ArrivalStat(Geo.fmtDur(a.secs), "time")
            ArrivalStat("${Math.round(a.avgMs * k)} ${if (imp) "mph" else "km/h"}", "average")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            a.place?.let { p ->
                var fav by remember { mutableStateOf(engine.places.isFavourite(p)) }
                Pill(if (fav) "Saved" else "Save place", fav, { fav = engine.places.toggleFavourite(p) })
            }
            Pill("Done", true, { engine.arrival = null })
        }
    }
}

@Composable
private fun NearbyCard(engine: NavEngine) {
    val c = LocalVw.current
    val adding = engine.stopMode || engine.route != null
    val title = (if (adding) "Add a stop: " else "") + when (engine.nearbyKind) { "fuel" -> "Fuel stations"; "charging" -> "Charging points"; else -> "Car parks" }
    Column(Modifier.floating(24.dp).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(when (engine.nearbyKind) { "fuel" -> Icons.Rounded.LocalGasStation; "charging" -> Icons.Rounded.EvStation; else -> Icons.Rounded.LocalParking }, c.accent, Modifier.padding(end = 12.dp), 36.dp)
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (engine.nearbyBusy) CircularProgressIndicator(Modifier.size(18.dp), color = c.accent, strokeWidth = 2.dp)
            Icon(Icons.Rounded.Close, "Close", tint = c.sub, modifier = Modifier.padding(start = 12.dp).size(22.dp).clickable { engine.clearNearby() })
        }
        LazyColumn(Modifier.heightIn(max = 200.dp).padding(top = 6.dp)) {
            items(engine.nearby) { n ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { if (adding) engine.addStop(n.place) else engine.startRoute(n.place) }.padding(vertical = 8.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c.accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(when (engine.nearbyKind) { "fuel" -> Icons.Rounded.LocalGasStation; "charging" -> Icons.Rounded.EvStation; else -> Icons.Rounded.LocalParking }, null, tint = c.accent, modifier = Modifier.size(20.dp))
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(n.place.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (n.extra.isNotBlank()) Text(n.extra, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(Geo.fmtDist(n.dist, engine.imperial), color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp).clip(RoundedCornerShape(50)).background(c.accent.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp))
                }
            }
        }
    }
}


private fun laneAngle(d: String): Float = when (d) {
    "SLIGHT_LEFT" -> -45f; "LEFT" -> -90f; "SHARP_LEFT" -> -135f; "LEFT_U_TURN" -> -180f
    "SLIGHT_RIGHT" -> 45f; "RIGHT" -> 90f; "SHARP_RIGHT" -> 135f; "RIGHT_U_TURN" -> 180f
    else -> 0f
}

private fun laneMatches(dir: String, maneuver: String): Boolean {
    val m = maneuver.uppercase()
    return when {
        m.contains("U_TURN") -> dir.endsWith("U_TURN")
        m.contains("LEFT") -> dir.contains("LEFT")
        m.contains("RIGHT") -> dir.contains("RIGHT")
        else -> dir == "STRAIGHT"
    }
}

@Composable
private fun LaneRow(sec: LaneSec, maneuver: String, near: Boolean = false) {
    val big by androidx.compose.animation.core.animateFloatAsState(if (near) 1f else 0f, androidx.compose.animation.core.tween(400), label = "laneBig")
    val anyFollow = sec.lanes.any { it.follow != null }
    val pulse by androidx.compose.animation.core.rememberInfiniteTransition(label = "lanePulse").animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800, easing = androidx.compose.animation.core.FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "lanePulseV",
    )
    val cellW = (42 + 8 * big).dp
    val gap = 6.dp
    val n = sec.lanes.size
    val accent = Color(0xFF7CCBFF)
    androidx.compose.foundation.Canvas(
        Modifier.width(cellW * n + gap * (n - 1) + 12.dp).height((70 + 12 * big).dp)
    ) {
        val pad = 6.dp.toPx()
        val g = gap.toPx()
        val cw = (size.width - 2 * pad - g * (n - 1)) / n
        val ch = size.height - 2 * pad
        val stroke = 4.5.dp.toPx()
        val round = androidx.compose.ui.graphics.StrokeCap.Round
        fun o(x: Float, y: Float) = androidx.compose.ui.geometry.Offset(x, y)
        sec.lanes.forEachIndexed { idx, lane ->
            val x0 = pad + idx * (cw + g)
            val cx = x0 + cw / 2
            val active = if (anyFollow) lane.follow != null else lane.dirs.any { laneMatches(it, maneuver) }
            val corner = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx())
            val sz = androidx.compose.ui.geometry.Size(cw, ch)
            if (active) {
                // soft glow, gradient fill and a bright pulsing edge
                drawRoundRect(accent.copy(alpha = 0.10f + 0.16f * pulse), o(x0 - 4.dp.toPx(), pad - 4.dp.toPx()), androidx.compose.ui.geometry.Size(cw + 8.dp.toPx(), ch + 8.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(15.dp.toPx()))
                drawRoundRect(
                    androidx.compose.ui.graphics.Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f + 0.2f * pulse), accent.copy(alpha = 0.18f + 0.1f * pulse)), startY = pad, endY = pad + ch),
                    o(x0, pad), sz, corner,
                )
                drawRoundRect(accent.copy(alpha = 0.6f + 0.4f * pulse), o(x0, pad), sz, corner, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
            } else {
                drawRoundRect(Color.White.copy(alpha = 0.06f), o(x0, pad), sz, corner)
            }
            lane.dirs.forEach { d ->
                val hit = if (anyFollow) d == lane.follow else laneMatches(d, maneuver)
                val col = Color.White.copy(alpha = if (active && hit) 1f else if (active) 0.55f else 0.28f)
                val bob = if (active && hit) -5.dp.toPx() * pulse else 0f
                val baseY = pad + ch - 12.dp.toPx() + bob
                val midY = pad + ch * 0.55f + bob
                val len = 17.dp.toPx()
                drawLine(col, o(cx, baseY), o(cx, midY), stroke, round)
                rotate(laneAngle(d), o(cx, midY)) {
                    val tip = o(cx, midY - len)
                    drawLine(col, o(cx, midY), tip, stroke, round)
                    val hd = 7.dp.toPx()
                    drawLine(col, tip, o(cx - hd, tip.y + hd), stroke, round)
                    drawLine(col, tip, o(cx + hd, tip.y + hd), stroke, round)
                }
            }
        }
    }
}
