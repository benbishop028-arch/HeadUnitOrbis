package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ThreeDRotation
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Geo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import kotlinx.coroutines.delay

@Composable
fun NavPage(engine: NavEngine, map: MapBinding) {
    val c = LocalVw.current
    var q by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(q) {
        if (q.length >= 3) { delay(500); engine.search(q) } else if (q.isEmpty()) engine.results = emptyList()
    }

    Box(Modifier.fillMaxSize()) {
        MapHost(map, Modifier.fillMaxSize())

        val routing = engine.route != null
        // left column: search / turn card
        Column(Modifier.align(Alignment.TopStart).padding(14.dp).width(360.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!routing) {
                TextField(
                    value = q, onValueChange = { q = it },
                    placeholder = { Text("Search address or place") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { if (q.isNotEmpty()) Icon(Icons.Rounded.Close, null, Modifier.clickable { q = ""; engine.results = emptyList() }) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { engine.search(q) }),
                    shape = RoundedCornerShape(50),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = c.surface, unfocusedContainerColor = c.surface,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (engine.results.isNotEmpty()) {
                    LazyColumn(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface).fillMaxWidth()) {
                        items(engine.results) { p ->
                            Column(Modifier.fillMaxWidth().clickable { q = ""; engine.startRoute(p) }.padding(horizontal = 18.dp, vertical = 11.dp)) {
                                Text(p.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(p.sub, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                } else if (q.isEmpty()) {
                    Text(
                        "Tip: long-press anywhere on the map to drop a pin and route there.",
                        color = c.text, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(c.surface.copy(alpha = 0.9f)).padding(10.dp),
                    )
                }
            } else {
                engine.turn?.let { t ->
                    Column(Modifier.clip(RoundedCornerShape(22.dp)).background(Blue)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(64.dp))
                            Column(Modifier.padding(start = 14.dp)) {
                                Text(Geo.fmtDist(t.dist, engine.imperial), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Text(t.street, color = Color.White, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (t.thenManeuver != null) {
                            Row(Modifier.fillMaxWidth().background(BlueSoft).padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                ManeuverArrow(t.thenManeuver, Geo.maneuverAngle(t.thenManeuver), Modifier.size(26.dp))
                                Text(t.thenText, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp))
                            }
                        }
                    }
                }
            }
        }

        // right: round buttons
        Column(Modifier.align(Alignment.CenterEnd).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RoundBtn(Icons.Rounded.Add, { engine.zoom(1.0) })
            RoundBtn(Icons.Rounded.Remove, { engine.zoom(-1.0) })
            RoundBtn(Icons.Rounded.ThreeDRotation, { engine.toggleTilt() }, active = engine.tilt3d)
            RoundBtn(Icons.Rounded.MyLocation, { engine.recenter() }, active = engine.following)
            RoundBtn(if (engine.voiceOn) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff, { engine.prefs.put("voice", !engine.voiceOn) })
            RoundBtn(Icons.Rounded.Layers, { if (routing) engine.cycleRoute() else engine.toggleAlternatives() }, active = engine.alternatives)
            RoundBtn(Icons.Rounded.PlayArrow, { engine.cycleSim() }, active = engine.simMode != 0)
        }
        if (engine.simMode != 0) {
            Text("DEMO ${engine.simMode}x", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).clip(RoundedCornerShape(50)).background(Warn).padding(horizontal = 10.dp, vertical = 4.dp))
        }

        // bottom ETA bar
        engine.eta?.let { e ->
            Row(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp).clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.97f)).padding(start = 26.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp),
            ) {
                Column { Text(e.arrive, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("arrival", color = c.sub, fontSize = 11.sp) }
                Column { Text(Geo.fmtDur(e.secs), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("time", color = c.sub, fontSize = 11.sp) }
                Column { Text(Geo.fmtDist(e.dist, engine.imperial), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("distance", color = c.sub, fontSize = 11.sp) }
                if (e.delayMin >= 1) Text("+${e.delayMin} min", color = if (e.delayMin >= 10) Bad else Warn, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (engine.routes.size > 1) Text("Route ${engine.active + 1}/${engine.routes.size}", color = c.sub, fontSize = 13.sp)
                RoundBtn(Icons.Rounded.Close, { engine.endRoute() }, size = 48.dp, active = true, tint = Color.White)
            }
        }

        if (engine.busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = c.accent)
    }
}
