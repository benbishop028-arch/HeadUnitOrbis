package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Screen(val label: String, val icon: ImageVector) {
    Nav("Nav", Icons.Filled.Navigation),
    Media("Media", Icons.Filled.MusicNote),
    Call("Call", Icons.Filled.Call),
    Settings("Settings", Icons.Filled.DirectionsCar),
    Apps("Apps", Icons.Filled.Apps),
}

@Composable
fun LauncherRoot(homeTick: Int, locationReady: Boolean) {
    var screen by rememberSaveable { mutableStateOf(Screen.Nav) }
    val dark = isSystemInDarkTheme()
    var diag by remember { mutableStateOf(false) }

    LaunchedEffect(homeTick) { if (homeTick > 0) screen = Screen.Nav }

    Row(Modifier.fillMaxSize().background(Rail)) {
        SideRail(screen) { screen = it }

        Box(Modifier.weight(1f).fillMaxHeight()) {
            // Non-map pages sit underneath; the single map instance is drawn on top of them
            when (screen) {
                Screen.Media -> MediaScreen()
                Screen.Call -> CallScreen()
                Screen.Settings -> SettingsScreen(onOpenDiag = { diag = true })
                Screen.Apps -> AppsScreen()
                Screen.Nav -> Unit
            }

            val isNav = screen == Screen.Nav
            val pipShape = RoundedCornerShape(20.dp)
            val mapModifier = if (isNav) Modifier.fillMaxSize() else Modifier
                .align(Alignment.BottomEnd).padding(20.dp).size(360.dp, 210.dp)
                .clip(pipShape).border(1.dp, Line, pipShape)

            if (locationReady && !diag) {
                NavWeb(pip = !isNav, dark = dark, modifier = mapModifier)
            }

            if (!isNav && !diag) {
                // Tap the picture-in-picture window to expand it back to full navigation
                Box(Modifier.align(Alignment.BottomEnd).padding(20.dp).size(360.dp, 210.dp)
                    .clip(pipShape).clickable { screen = Screen.Nav })
            }

            if (diag) NativeDiagScreen(onClose = { diag = false })
        }
    }
}

@Composable
private fun SideRail(selected: Screen, onSelect: (Screen) -> Unit) {
    Column(Modifier.width(104.dp).fillMaxHeight().background(Rail).padding(vertical = 8.dp)) {
        Screen.entries.forEach { s ->
            val on = s == selected
            Column(
                Modifier.weight(1f).fillMaxWidth().clickable { onSelect(s) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(s.icon, s.label, tint = if (on) Accent else TextDim, modifier = Modifier.size(38.dp))
                Spacer(Modifier.height(6.dp))
                Text(s.label, color = if (on) Ink else TextDim, fontSize = 17.sp)
            }
        }
    }
}
