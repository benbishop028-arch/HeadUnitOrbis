package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.headunit.launcher.nav.NavViewModel

enum class Screen(val label: String, val icon: ImageVector) {
    Nav("Nav", Icons.Filled.Navigation),
    Media("Media", Icons.Filled.MusicNote),
    Call("Call", Icons.Filled.Call),
    Settings("Settings", Icons.Filled.DirectionsCar),
    Apps("Apps", Icons.Filled.Apps),
}

@Composable
fun LauncherRoot(vm: NavViewModel, homeTick: Int) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(Screen.Nav) }
    var follow by remember { mutableStateOf(true) }
    var tilt3d by remember { mutableStateOf(true) }
    var searching by remember { mutableStateOf(false) }

    LaunchedEffect(homeTick) { if (homeTick > 0) { screen = Screen.Nav; searching = false } }
    LaunchedEffect(ui.navigating) { if (ui.navigating) follow = true }

    Row(Modifier.fillMaxSize().background(Rail)) {
        SideRail(screen) { screen = it; searching = false }

        Box(Modifier.weight(1f).fillMaxHeight()) {
            // Non-map pages sit underneath; the single map instance is drawn on top of them
            when (screen) {
                Screen.Media -> MediaScreen()
                Screen.Call -> CallScreen()
                Screen.Settings -> SettingsScreen()
                Screen.Apps -> AppsScreen()
                Screen.Nav -> Unit
            }

            val isNav = screen == Screen.Nav
            val pipShape = RoundedCornerShape(20.dp)
            val mapModifier = if (isNav) Modifier.fillMaxSize() else Modifier
                .align(Alignment.BottomEnd).padding(20.dp).size(360.dp, 210.dp)
                .clip(pipShape).border(1.dp, Line, pipShape)

            NavMap(ui = ui, routingInfrastructure = vm.routingVisualizationInfrastructure, follow = follow, tilt3d = tilt3d, modifier = mapModifier, onPan = { follow = false })

            if (isNav) {
                ui.guidance?.let { GuidanceBanner(it, Modifier.align(Alignment.TopStart).padding(16.dp)) }

                Column(Modifier.align(Alignment.TopEnd).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    RoundBtn(Icons.Filled.Search, "Search", { searching = true }, ring = Green)
                }
                Column(Modifier.align(Alignment.BottomEnd).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    RoundTextBtn(if (tilt3d) "3D" else "2D", { tilt3d = !tilt3d }, active = tilt3d)
                    RoundBtn(Icons.Filled.MyLocation, "Recenter", { follow = true }, active = follow)
                }

                EtaBar(ui, onStop = vm::stopNavigation, onSearch = { searching = true },
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp))

                if (searching) {
                    SearchPanel(
                        results = ui.results, onSearch = vm::searchPlaces,
                        onPick = { searching = false; vm.navigateTo(it) },
                        onClose = { searching = false; vm.clearResults() },
                        modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
                    )
                }
            } else {
                // Tap the picture-in-picture window to expand it back to full navigation
                Box(Modifier.align(Alignment.BottomEnd).padding(20.dp).size(360.dp, 210.dp)
                    .clip(pipShape).clickable { screen = Screen.Nav }) {
                    ui.guidance?.let { PipChip(it, Modifier.align(Alignment.TopStart).padding(10.dp)) }
                }
            }

            Text(
                "SDK ${if (ui.sdkReady) "ready" else "starting"} · GPS ${if (ui.position != null) "fix" else "none"} · key ${com.headunit.launcher.BuildConfig.TOMTOM_API_KEY.length} chars",
                color = Color(0xFF8A93A0), fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
            )

            ui.message?.let { msg ->
                Text(
                    msg, color = Color.White, fontSize = 18.sp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp)
                        .clip(RoundedCornerShape(12.dp)).background(Panel)
                        .clickable { vm.dismissMessage() }.padding(horizontal = 20.dp, vertical = 12.dp),
                )
            }
        }
    }
}

@Composable
private fun SideRail(selected: Screen, onSelect: (Screen) -> Unit) {
    Column(Modifier.width(104.dp).fillMaxHeight().background(Rail).padding(vertical = 8.dp)) {
        Screen.entries.forEach { s ->
            val on = s == selected
            Column(
                Modifier.weight(1f).fillMaxWidth().clickable { onSelect(s) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(s.icon, s.label, tint = if (on) Accent else Color(0xFFB8C0CC), modifier = Modifier.size(38.dp))
                Spacer(Modifier.height(6.dp))
                Text(s.label, color = if (on) Color.White else Color(0xFFB8C0CC), fontSize = 17.sp)
            }
        }
    }
}
