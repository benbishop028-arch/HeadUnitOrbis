package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs

/** Everything that changes how the map looks, routes and warns, in one place. */
@Composable
fun MapSettingsPage(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    var cat by remember { mutableIntStateOf(0) }
    val cats = listOf(
        "Theme & map" to Icons.Rounded.Palette, "Route" to Icons.Rounded.Route, "On screen" to Icons.Rounded.Visibility,
        "Performance" to Icons.Rounded.Speed, "Alerts" to Icons.Rounded.NotificationsActive, "Voice & sound" to Icons.Rounded.VolumeUp,
        "Offline maps" to Icons.Rounded.CloudDownload, "Data & keys" to Icons.Rounded.Storage,
    )
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.width(240.dp).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Map, null, tint = c.accent, modifier = Modifier.size(22.dp))
                    Text("Map settings", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
                }
                cats.forEachIndexed { i, (label, icon) ->
                    val on = i == cat
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (on) c.tile else Color.Transparent).clickable { cat = i }.padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = if (on) c.accent else c.sub, modifier = Modifier.size(26.dp))
                        Text(label, color = if (on) c.text else c.sub, fontSize = 17.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(start = 14.dp))
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
                PageTitle(cats[cat].first, modifier = Modifier.padding(bottom = 8.dp))
                when (cat) {
                    0 -> {
                        Row2("Map theme") {
                            Pill("Modern", prefs.s("maptheme", "immersive") == "immersive", { prefs.put("maptheme", "immersive") })
                            Pill("Classic", prefs.s("maptheme", "immersive") == "classic", { prefs.put("maptheme", "classic") })
                        }
                        Row2("Night street lamp spacing") {
                            var lv by remember { mutableStateOf(prefs.s("lampgap", "40").toFloatOrNull() ?: 40f) }
                            androidx.compose.material3.Slider(
                                value = lv, onValueChange = { lv = it },
                                onValueChangeFinished = { prefs.put("lampgap", Math.round(lv).toString()) },
                                valueRange = 15f..120f,
                                modifier = Modifier.width(300.dp),
                            )
                            Text("${Math.round(lv)} m", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
                            Pill("Reset", false, { lv = 40f; prefs.put("lampgap", "40") })
                        }
                        Row2("Locator arrow size") {
                            var av by remember { mutableStateOf(prefs.s("arrowpct", "240").toFloatOrNull() ?: 240f) }
                            androidx.compose.material3.Slider(
                                value = av, onValueChange = { av = it },
                                onValueChangeFinished = { prefs.put("arrowpct", Math.round(av).toString()) },
                                valueRange = 100f..500f,
                                modifier = Modifier.width(300.dp),
                            )
                            Text("${Math.round(av)}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
                            Pill("Reset", false, { av = 240f; prefs.put("arrowpct", "240") })
                        }
                        Text(
                            "Modern recolours the map in soft, light tones, draws a blue route with traffic painted on it, a Google-style blue arrow and red destination pin, and turns the turn card green with a bold arrow. Both themes follow day and night.",
                            color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                        )
                        Row2("Map source") {
                            Pill("TomTom Orbis", prefs.s("mapstyle", "tomtom") == "tomtom", { prefs.put("mapstyle", "tomtom") })
                            Pill("OpenStreetMap (free)", prefs.s("mapstyle", "tomtom") == "osm", { prefs.put("mapstyle", "osm") })
                            Pill("Google Maps", prefs.s("mapstyle", "tomtom") == "google", { prefs.put("mapstyle", "google") })
                        }
                        Text("The Modern colours apply to the TomTom and OpenStreetMap styles. Google's own map picture keeps Google's colours, but the route, arrow and cards still change.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                        Row2("Live traffic on map") { Switch(prefs.b("traffic", true), { prefs.put("traffic", it) }) }
                        Row2("Rain effect on map") { Switch(prefs.b("rainfx", false), { prefs.put("rainfx", it) }) }
                    }
                    1 -> {
                        Row2("Avoid toll roads") { Switch(prefs.b("avoid_toll", false), { prefs.put("avoid_toll", it) }) }
                        Row2("Avoid motorways") { Switch(prefs.b("avoid_motorway", false), { prefs.put("avoid_motorway", it) }) }
                        Row2("Avoid ferries") { Switch(prefs.b("avoid_ferry", false), { prefs.put("avoid_ferry", it) }) }
                        Row2("Avoid unpaved roads") { Switch(prefs.b("avoid_unpaved", true), { prefs.put("avoid_unpaved", it) }) }
                        Row2("Eco route (fuel-efficient instead of fastest)") { Switch(prefs.b("route_eco", false), { prefs.put("route_eco", it) }) }
                        Row2("Suggest faster routes while driving") { Switch(prefs.b("fasterroute", true), { prefs.put("fasterroute", it) }) }
                        Row2("Weather on route") { Switch(prefs.b("routewx", true), { prefs.put("routewx", it) }) }
                    }
                    2 -> {
                        Row2("Show my speed next to the limit sign") { Switch(prefs.b("mapspeed", true), { prefs.put("mapspeed", it) }) }
                        Row2("Hide traffic colours on other roads while navigating (the route shows its own)") { Switch(prefs.b("routetrafficonly", true), { prefs.put("routetrafficonly", it) }) }
                        Row2("Keep the arrow on the road when there is no route") { Switch(prefs.b("snaproad", true), { prefs.put("snaproad", it) }) }
                        Row2("Flatten the map to 2D for turns and junctions") { Switch(prefs.b("turn2d", true), { prefs.put("turn2d", it) }) }
                        Row2("Switch to the full-screen map when driving over 5 mph") { Switch(prefs.b("autofull", true), { prefs.put("autofull", it) }) }
                        Row2("Lane arrows painted on the map") { Switch(prefs.b("lanemap", true), { prefs.put("lanemap", it) }) }
                        Row2("Lane guidance strip") { Switch(prefs.b("lanestrip", true), { prefs.put("lanestrip", it) }) }
                        Row2("Lock typing while driving (voice search still works)") { Switch(prefs.b("drivelock", true), { prefs.put("drivelock", it) }) }
                        Row2("Show demo-drive button on the map") { Switch(prefs.b("demo", false), { prefs.put("demo", it) }) }
                    }
                    3 -> {
                        Text("Lower these if the map feels slow or the head unit gets warm. Sharpness and fast rendering apply after restarting the app.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                        Row2("Map sharpness (lower is smoother on a slow head unit; restart the app to apply)") {
                            for ((n, l) in listOf("100" to "Full", "80" to "Balanced", "65" to "Light", "50" to "Lowest")) Pill(l, prefs.s("mapres", "80") == n, { prefs.put("mapres", n) })
                        }
                        Row2("Fast map rendering (restart the app to apply; map corners may look square)") { Switch(prefs.b("mapfast", true), { prefs.put("mapfast", it) }) }
                        Row2("Map frame rate (lower is lighter on the head unit)") {
                            for (n in listOf("20", "30", "45", "60")) Pill(n, prefs.s("mapfps", "30") == n, { prefs.put("mapfps", n) })
                        }
                        Row2("Light map (hides points of interest and the route glow, and lowers the tilt)") { Switch(prefs.b("maplite", true), { prefs.put("maplite", it) }) }
                        Row2("Show performance monitor (map fps and stalls: send me a screenshot)") { Switch(prefs.b("perfmon", false), { prefs.put("perfmon", it) }) }
                        Row2("Simplify map while driving") { Switch(prefs.b("drivesimple", true), { prefs.put("drivesimple", it) }) }
                    }
                    4 -> {
                        Row2("Speed camera alerts") { Switch(prefs.b("cameras", true), { prefs.put("cameras", it) }) }
                        Row2("Police reports (made with the bar button)") { Switch(prefs.b("policealerts", true), { prefs.put("policealerts", it) }) }
                        Row2("Speed limit change alert") { Switch(prefs.b("limitchange", true), { prefs.put("limitchange", it) }) }
                        Row2("Roadworks & incident alerts") { Switch(prefs.b("incidents", true), { prefs.put("incidents", it) }) }
                        Row2("Speed limit warning") { Switch(prefs.b("speedwarn", true), { prefs.put("speedwarn", it) }) }
                        Row2("Warn when over by") {
                            for (t in listOf("0", "5", "10")) Pill(t + if (engine.imperial) " mph" else " km/h", prefs.s("warntol", "5") == t, { prefs.put("warntol", t) })
                        }
                        Row2("Test alert sound") { Pill("Play test alert", false, { engine.testAlert() }) }
                    }
                    5 -> {
                        Row2("Sound") {
                            Pill("All", engine.soundMode == 0, { prefs.put("soundmode", 0) })
                            Pill("Alerts only", engine.soundMode == 1, { prefs.put("soundmode", 1) })
                            Pill("Off", engine.soundMode == 2, { prefs.put("soundmode", 2) })
                        }
                        Text("Alerts only skips turn-by-turn voice but still speaks and chimes for speed cameras, speed limit changes, incidents, rain and break reminders.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                        Row2("Read messages aloud") { Switch(prefs.b("readmsgs", false), { prefs.put("readmsgs", it) }) }
                    }
                    6 -> OfflineMapsContent(prefs, engine)
                    else -> {
                        Row2("Search results") {
                            Pill("United Kingdom first", prefs.s("country", "GB") == "GB", { prefs.put("country", "GB") })
                            Pill("Anywhere", prefs.s("country", "GB").isEmpty(), { prefs.put("country", "") })
                        }
                        Row2("TomTom API key") {
                            var key by remember { mutableStateOf(prefs.s("apikey", "")) }
                            TextField(
                                value = key, onValueChange = { key = it; prefs.put("apikey", it.trim()) },
                                placeholder = { Text(if (engine.hasKey) "Using the key built into this app" else "Paste a key to enable search & routing") },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile),
                                modifier = Modifier.width(420.dp),
                            )
                        }
                        Row2("Offline places (UK towns and villages, so you can search without signal)") {
                            val ctxO = androidx.compose.ui.platform.LocalContext.current
                            val scO = androidx.compose.runtime.rememberCoroutineScope()
                            var stateO by remember { mutableStateOf(if (com.headunit.launcher.OfflinePlaces.installed(ctxO)) "Installed (%.1f MB)".format(com.headunit.launcher.OfflinePlaces.sizeMb(ctxO)) else "Not downloaded") }
                            var busyO by remember { mutableStateOf(false) }
                            Text(stateO, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
                            Pill(if (busyO) "Downloading…" else if (com.headunit.launcher.OfflinePlaces.installed(ctxO)) "Update" else "Download", false, {
                                if (!busyO) {
                                    busyO = true; stateO = "Downloading (needs signal)…"
                                    scO.launch {
                                        try {
                                            val n = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.headunit.launcher.OfflinePlaces.download(ctxO) }
                                            stateO = "Installed: $n places"; engine.toast("Offline places ready", 3000)
                                        } catch (e: Exception) { stateO = "Failed: ${e.message}" } finally { busyO = false }
                                    }
                                }
                            })
                            if (com.headunit.launcher.OfflinePlaces.installed(ctxO) && !busyO) Pill("Remove", false, { com.headunit.launcher.OfflinePlaces.delete(ctxO); stateO = "Not downloaded" })
                        }
                        Text("Search also finds places you saved or routed to before. With no signal, routes, the map and search for streets and shops come from the pack on the Offline maps page. Without a pack, a route you pick starts by itself when the connection returns.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                        if (prefs.s("mapstyle", "tomtom") == "google") Row2("Google Maps API key") {
                            var gk by remember { mutableStateOf(prefs.s("gkey", "")) }
                            TextField(
                                value = gk, onValueChange = { gk = it; prefs.put("gkey", it.trim()) },
                                placeholder = { Text("Key with Map Tiles API enabled") },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile),
                                modifier = Modifier.width(420.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
