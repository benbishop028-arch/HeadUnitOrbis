package com.headunit.launcher.ui

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.BuildConfig
import com.tomtom.sdk.common.configuration.buildSdkConfiguration
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.map.display.camera.InitialCameraOptions
import com.tomtom.sdk.map.display.compose.TomTomMap
import com.tomtom.sdk.map.display.compose.model.MapDisplayInfrastructure
import com.tomtom.sdk.map.display.compose.state.rememberMapViewState
import com.tomtom.sdk.map.display.style.*
import com.tomtom.sdk.telemetry.UserConsent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val LONDON = GeoPoint(latitude = 51.5074, longitude = -0.1278)

/** Minimal, documented TomTom native map plus device/network checks, to find out why roads don't draw. */
@Composable
fun NativeDiagScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var sdkStatus by remember { mutableStateOf("starting…") }
    var sdkReady by remember { mutableStateOf(false) }
    var styleStatus by remember { mutableStateOf("not tested") }
    var tileStatus by remember { mutableStateOf("not tested") }
    var useDriving by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) {
            try {
                if (!TomTomSdk.isInitialized) {
                    val cfg = buildSdkConfiguration(
                        context = ctx.applicationContext,
                        apiKey = BuildConfig.TOMTOM_API_KEY,
                        telemetryUserConsent = { UserConsent.TelemetryOff },
                    )
                    TomTomSdk.initialize(context = ctx.applicationContext, sdkConfiguration = cfg)
                }
                sdkStatus = "initialised OK"
                sdkReady = true
            } catch (t: Throwable) {
                sdkStatus = "FAILED: ${t.javaClass.simpleName}: ${t.message}"
            }
        }
        // Device -> TomTom network checks, using the same key the app was built with
        val key = BuildConfig.TOMTOM_API_KEY
        styleStatus = httpCode("https://api.tomtom.com/maps/orbis/assets/styles/0.*/style.json?key=$key&apiVersion=1&map=basic_street-light-driving")
        tileStatus = httpCode("https://api.tomtom.com/maps/orbis/map-display/tile/14/8186/5448.pbf?apiVersion=1&key=$key")
    }

    Row(Modifier.fillMaxSize().background(Rail).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.width(330.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Native SDK test", color = Ink, fontSize = 22.sp)
            Text("← Back", color = Accent, fontSize = 18.sp, modifier = Modifier.clickable { onClose() }.padding(vertical = 6.dp))
            diagLines(ctx).forEach { Text(it, color = TextDim, fontSize = 13.sp) }
            Text("SDK init: $sdkStatus", color = Ink, fontSize = 13.sp)
            Text("Style request: $styleStatus", color = Ink, fontSize = 13.sp)
            Text("Tile request: $tileStatus", color = Ink, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = useDriving, onCheckedChange = { useDriving = it })
                Text("  Explicit driving style", color = Ink, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = dark, onCheckedChange = { dark = it })
                Text("  Dark style mode", color = Ink, fontSize = 14.sp)
            }
        }
        Box(
            Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).border(1.dp, Line, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (sdkReady) {
                key(useDriving) {
                    val state = if (useDriving) {
                        rememberMapViewState(
                            initialCameraOptions = InitialCameraOptions.LocationBased(position = LONDON, zoom = 14.0),
                            initialStyle = StandardStyles.TomTomOrbisMaps.DRIVING,
                        )
                    } else {
                        rememberMapViewState(
                            initialCameraOptions = InitialCameraOptions.LocationBased(position = LONDON, zoom = 14.0),
                        )
                    }
                    LaunchedEffect(dark) {
                        state.styleState.styleMode = if (dark) StyleMode.DARK else StyleMode.MAIN
                    }
                    TomTomMap(
                        state = state,
                        infrastructure = remember { MapDisplayInfrastructure(sdkContext = TomTomSdk.sdkContext) {} },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                Text("Waiting for SDK…", color = TextDim)
            }
        }
    }
}

private suspend fun httpCode(url: String): String = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 10_000
        val code = c.responseCode
        val len = c.contentLengthLong
        c.disconnect()
        "HTTP $code" + if (len >= 0) " ($len bytes)" else ""
    } catch (t: Throwable) {
        "ERROR ${t.javaClass.simpleName}: ${t.message}"
    }
}

private fun diagLines(ctx: Context): List<String> {
    val pm = ctx.packageManager
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val vulkan = pm.systemAvailableFeatures.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val v = vulkan?.version ?: 0
    return listOf(
        "Device: ${Build.MANUFACTURER} ${Build.MODEL}",
        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "ABIs: ${Build.SUPPORTED_ABIS.joinToString()}",
        "Vulkan: " + if (vulkan == null) "NOT REPORTED" else "${v shr 22}.${(v shr 12) and 0x3ff}",
        "GLES: ${am.deviceConfigurationInfo.glEsVersion}",
        "RAM: ${mi.totalMem / (1024 * 1024)} MB",
        "Key length: ${BuildConfig.TOMTOM_API_KEY.length}",
    )
}
