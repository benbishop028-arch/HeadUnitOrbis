package com.headunit.launcher.ui

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.os.Build
import android.os.Process
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.BuildConfig
import com.tomtom.sdk.common.configuration.buildSdkConfiguration
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.map.display.camera.InitialCameraOptions
import com.tomtom.sdk.map.display.compose.TomTomMap
import com.tomtom.sdk.map.display.compose.model.MapDisplayInfrastructure
import com.tomtom.sdk.map.display.compose.state.rememberMapViewState
import com.tomtom.sdk.map.display.style.*
import com.tomtom.sdk.telemetry.UserConsent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val LONDON = GeoPoint(latitude = 51.5074, longitude = -0.1278)

/** Minimal, documented TomTom native map plus device/network checks, to find out why roads don't draw. */
@Composable
fun NativeDiagScreen(pip: Boolean, systemDark: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var sdkStatus by remember { mutableStateOf("starting…") }
    var orbisStatus by remember { mutableStateOf("not tried") }
    var sdkReady by remember { mutableStateOf(false) }
    var styleStatus by remember { mutableStateOf("not tested") }
    var tileStatus by remember { mutableStateOf("not tested") }
    val scope = rememberCoroutineScope()
    var tilt by remember { mutableStateOf(false) }
    var styleIdx by remember { mutableStateOf(0) }
    val styleChoices = remember { listStylesOf(StandardStyles.TomTomOrbisMaps.DRIVING, StandardStyles.TomTomOrbisMaps) }
    var dark by remember { mutableStateOf(systemDark) }
    LaunchedEffect(systemDark) { dark = systemDark }
    var logs by remember { mutableStateOf("(tap Refresh log)") }
    var logTick by remember { mutableStateOf(0) }
    var rxKb by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = TrafficStats.getUidRxBytes(Process.myUid())
        while (true) {
            val now = TrafficStats.getUidRxBytes(Process.myUid())
            rxKb = if (start >= 0 && now >= 0) (now - start) / 1024 else -1
            delay(1000)
        }
    }
    LaunchedEffect(logTick) { if (logTick > 0) logs = readOwnLogs() }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) {
            orbisStatus = enableOrbisToggle(ctx.applicationContext)
            try {
                if (!TomTomSdk.isInitialized) {
                    val cfg = buildSdkConfiguration(
                        context = ctx.applicationContext,
                        apiKey = BuildConfig.TOMTOM_API_KEY,
                        telemetryUserConsent = { UserConsent.TelemetryOff },
                    )
                    TomTomSdk.initialize(context = ctx.applicationContext, sdkConfiguration = cfg)
                }
                sdkStatus = "initialised OK"
                sdkReady = true
            } catch (t: Throwable) {
                sdkStatus = "FAILED: ${t.javaClass.simpleName}: ${t.message}"
            }
        }
        // Device -> TomTom network checks, using the same key the app was built with
        val key = BuildConfig.TOMTOM_API_KEY
        styleStatus = httpCode("https://api.tomtom.com/maps/orbis/assets/styles/0.*/style.json?key=$key&apiVersion=1&map=basic_street-light-driving")
        tileStatus = httpCode("https://api.tomtom.com/maps/orbis/map-display/tile/14/8186/5448.pbf?apiVersion=1&key=$key")
    }

    Row(
        if (pip) modifier.background(Rail) else modifier.background(Rail).padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (!pip) Column(Modifier.width(330.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Native SDK test", color = Ink, fontSize = 22.sp)
            diagLines(ctx).forEach { Text(it, color = TextDim, fontSize = 13.sp) }
            Text("Orbis toggle: $orbisStatus", color = Ink, fontSize = 13.sp)
            Text("SDK init: $sdkStatus", color = Ink, fontSize = 13.sp)
            Text("Style request: $styleStatus", color = Ink, fontSize = 13.sp)
            Text("Tile request: $tileStatus", color = Ink, fontSize = 13.sp)
            Text(
                "Data downloaded by this app since opening: " + (if (rxKb < 0) "unavailable" else "$rxKb KB"),
                color = Ink, fontSize = 13.sp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = tilt, onCheckedChange = { tilt = it })
                Text("  3D tilt (45°)", color = Ink, fontSize = 14.sp)
            }
            Text("Map style (tap one, map reloads):", color = Accent, fontSize = 14.sp)
            styleChoices.forEachIndexed { i, (name, _) ->
                Text(
                    (if (i == styleIdx) "● " else "○ ") + name,
                    color = if (i == styleIdx) Ink else TextDim, fontSize = 15.sp,
                    modifier = Modifier.clickable { styleIdx = i }.padding(vertical = 5.dp),
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = dark, onCheckedChange = { dark = it })
                Text("  Dark style mode", color = Ink, fontSize = 14.sp)
            }
            Text(
                "Refresh log", color = Accent, fontSize = 18.sp,
                modifier = Modifier.clickable { logTick++ }.padding(vertical = 8.dp),
            )
            Text(
                "Copy full log to clipboard", color = Accent, fontSize = 18.sp,
                modifier = Modifier.clickable {
                    scope.launch {
                        val full = readOwnLogs(400)
                        val head = (diagLines(ctx) + listOf(
                            "Orbis toggle: $orbisStatus", "SDK init: $sdkStatus", "Style: " + (styleChoices.getOrNull(styleIdx)?.first ?: "?"),
                            "tilt=$tilt dark=$dark", "Style request: $styleStatus", "Tile request: $tileStatus", "Downloaded: $rxKb KB",
                        )).joinToString("\n")
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("log", head + "\n\n" + full))
                        logs = "Copied ${full.length} characters. Paste it into the chat."
                    }
                }.padding(vertical = 8.dp),
            )
            Text(logs, color = TextDim, fontSize = 10.sp, lineHeight = 12.sp)
        }
        Box(
            if (pip) Modifier.weight(1f).fillMaxHeight() else Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).border(1.dp, Line, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (sdkReady) {
                key(styleIdx, tilt) {
                    val cam = InitialCameraOptions.LocationBased(position = LONDON, zoom = 14.0, tilt = if (tilt) 45.0 else 0.0)
                    val chosen = styleChoices.getOrNull(styleIdx)?.second
                    val state = if (chosen != null) {
                        rememberMapViewState(initialCameraOptions = cam, initialStyle = chosen)
                    } else {
                        rememberMapViewState(initialCameraOptions = cam)
                    }
                    LaunchedEffect(dark) {
                        state.styleState.styleMode = if (dark) StyleMode.DARK else StyleMode.MAIN
                    }
                    TomTomMap(
                        state = state,
                        infrastructure = remember { MapDisplayInfrastructure(sdkContext = TomTomSdk.sdkContext) {} },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                Text("Waiting for SDK…", color = TextDim)
            }
        }
    }
}

private suspend fun httpCode(url: String): String = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 10_000
        val code = c.responseCode
        val len = c.contentLengthLong
        c.disconnect()
        "HTTP $code" + if (len >= 0) " ($len bytes)" else ""
    } catch (t: Throwable) {
        "ERROR ${t.javaClass.simpleName}: ${t.message}"
    }
}

private fun diagLines(ctx: Context): List<String> {
    val pm = ctx.packageManager
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val vulkan = pm.systemAvailableFeatures.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val v = vulkan?.version ?: 0
    return listOf(
        "Device: ${Build.MANUFACTURER} ${Build.MODEL}",
        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "ABIs: ${Build.SUPPORTED_ABIS.joinToString()}",
        "Vulkan: " + if (vulkan == null) "NOT REPORTED" else "${v shr 22}.${(v shr 12) and 0x3ff}",
        "GLES: ${am.deviceConfigurationInfo.glEsVersion}",
        "RAM: ${mi.totalMem / (1024 * 1024)} MB",
        "Key length: ${BuildConfig.TOMTOM_API_KEY.length}",
        "Map renderer: PREMIUM, TomTom SDK ${BuildConfig.SDK_VERSION}",
    )
}

/** Warnings/errors this app's own process has logged (apps can read their own logcat). */
private suspend fun readOwnLogs(maxLines: Int = 60): String = withContext(Dispatchers.IO) {
    try {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "6000", "-v", "brief"))
        val keep = Regex("tomtom|unity|tile|style|layer|http|fail|error|exception|shader|pipeline|vulkan|download|cache|key|auth", RegexOption.IGNORE_CASE)
        val noise = Regex("BLAST|VRI|SurfaceView|SV\\[|nativeloader|Connectivity|AdrenoGLES|GL_|InsetsController|SurfaceSyncer|RenderWorker|perf_hint|libpenguin|Choreographer|WindowManager|esture|mCurrentDown|common\\.internal|Interceptor|MotionEvent|ViewRootImpl|InputMethod|ImeTracker")
        val lines = p.inputStream.bufferedReader().readLines()
            .filter { it.isNotBlank() && !it.startsWith("---") && !it.contains("SPRDDEBUG") && !noise.containsMatchIn(it) }
            .filter { it.startsWith("W/") || it.startsWith("E/") || it.startsWith("F/") || keep.containsMatchIn(it) }
            .takeLast(maxLines)
            .map { it.take(180) }
        if (lines.isEmpty()) "(no warnings or errors logged)" else lines.joinToString("\n")
    } catch (t: Throwable) {
        "Could not read logs: ${t.javaClass.simpleName}: ${t.message}"
    }
}


/** Turns on TomTom's "Orbis map" runtime feature by reflection, so a missing class can't break the build. */
private fun enableOrbisToggle(appCtx: Context): String = try {
    val ctrl = Class.forName("com.tomtom.sdk.featuretoggle.FeatureToggleController")
    val inst = ctrl.getField("INSTANCE").get(null)
    val feat = Class.forName("com.tomtom.sdk.featuretoggle.TomTomOrbisMapFeature").getField("INSTANCE").get(null)
    val log = StringBuilder()
    ctrl.methods.firstOrNull { it.name == "initialize" && it.parameterTypes.size == 1 && it.parameterTypes[0] == Context::class.java }
        ?.let { runCatching { it.invoke(inst, appCtx) }.onFailure { e -> log.append("init: ${e.cause ?: e}; ") } }
    val en = ctrl.methods.firstOrNull { it.name == "enable" && it.parameterTypes.size == 1 }
    if (en == null) "no enable() method found" else { en.invoke(inst, feat); log.append("enabled").toString() }
} catch (t: Throwable) {
    "${t.javaClass.simpleName}: ${t.cause?.message ?: t.message}"
}


/** Every ready-made Orbis style the SDK ships, found by reflection, plus "SDK default". */
private fun <T : Any> listStylesOf(sample: T, holder: Any): List<Pair<String, T?>> {
    val out = mutableListOf<Pair<String, T?>>("SDK default (no style given)" to null)
    try {
        holder.javaClass.methods
            .filter { it.name.startsWith("get") && it.parameterTypes.isEmpty() && it.name != "getClass" }
            .sortedBy { it.name }
            .forEach { m ->
                val v = runCatching { m.invoke(holder) }.getOrNull()
                @Suppress("UNCHECKED_CAST")
                if (v != null && sample.javaClass.isInstance(v)) out += m.name.removePrefix("get") to (v as T)
            }
    } catch (_: Throwable) { }
    if (out.none { it.second === sample }) out += "DRIVING" to sample
    return out
}
