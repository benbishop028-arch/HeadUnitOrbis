package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

/** True when the temperature unit is Fahrenheit. */
fun isImperial(prefs: Prefs): Boolean =
    prefs.s("tempunit", "C") == "F"

fun tempText(tenthsC: Int, imperial: Boolean): String =
    if (tenthsC <= 160) "LO" else if (tenthsC >= 280) "HI"
    else if (imperial) "${(tenthsC / 10.0 * 9 / 5 + 32).roundToInt()}" else String.format("%.1f", tenthsC / 10.0)

@Composable
internal fun MiniPlayer(onOpen: () -> Unit) {
    val c = LocalVw.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val m = rememberMedia()
    val access = rememberMediaAccess()
    val open: () -> Unit = if (access) onOpen else ({ com.headunit.launcher.MediaHelper.openAccess(ctx) })
    Row(
        Modifier.width(332.dp).height(66.dp).padding(horizontal = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(c.tile).clickable(onClick = open), contentAlignment = Alignment.Center) {
            if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp).clickable(onClick = open)) {
            Text(m?.title ?: if (access) "Nothing playing" else "Allow media access", color = c.onBg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m?.artist ?: if (access) "Tap to open" else "Tap to enable", color = c.onBgSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (m != null) {
            Box(Modifier.size(42.dp).clip(CircleShape).clickable { m.previous() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipPrevious, null, tint = c.onBg, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.size(48.dp).clip(CircleShape).background(c.accent).clickable { m.toggle() }, contentAlignment = Alignment.Center) {
                Icon(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.size(42.dp).clip(CircleShape).clickable { m.next() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, tint = c.onBg, modifier = Modifier.size(28.dp))
            }
        }
    }
}

@Composable
fun AmbientPage(prefs: Prefs) {
    val c = LocalVw.current
    val on = prefs.b("ambon", true)
    val sel = prefs.i("amb", 0).coerceIn(0, AmbientColors.lastIndex)
    val col = AmbientColors[sel]
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                androidx.compose.foundation.Canvas(Modifier.size(220.dp)) {
                    val r = size.minDimension / 2f
                    val centre = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
                    if (on) {
                        drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.55f), Color.Transparent), centre, r), r, centre)
                        drawCircle(Brush.linearGradient(listOf(col.lighten(0.3f), col.darken(0.2f)), androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, size.height)), r * 0.5f, centre)
                        drawCircle(Color.White.copy(alpha = 0.4f), r * 0.5f, centre, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                    } else {
                        drawCircle(c.line.copy(alpha = 0.7f), r * 0.5f, centre, style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
                        drawLine(c.line.copy(alpha = 0.7f), androidx.compose.ui.geometry.Offset(centre.x - r * 0.35f, centre.y + r * 0.35f), androidx.compose.ui.geometry.Offset(centre.x + r * 0.35f, centre.y - r * 0.35f), 3.dp.toPx())
                    }
                }
                Text(if (on) AmbientNames[sel] else "Off", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                Text(if (on) "A soft glow around the edges of the screen." else "No ambient light.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionLabel("Colour")
                Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AmbientColors.forEachIndexed { i, colr ->
                        val chosen = on && i == sel
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(colr.lighten(0.2f), colr.darken(0.12f))))
                                .then(if (chosen) Modifier.border(3.dp, c.text, CircleShape) else Modifier.border(1.dp, c.line.copy(alpha = 0.5f), CircleShape))
                                .clickable { prefs.put("amb", i); prefs.put("ambon", true) },
                        )
                    }
                }
                Row2("Ambient light") { Switch(on, { prefs.put("ambon", it) }) }
                Row2("Brightness") {
                    var iv by remember { mutableStateOf(prefs.i("ambint", 100).toFloat()) }
                    androidx.compose.material3.Slider(
                        value = iv, onValueChange = { iv = it }, onValueChangeFinished = { prefs.put("ambint", Math.round(iv)) },
                        valueRange = 40f..160f, enabled = on, modifier = Modifier.width(220.dp),
                    )
                    Text("${Math.round(iv)}%", color = c.sub, fontSize = 14.sp, modifier = Modifier.width(46.dp))
                }
                Row2("React to calls, turns and alerts") { Switch(prefs.b("ambreact", true), { prefs.put("ambreact", it) }) }
                Row2("Slow pulse") { Switch(prefs.b("ambpulse", true), { prefs.put("ambpulse", it) }) }
            }
        }
    }
}
