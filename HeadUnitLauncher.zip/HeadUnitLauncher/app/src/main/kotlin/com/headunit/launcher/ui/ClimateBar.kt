package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.background
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

fun isImperial(prefs: Prefs): Boolean =
    prefs.s("units", if (Locale.getDefault().country in setOf("GB", "US", "LR", "MM")) "imperial" else "metric") == "imperial"

fun tempText(tenthsC: Int, imperial: Boolean): String =
    if (tenthsC <= 160) "LO" else if (tenthsC >= 280) "HI"
    else if (imperial) "${(tenthsC / 10.0 * 9 / 5 + 32).roundToInt()}" else String.format("%.1f", tenthsC / 10.0)

@Composable
private fun TempNum(tenths: Int, imperial: Boolean, editing: Boolean, onTap: () -> Unit, onChange: (Int) -> Unit) {
    val c = LocalVw.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (editing) Box(Modifier.size(38.dp).clip(CircleShape).background(c.surface2).clickable { onChange((tenths - 5).coerceAtLeast(160)) }, contentAlignment = Alignment.Center) {
            Text("–", color = c.text, fontSize = 22.sp)
        }
        Text(
            tempText(tenths, imperial), color = c.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
            modifier = Modifier.width(if (imperial) 56.dp else 74.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onTap),
        )
        if (editing) Box(Modifier.size(38.dp).clip(CircleShape).background(c.surface2).clickable { onChange((tenths + 5).coerceAtMost(280)) }, contentAlignment = Alignment.Center) {
            Text("+", color = c.text, fontSize = 22.sp)
        }
    }
}

@Composable
private fun SeatKey(level: Int, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.EventSeat, "Seat heating", tint = c.text, modifier = Modifier.size(24.dp))
        Dots(level, 3, SeatRed, c.line, Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun FanKey(fan: Int, on: Boolean, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.Air, "Fan", tint = if (on) c.accent else c.sub, modifier = Modifier.size(24.dp))
        Dots(if (on) ((fan + 2) / 3).coerceAtMost(3) else 0, 3, c.accent, c.line, Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun MiniPlayer(onOpen: () -> Unit) {
    val c = LocalVw.current
    val m = rememberMedia()
    Row(
        Modifier.width(270.dp).height(52.dp).clip(RoundedCornerShape(14.dp)).background(c.surface).padding(horizontal = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(9.dp)).background(c.surface2).clickable(onClick = onOpen), contentAlignment = Alignment.Center) {
            if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 8.dp).clickable(onClick = onOpen)) {
            Text(m?.title ?: "Media", color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m?.artist ?: "Tap to open", color = c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (m != null) {
            Box(Modifier.size(34.dp).clip(CircleShape).clickable { m.controller.transportControls.skipToPrevious() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipPrevious, null, tint = c.text, modifier = Modifier.size(22.dp))
            }
            Box(Modifier.size(36.dp).clip(CircleShape).background(c.accent).clickable { if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play() }, contentAlignment = Alignment.Center) {
                Icon(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Box(Modifier.size(34.dp).clip(CircleShape).clickable { m.controller.transportControls.skipToNext() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, tint = c.text, modifier = Modifier.size(22.dp))
            }
        }
    }
}

@Composable
private fun ClimateKey(label: String, onClick: () -> Unit) {
    val c = LocalVw.current
    Row(
        Modifier.height(48.dp).clip(RoundedCornerShape(14.dp)).background(c.surface).clickable(onClick = onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.DeviceThermostat, "Climate", tint = AutoAmber, modifier = Modifier.size(22.dp))
        Text(label, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp))
    }
}

/** Bottom strip modelled on the car: temps at the edges, CLIMA/AUTO, seat heat, home key, A/C, defrost. Local only. */
@Composable
fun BottomBar(prefs: Prefs, page: Page, amb: Color, onPage: (Page) -> Unit) {
    val c = LocalVw.current
    val imp = isImperial(prefs)
    val tl = prefs.i("c_tl", 215)
    val tr = prefs.i("c_tr", 215)
    val sync = prefs.b("c_sync", false)
    val off = prefs.b("c_off", false)
    val fan = prefs.i("c_fan", 3)
    val mini = if (page == Page.Nav) prefs.s("mini", "right") else "off"
    var editing by remember { mutableIntStateOf(0) }   // 0 none, 1 left, 2 right
    LaunchedEffect(editing, tl, tr) { if (editing != 0) { delay(4000); editing = 0 } }

    // On the map page the mini player and the climate controls take turns on the same side
    var climateOpen by remember { mutableStateOf(false) }
    val sl = prefs.i("c_sl", 0)
    val sr = prefs.i("c_sr", 0)
    val ac = prefs.b("c_ac", true)
    LaunchedEffect(climateOpen, tl, tr, fan, sl, sr, ac, off) { if (climateOpen) { delay(6000); climateOpen = false } }
    LaunchedEffect(mini) { if (mini == "off") climateOpen = false }

    fun setL(v: Int) { prefs.put("c_tl", v); if (sync) prefs.put("c_tr", v) }
    fun setR(v: Int) { prefs.put("c_tr", v); if (sync) prefs.put("c_tl", v) }

    val leftGroup: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TempNum(tl, imp, editing == 1, { editing = if (editing == 1) 0 else 1 }, { setL(it) })
            Column(Modifier.padding(start = 10.dp).clip(RoundedCornerShape(10.dp)).clickable { onPage(Page.Climate) }.padding(horizontal = 6.dp, vertical = 2.dp)) {
                Text("CLIMA", color = c.text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text("AUTO", color = if (prefs.b("c_auto", true) && !off) AutoAmber else c.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { prefs.put("c_auto", !prefs.b("c_auto", true)); prefs.put("c_off", false) })
            }
            Spacer(Modifier.width(10.dp))
            FanKey(fan, !off, { prefs.put("c_fan", if (fan >= 7) 1 else fan + 1); prefs.put("c_off", false) })
            SeatKey(sl) { prefs.put("c_sl", (sl + 1) % 4) }
        }
    }
    val rightGroup: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SeatKey(sr) { prefs.put("c_sr", (sr + 1) % 4) }
            Text("A/C", color = if (ac && !off) c.text else c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { prefs.put("c_ac", !ac) }.padding(horizontal = 8.dp, vertical = 8.dp))
            Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { prefs.put("c_dr", !prefs.b("c_dr", false)) }.padding(4.dp)) {
                DefrostIcon(false, if (prefs.b("c_dr", false)) AutoAmber else c.text)
            }
            Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { prefs.put("c_df", !prefs.b("c_df", false)) }.padding(4.dp)) {
                DefrostIcon(true, if (prefs.b("c_df", false)) AutoAmber else c.text)
            }
            Spacer(Modifier.width(10.dp))
            TempNum(tr, imp, editing == 2, { editing = if (editing == 2) 0 else 2 }, { setR(it) })
        }
    }
    val enter = expandHorizontally() + fadeIn()
    val exit = shrinkHorizontally() + fadeOut()

    Box(
        Modifier.fillMaxWidth().height(70.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.0f), c.bg.copy(alpha = 0.85f))))
            .drawBehind {
                // ambient "slider" strip along the bottom edge
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, amb, amb, Color.Transparent)),
                    topLeft = Offset(size.width * 0.04f, size.height - 4f), size = androidx.compose.ui.geometry.Size(size.width * 0.92f, 4f),
                )
            },
    ) {
        Row(Modifier.align(Alignment.CenterStart).padding(start = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (mini == "left") {
                AnimatedVisibility(!climateOpen, enter = enter, exit = exit) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MiniPlayer { onPage(Page.Media) }
                        Spacer(Modifier.width(8.dp))
                        ClimateKey(tempText(tl, imp)) { climateOpen = true }
                    }
                }
                AnimatedVisibility(climateOpen, enter = enter, exit = exit) { leftGroup() }
            } else leftGroup()
        }
        HomeKey(amb, c.text, { onPage(Page.Home) }, Modifier.align(Alignment.Center).padding(bottom = 4.dp))
        Row(Modifier.align(Alignment.CenterEnd).padding(end = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (mini == "right") {
                AnimatedVisibility(!climateOpen, enter = enter, exit = exit) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ClimateKey(tempText(tr, imp)) { climateOpen = true }
                        Spacer(Modifier.width(8.dp))
                        MiniPlayer { onPage(Page.Media) }
                    }
                }
                AnimatedVisibility(climateOpen, enter = enter, exit = exit) { rightGroup() }
            } else rightGroup()
        }
    }
}

// ------------------------------------------------------------------ pages
@Composable
private fun Level(label: String, level: Int, onSet: (Int) -> Unit) {
    val c = LocalVw.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = c.sub, fontSize = 13.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0..3) Pill(if (i == 0) "Off" else "$i", level == i, { onSet(i) })
        }
    }
}

@Composable
fun SeatsPage(prefs: Prefs) {
    val c = LocalVw.current
    Row(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(24.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        for ((title, hk, vk) in listOf(Triple("Driver", "c_sl", "c_vl"), Triple("Passenger", "c_sr", "c_vr"))) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text(title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Icon(Icons.Rounded.EventSeat, null, tint = if (prefs.i(hk, 0) > 0) SeatRed else c.text, modifier = Modifier.size(64.dp))
                Level("Seat heating", prefs.i(hk, 0)) { prefs.put(hk, it) }
                Level("Ventilation", prefs.i(vk, 0)) { prefs.put(vk, it) }
            }
        }
    }
}

@Composable
fun ClimatePage(prefs: Prefs) {
    val c = LocalVw.current
    val imp = isImperial(prefs)
    val sync = prefs.b("c_sync", false)
    val off = prefs.b("c_off", false)
    val fan = prefs.i("c_fan", 3)
    fun setL(v: Int) { prefs.put("c_tl", v); if (sync) prefs.put("c_tr", v) }
    fun setR(v: Int) { prefs.put("c_tr", v); if (sync) prefs.put("c_tl", v) }
    Row(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
        BigTemp("Driver", prefs.i("c_tl", 215), imp, { setL(it) })
        Column(Modifier.weight(1f).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("AUTO", prefs.b("c_auto", true) && !off, { prefs.put("c_auto", !prefs.b("c_auto", true)); prefs.put("c_off", false) })
                Pill("A/C", prefs.b("c_ac", true) && !off, { prefs.put("c_ac", !prefs.b("c_ac", true)) })
                Pill("SYNC", sync, { val n = !sync; prefs.put("c_sync", n); if (n) prefs.put("c_tr", prefs.i("c_tl", 215)) })
                Pill("OFF", off, { prefs.put("c_off", !off) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RoundBtn(Icons.Rounded.Air, { prefs.put("c_fan", (fan - 1).coerceAtLeast(0)); prefs.put("c_off", false) }, size = 44.dp)
                Dots(fan, 7, c.accent, c.line, dot = 9.dp)
                RoundBtn(Icons.Rounded.Air, { prefs.put("c_fan", (fan + 1).coerceAtMost(7)); prefs.put("c_off", false) }, size = 44.dp, active = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Recirculation", prefs.b("c_rc", false), { prefs.put("c_rc", !prefs.b("c_rc", false)) })
                Pill("Windscreen", prefs.b("c_df", false), { prefs.put("c_df", !prefs.b("c_df", false)) })
                Pill("Rear window", prefs.b("c_dr", false), { prefs.put("c_dr", !prefs.b("c_dr", false)) })
            }
            Text("Visual only: this does not control the car's climate system.", color = c.sub, fontSize = 12.sp)
        }
        BigTemp("Passenger", prefs.i("c_tr", 215), imp, { setR(it) })
    }
}

@Composable
private fun BigTemp(label: String, tenths: Int, imp: Boolean, onChange: (Int) -> Unit) {
    val c = LocalVw.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, color = c.sub, fontSize = 14.sp)
        RoundBtn(Icons.Rounded.KeyboardArrowUp, { onChange((tenths + 5).coerceAtMost(280)) }, size = 48.dp, active = true)
        Text(tempText(tenths, imp), color = c.text, fontSize = 52.sp, fontWeight = FontWeight.Bold)
        RoundBtn(Icons.Rounded.KeyboardArrowDown, { onChange((tenths - 5).coerceAtLeast(160)) }, size = 48.dp)
    }
}

@Composable
fun AmbientPage(prefs: Prefs) {
    val c = LocalVw.current
    val sel = prefs.i("amb", 0)
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Text("Ambient light", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Tints the glow around the screen.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            AmbientColors.forEachIndexed { i, col ->
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(col).clickable { prefs.put("amb", i) },
                    contentAlignment = Alignment.Center,
                ) { if (i == sel) Box(Modifier.size(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.9f))) }
            }
        }
        Text(AmbientNames[sel.coerceIn(0, AmbientNames.lastIndex)], color = c.text, fontSize = 16.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
fun FeaturePage(page: Page) {
    val c = LocalVw.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Terrain, null, tint = c.sub, modifier = Modifier.size(54.dp))
        Text(page.label, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
        Text("Not connected: a launcher app can't read or control this vehicle system.", color = c.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
    }
}
