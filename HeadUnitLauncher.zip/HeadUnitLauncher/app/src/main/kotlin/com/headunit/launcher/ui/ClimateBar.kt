package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Autorenew
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Prefs

private val SeatHot = Color(0xFFFF6A3D)

@Composable
private fun Toggle(label: String, icon: ImageVector?, on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(if (on) c.accent else c.surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (icon != null) Icon(icon, label, tint = if (on) Color.White else c.text, modifier = Modifier.size(22.dp))
        Text(label, color = if (on) Color.White else c.sub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Seat(level: Int, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(
        Modifier.clip(RoundedCornerShape(14.dp)).background(c.surface2).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Rounded.EventSeat, "Seat heating", tint = if (level > 0) SeatHot else c.text, modifier = Modifier.size(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(top = 3.dp)) {
            for (i in 1..3) Box(Modifier.width(9.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= level) SeatHot else c.line))
        }
    }
}

@Composable
private fun Temp(tenths: Int, onChange: (Int) -> Unit) {
    val c = LocalVw.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(c.surface2).clickable { onChange((tenths - 5).coerceAtLeast(160)) },
            contentAlignment = Alignment.Center,
        ) { Text("–", color = c.text, fontSize = 24.sp) }
        Text(
            if (tenths <= 160) "LO" else if (tenths >= 280) "HI" else String.format("%.1f", tenths / 10f),
            color = c.text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(66.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(c.surface2).clickable { onChange((tenths + 5).coerceAtMost(280)) },
            contentAlignment = Alignment.Center,
        ) { Text("+", color = c.text, fontSize = 24.sp) }
    }
}

/** Visual climate strip modelled on the car's bottom bar. It stores state locally; it cannot talk to the car's HVAC. */
@Composable
fun ClimateBar(prefs: Prefs) {
    val c = LocalVw.current
    val sync = prefs.b("c_sync", false)
    val tl = prefs.i("c_tl", 215)
    val tr = prefs.i("c_tr", 215)
    val fan = prefs.i("c_fan", 3)
    val off = prefs.b("c_off", false)

    fun setL(v: Int) { prefs.put("c_tl", v); if (sync) prefs.put("c_tr", v) }
    fun setR(v: Int) { prefs.put("c_tr", v); if (sync) prefs.put("c_tl", v) }

    Row(
        Modifier.fillMaxWidth().height(76.dp).background(c.surface).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Seat(prefs.i("c_sl", 0)) { prefs.put("c_sl", (prefs.i("c_sl", 0) + 1) % 4) }
        Temp(tl) { setL(it) }
        Toggle("AUTO", null, prefs.b("c_auto", true) && !off, { prefs.put("c_auto", !prefs.b("c_auto", true)); prefs.put("c_off", false) })
        Toggle("A/C", Icons.Rounded.AcUnit, prefs.b("c_ac", true) && !off, { prefs.put("c_ac", !prefs.b("c_ac", true)) })
        // fan
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(c.surface2).clickable { prefs.put("c_fan", (fan - 1).coerceAtLeast(0)); prefs.put("c_off", false) },
                contentAlignment = Alignment.Center,
            ) { Text("–", color = c.text, fontSize = 22.sp) }
            Column(Modifier.width(70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Air, "Fan", tint = if (off || fan == 0) c.sub else c.accent, modifier = Modifier.size(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.padding(top = 3.dp)) {
                    for (i in 1..7) Box(Modifier.width(6.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= fan && !off) c.accent else c.line))
                }
            }
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(c.surface2).clickable { prefs.put("c_fan", (fan + 1).coerceAtMost(7)); prefs.put("c_off", false) },
                contentAlignment = Alignment.Center,
            ) { Text("+", color = c.text, fontSize = 22.sp) }
        }
        Toggle("RECIRC", Icons.Rounded.Autorenew, prefs.b("c_rc", false), { prefs.put("c_rc", !prefs.b("c_rc", false)) })
        Toggle("FRONT", Icons.Rounded.AcUnit, prefs.b("c_df", false), { prefs.put("c_df", !prefs.b("c_df", false)) })
        Toggle("REAR", Icons.Rounded.AcUnit, prefs.b("c_dr", false), { prefs.put("c_dr", !prefs.b("c_dr", false)) })
        Toggle("SYNC", null, sync, { val n = !sync; prefs.put("c_sync", n); if (n) prefs.put("c_tr", prefs.i("c_tl", 215)) })
        Toggle("OFF", null, off, { prefs.put("c_off", !off) })
        Temp(tr) { setR(it) }
        Seat(prefs.i("c_sr", 0)) { prefs.put("c_sr", (prefs.i("c_sr", 0) + 1) % 4) }
    }
}
