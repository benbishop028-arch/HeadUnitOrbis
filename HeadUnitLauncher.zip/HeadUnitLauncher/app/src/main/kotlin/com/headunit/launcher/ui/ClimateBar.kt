package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.material.icons.rounded.DeviceThermostat
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

/** True when the temperature unit is Fahrenheit. */
fun isImperial(prefs: Prefs): Boolean =
    prefs.s("tempunit", if (Locale.getDefault().country in setOf("US", "LR", "BS", "BZ", "KY", "PW")) "F" else "C") == "F"

fun tempText(tenthsC: Int, imperial: Boolean): String =
    if (tenthsC <= 160) "LO" else if (tenthsC >= 280) "HI"
    else if (imperial) "${(tenthsC / 10.0 * 9 / 5 + 32).roundToInt()}" else String.format("%.1f", tenthsC / 10.0)

@Composable
internal fun MiniPlayer(onOpen: () -> Unit) {
    val c = LocalVw.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val m = rememberMedia()
    val access = rememberMediaAccess()
    val open: () -> Unit = if (access) onOpen else ({ com.headunit.launcher.MediaHelper.openAccess(ctx) })
    Row(
        Modifier.width(332.dp).height(66.dp).padding(horizontal = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(c.tile).clickable(onClick = open), contentAlignment = Alignment.Center) {
            if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp).clickable(onClick = open)) {
            Text(m?.title ?: if (access) "Nothing playing" else "Allow media access", color = c.onBg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m?.artist ?: if (access) "Tap to open" else "Tap to enable", color = c.onBgSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (m != null) {
            Box(Modifier.size(42.dp).clip(CircleShape).clickable { m.previous() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipPrevious, null, tint = c.onBg, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.size(48.dp).clip(CircleShape).background(c.accent).clickable { m.toggle() }, contentAlignment = Alignment.Center) {
                Icon(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.size(42.dp).clip(CircleShape).clickable { m.next() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, tint = c.onBg, modifier = Modifier.size(28.dp))
            }
        }
    }
}

@Composable
fun AmbientPage(prefs: Prefs) {
    val c = LocalVw.current
    val sel = prefs.i("amb", 0)
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Text("Ambient light", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Tints the glow around the screen.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            AmbientColors.forEachIndexed { i, col ->
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(col).then(if (i == sel) Modifier.border(3.dp, c.text, CircleShape) else Modifier).clickable { prefs.put("amb", i) },
                    contentAlignment = Alignment.Center,
                ) { }
            }
        }
        Text(AmbientNames[sel.coerceIn(0, AmbientNames.lastIndex)], color = c.text, fontSize = 16.sp, modifier = Modifier.padding(top = 18.dp))
    }
}
