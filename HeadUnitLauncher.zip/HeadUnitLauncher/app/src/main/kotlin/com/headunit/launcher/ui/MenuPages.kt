package com.headunit.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.DriveEta
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.Fastfood
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.Prefs

private class Tile(val label: String, val icon: ImageVector?, val tint: Color, val page: Page)

@Composable
fun MenuPage(prefs: Prefs, amb: Color, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    val pager = rememberPagerState(pageCount = { 2 })
    val white = c.text
    val page1 = listOf(
        Tile("Telephone", Icons.Rounded.Call, PhoneGreen, Page.Phone),
        Tile("Radio/Media", Icons.Rounded.MusicNote, MediaRed, Page.Media),
        Tile("Navigation", Icons.Rounded.Navigation, NavBlue, Page.Nav),
        Tile("App-Connect", Icons.Rounded.PhoneAndroid, white, Page.AppConnect),
        Tile("Settings", Icons.Rounded.Settings, white, Page.Settings),
        Tile("Apps", Icons.Rounded.Apps, white, Page.Apps),
        Tile("Ambient light", null, white, Page.Ambient),
        Tile("Weather", Icons.Rounded.WbSunny, white, Page.Weather),
        Tile("Calendar", Icons.Rounded.Event, white, Page.Calendar),
        Tile("Clock", Icons.Rounded.Timer, white, Page.Clock),
        Tile("Trips", Icons.Rounded.Route, white, Page.Trips),
        Tile("Car log", Icons.Rounded.LocalGasStation, white, Page.CarLog),
        Tile("Drive", Icons.Rounded.Speed, white, Page.Drive),
        Tile("Smart home", Icons.Rounded.Home, white, Page.SmartHome),
        Tile("Dash cam", Icons.Rounded.Videocam, white, Page.DashCam),
        Tile("Discover", Icons.Rounded.Explore, white, Page.Discover),
    )
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp).padding(top = 2.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(c.panel)) {
            HorizontalPager(pager, Modifier.fillMaxSize()) { p ->
                TileGrid(page1.chunked(12).getOrElse(p) { emptyList() }, onOpen)
            }
        }
    }
}

@Composable
private fun TileGrid(tiles: List<Tile>, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        val cellW = maxWidth / 6
        val labelH = 22.dp
        val tile = minOf(cellW * 0.8f, (maxHeight - labelH * 2 - 16.dp) / 2)
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            tiles.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { t ->
                        Column(Modifier.width(cellW), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(tile).clip(RoundedCornerShape(tile * 0.2f)).background(c.tile).clickable { onOpen(t.page) },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (t.icon != null) Icon(t.icon, t.label, tint = t.tint, modifier = Modifier.size(tile * 0.5f))
                                else AmbientGlyph(Modifier.size(tile * 0.46f))
                            }
                            Text(t.label, color = c.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppConnectPage(apps: AppsRepo, prefs: Prefs, onHome: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val proj = apps.projectionApps()
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(c.panel).padding(22.dp),
    ) {
        Text("App-Connect", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Android Auto and CarPlay-style apps found on this unit. Open one full screen, or show it in the Home window.",
            color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp),
        )
        if (proj.isEmpty()) Text("None found. Pick any app from the Home window's Source button.", color = c.text, fontSize = 15.sp)
        LazyVerticalGrid(GridCells.Adaptive(150.dp), Modifier.fillMaxSize()) {
            items(proj) { a ->
                Column(Modifier.padding(6.dp).clip(RoundedCornerShape(18.dp)).background(c.tile).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(a.icon, a.label, Modifier.size(64.dp).clickable { Launch.app(ctx, a.pkg) })
                    Text(a.label, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("Open", true, { Launch.app(ctx, a.pkg) })
                        Pill("In window", false, { prefs.put("pip_src", a.pkg); onHome() })
                    }
                }
            }
        }
    }
}
