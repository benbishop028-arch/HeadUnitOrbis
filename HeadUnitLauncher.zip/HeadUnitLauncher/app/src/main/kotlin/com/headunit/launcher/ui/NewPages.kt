package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbCloudy
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.CalEvent
import com.headunit.launcher.CalendarData
import com.headunit.launcher.ClockTools
import com.headunit.launcher.FuelEntry
import com.headunit.launcher.FuelStore
import com.headunit.launcher.Geo
import com.headunit.launcher.LL
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import com.headunit.launcher.ServiceStore
import com.headunit.launcher.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ------------------------------------------------------------------ Weather
private fun wxIcon(code: Int): ImageVector = when (code) {
    0 -> Icons.Rounded.WbSunny
    1, 2 -> Icons.Rounded.WbCloudy
    3, 45, 48 -> Icons.Rounded.Cloud
    in 51..67, in 80..82 -> Icons.Rounded.WaterDrop
    in 71..77, in 85..86 -> Icons.Rounded.AcUnit
    in 95..99 -> Icons.Rounded.Bolt
    else -> Icons.Rounded.Cloud
}

@Composable
fun WeatherPage(engine: NavEngine, prefs: Prefs) {
    val c = LocalVw.current
    val fahrenheit = isImperial(prefs)
    val lat = prefs.s("lastlat", "").toDoubleOrNull()
    val lon = prefs.s("lastlon", "").toDoubleOrNull()
    var fc by remember { mutableStateOf<Weather.Forecast?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(lat, lon) {
        while (true) {
            val pos = engine.fix?.pos ?: if (lat != null && lon != null) LL(lat, lon) else null
            if (pos != null) {
                val r = withContext(Dispatchers.IO) { Weather.forecast(pos) }
                failed = r == null
                if (r != null) fc = r
            }
            delay(20 * 60_000L)
        }
    }
    fun t(cel: Double) = (if (fahrenheit) (cel * 9 / 5 + 32).roundToInt() else cel.roundToInt()).toString() + "°"
    fun wind(kmh: Double) = if (engine.imperial) "${(kmh * 0.621371).roundToInt()} mph" else "${kmh.roundToInt()} km/h"

    val f = fc
    if (f == null) {
        VCard(Modifier.fillMaxSize().padding(14.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (failed) "Could not load the forecast. Check the internet connection." else "Waiting for a GPS position…",
                    color = c.sub, fontSize = 16.sp,
                )
            }
        }
        return
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                Icon(wxIcon(f.code), null, tint = c.accent, modifier = Modifier.size(64.dp))
                Text(t(f.temp), color = c.text, fontSize = 54.sp, fontWeight = FontWeight.Bold)
                Text(Weather.text(f.code), color = c.text, fontSize = 20.sp)
                Text("Feels like ${t(f.feels)}  ·  Wind ${wind(f.windKmh)}", color = c.sub, fontSize = 14.sp)
                Text("Sunrise ${f.sunrise}   Sunset ${f.sunset}", color = c.sub, fontSize = 14.sp)
            }
        }
        VCard(Modifier.weight(2f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Next hours", color = c.sub, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(f.hours) { h ->
                        Column(Modifier.clip(RoundedCornerShape(14.dp)).background(c.surface2).padding(horizontal = 12.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(h.label, color = c.sub, fontSize = 12.sp)
                            Icon(wxIcon(h.code), null, tint = c.text, modifier = Modifier.padding(vertical = 4.dp).size(24.dp))
                            Text(t(h.temp), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text("${h.rain}%", color = if (h.rain >= 50) c.accent else c.sub, fontSize = 11.sp)
                        }
                    }
                }
                Text("Coming days", color = c.sub, fontSize = 13.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (d in f.days.take(6)) {
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(c.surface2).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.label, color = c.sub, fontSize = 12.sp)
                            Icon(wxIcon(d.code), null, tint = c.text, modifier = Modifier.padding(vertical = 4.dp).size(26.dp))
                            Text(t(d.max), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(t(d.min), color = c.sub, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Calendar
@Composable
fun CalendarPage(engine: NavEngine, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var perms by remember { mutableIntStateOf(0) }
    val allowed = remember(perms) { CalendarData.has(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perms++ }
    var events by remember { mutableStateOf<List<CalEvent>>(emptyList()) }
    LaunchedEffect(perms) {
        while (true) {
            events = withContext(Dispatchers.IO) { CalendarData.upcoming(ctx, 7) }
            delay(5 * 60_000L)
        }
    }
    val dayFmt = remember { SimpleDateFormat("EEEE d MMMM", Locale.getDefault()) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Next 7 days", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (!allowed) {
                Text("Allow calendar access to see your appointments and navigate to them.", color = c.sub, fontSize = 14.sp)
                Pill("Allow calendar access", true, { launcher.launch(android.Manifest.permission.READ_CALENDAR) })
            } else if (events.isEmpty()) {
                Text("Nothing coming up.", color = c.sub, fontSize = 15.sp)
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(events.size) { idx ->
                        val e = events[idx]
                        val day = dayFmt.format(Date(e.begin))
                        val lastDay = if (idx > 0) dayFmt.format(Date(events[idx - 1].begin)) else ""
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (day != lastDay) Text(day, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.surface2).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (e.allDay) "All day" else timeFmt.format(Date(e.begin)), color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(72.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (e.where.isNotBlank()) Text(e.where, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (e.where.isNotBlank()) Pill("Navigate", true, { engine.routeToText(e.where) { onOpen(Page.Nav) } })
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Clock tools
private val zones = listOf(
    "London" to "Europe/London", "Paris" to "Europe/Paris", "New York" to "America/New_York", "Chicago" to "America/Chicago",
    "Los Angeles" to "America/Los_Angeles", "Dubai" to "Asia/Dubai", "Delhi" to "Asia/Kolkata", "Singapore" to "Asia/Singapore",
    "Tokyo" to "Asia/Tokyo", "Sydney" to "Australia/Sydney", "Auckland" to "Pacific/Auckland", "Johannesburg" to "Africa/Johannesburg",
)

private fun fmtMs(ms: Long, tenths: Boolean): String {
    val t = ms.coerceAtLeast(0L)
    val m = t / 60000; val s = (t / 1000) % 60; val d = (t / 100) % 10
    return if (tenths) String.format("%02d:%02d.%d", m, s, d) else String.format("%d:%02d:%02d", t / 3_600_000, m % 60, s)
}

@Composable
fun ClockPage(prefs: Prefs) {
    val c = LocalVw.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val chosen = prefs.s("worldclocks", "Europe/London,America/New_York,Asia/Dubai,Asia/Tokyo").split(",").filter { it.isNotBlank() }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        // world clocks
        VCard(Modifier.weight(1.2f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("World clocks", color = c.sub, fontSize = 13.sp)
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (id in chosen) {
                        val name = zones.firstOrNull { it.second == id }?.first ?: id
                        val tz = java.util.TimeZone.getTimeZone(id)
                        val f = SimpleDateFormat("HH:mm", Locale.getDefault()).apply { timeZone = tz }
                        val day = SimpleDateFormat("EEE", Locale.getDefault()).apply { timeZone = tz }
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface2).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text(day.format(Date(now)), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(end = 10.dp))
                            Text(f.format(Date(now)), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(zones) { (label, id) ->
                        val on = id in chosen
                        Pill(label, on, {
                            val next = if (on) chosen - id else chosen + id
                            prefs.put("worldclocks", next.joinToString(","))
                        })
                    }
                }
            }
        }
        // stopwatch
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Stopwatch", color = c.sub, fontSize = 13.sp, modifier = Modifier.align(Alignment.Start))
                Text(fmtMs(ClockTools.swElapsed, true), color = c.text, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(if (ClockTools.swRunning) "Stop" else "Start", true, { ClockTools.swToggle() })
                    Pill(if (ClockTools.swRunning) "Lap" else "Reset", false, { ClockTools.swLapOrReset() })
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(ClockTools.laps.size) { i ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text("Lap ${ClockTools.laps.size - i}", color = c.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(fmtMs(ClockTools.laps[i], true), color = c.text, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
        // timer
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Timer", color = c.sub, fontSize = 13.sp, modifier = Modifier.align(Alignment.Start))
                Text(fmtMs(ClockTools.timerLeft, false), color = if (ClockTools.timerDone) Bad else c.text, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                if (ClockTools.timerDone) Text("Time's up", color = Bad, fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (m in listOf(1, 5, 10, 15)) Pill("${m}m", false, { ClockTools.timerSet(m * 60_000L) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("+1 min", false, { ClockTools.timerAdd(60_000L) })
                    Pill("+5 min", false, { ClockTools.timerAdd(300_000L) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(if (ClockTools.timerRunning) "Pause" else "Start", true, { ClockTools.timerToggle() })
                    Pill("Reset", false, { ClockTools.timerReset() })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Trips
@Composable
fun TripsPage(engine: NavEngine) {
    val c = LocalVw.current
    val trips = engine.trips.all()
    var confirm by remember { mutableStateOf(false) }
    val dayFmt = remember { SimpleDateFormat("EEE d MMM", Locale.getDefault()) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val imp = engine.imperial
    val unitSpeed = if (imp) "mph" else "km/h"
    val k = if (imp) 2.23694 else 3.6
    val totalDist = trips.sumOf { it.dist }
    val totalSecs = trips.sumOf { (it.end - it.start) / 1000 }
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Trip log", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("${trips.size} trips  ·  ${Geo.fmtDist(totalDist, imp)}  ·  ${Geo.fmtDur(totalSecs.toDouble())} driving", color = c.sub, fontSize = 13.sp)
                }
                if (trips.isNotEmpty()) Pill(if (confirm) "Tap again to clear" else "Clear all", confirm, { if (confirm) { engine.trips.clear(); confirm = false } else confirm = true })
            }
            if (trips.isEmpty()) {
                Text("Trips are recorded automatically from your GPS when you drive and stop for a couple of minutes.", color = c.sub, fontSize = 15.sp)
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(trips) { t ->
                        val secs = ((t.end - t.start) / 1000).coerceAtLeast(1)
                        val avg = if (t.moving > 0) t.dist / t.moving else 0.0
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.surface2).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1.3f)) {
                                Text(dayFmt.format(Date(t.start)), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                Text(timeFmt.format(Date(t.start)) + " – " + timeFmt.format(Date(t.end)) + (if (t.to.isNotBlank()) "  ·  to ${t.to}" else ""), color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(Geo.fmtDist(t.dist, imp), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text(Geo.fmtDur(secs.toDouble()), color = c.sub, fontSize = 12.sp)
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text("avg ${(avg * k).roundToInt()} $unitSpeed", color = c.text, fontSize = 14.sp)
                                Text("top ${(t.maxSpeed * k).roundToInt()} $unitSpeed", color = c.sub, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Car log: fuel + service
@Composable
fun CarLogPage(engine: NavEngine) {
    val c = LocalVw.current
    var tab by remember { mutableIntStateOf(0) }
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Fuel log", tab == 0, { tab = 0 })
                Pill("Service reminders", tab == 1, { tab = 1 })
            }
            if (tab == 0) FuelTab(engine) else ServiceTab(engine.prefs)
        }
    }
}

@Composable
private fun NumField(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    TextField(
        value = value, onValueChange = onChange, singleLine = true, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        colors = TextFieldDefaults.colors(focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
        shape = RoundedCornerShape(14.dp), modifier = modifier,
    )
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.FuelTab(engine: NavEngine) {
    val c = LocalVw.current
    val store = remember { FuelStore(engine.prefs) }
    val entries = store.all()
    val imp = engine.imperial
    var litres by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var odo by remember { mutableStateOf("") }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    val money = remember { java.text.NumberFormat.getCurrencyInstance() }
    fun economy(i: Int): String? {
        val e = entries[i]
        val prev = entries.drop(i + 1).firstOrNull { it.odo > 0 } ?: return null
        if (e.odo <= 0 || e.odo <= prev.odo) return null
        val km = e.odo - prev.odo
        return if (imp) String.format("%.1f mpg", (km / 1.609344) / (e.litres / 4.54609)) else String.format("%.1f L/100km", e.litres / km * 100)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        NumField(litres, "Litres", { litres = it }, Modifier.weight(1f))
        NumField(cost, "Total cost", { cost = it }, Modifier.weight(1f))
        NumField(odo, "Odometer (km, optional)", { odo = it }, Modifier.weight(1.3f))
        Pill("Add fill-up", true, {
            val l = litres.replace(',', '.').toDoubleOrNull()
            val p = cost.replace(',', '.').toDoubleOrNull()
            if (l != null && l > 0 && p != null && p >= 0) {
                store.add(FuelEntry(System.currentTimeMillis(), l, p, odo.replace(',', '.').toDoubleOrNull() ?: 0.0))
                litres = ""; cost = ""; odo = ""
            } else engine.toast("Enter litres and total cost", 2500)
        })
    }
    if (entries.isEmpty()) Text("No fill-ups yet. Fuel economy appears once you log two fill-ups with odometer readings.", color = c.sub, fontSize = 14.sp)
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(entries.size) { i ->
            val e = entries[i]
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface2).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(dateFmt.format(Date(e.date)), color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text(String.format("%.1f L", e.litres), color = c.text, fontSize = 15.sp, modifier = Modifier.width(80.dp))
                Text(money.format(e.cost), color = c.text, fontSize = 15.sp, modifier = Modifier.width(90.dp))
                Text(economy(i) ?: "", color = c.accent, fontSize = 14.sp, modifier = Modifier.width(110.dp))
                Icon(Icons.Rounded.Close, "Delete", tint = c.sub, modifier = Modifier.size(22.dp).clickable { store.remove(e.date) })
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.ServiceTab(prefs: Prefs) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val store = remember { ServiceStore(prefs) }
    val items = store.all()
    var name by remember { mutableStateOf("") }
    var due by remember { mutableStateOf(System.currentTimeMillis() + 180L * 86_400_000L) }
    var repeat by remember { mutableIntStateOf(0) }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextField(
            value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Job (MOT, service, tyres…)") },
            colors = TextFieldDefaults.colors(focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
            shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1.4f),
        )
        Pill("Due ${dateFmt.format(Date(due))}", false, {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = due }
            android.app.DatePickerDialog(ctx, { _, y, m, d ->
                val n = java.util.Calendar.getInstance()
                n.set(y, m, d, 9, 0, 0)
                due = n.timeInMillis
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        })
        Pill(if (repeat == 0) "One-off" else "Every $repeat months", false, { repeat = when (repeat) { 0 -> 6; 6 -> 12; else -> 0 } })
        Pill("Add", true, {
            if (name.isNotBlank()) { store.add(name.trim(), due, repeat); name = "" }
        })
    }
    if (items.isEmpty()) Text("No reminders yet. Add the next MOT, service or insurance renewal and the launcher will warn you at start-up when it is close.", color = c.sub, fontSize = 14.sp)
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(items) { s ->
            val days = Math.floor((s.due - System.currentTimeMillis()) / 86_400_000.0).toInt()
            val col = if (days < 0) Bad else if (days < 30) Warn else c.text
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface2).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(dateFmt.format(Date(s.due)) + (if (s.repeatMonths > 0) "  ·  every ${s.repeatMonths} months" else ""), color = c.sub, fontSize = 12.sp)
                }
                Text(if (days < 0) "${-days} days overdue" else if (days == 0) "Today" else "in $days days", color = col, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(end = 12.dp))
                Pill("Done", false, { store.done(s.id) })
                Icon(Icons.Rounded.Close, "Delete", tint = c.sub, modifier = Modifier.padding(start = 10.dp).size(22.dp).clickable { store.remove(s.id) })
            }
        }
    }
}
