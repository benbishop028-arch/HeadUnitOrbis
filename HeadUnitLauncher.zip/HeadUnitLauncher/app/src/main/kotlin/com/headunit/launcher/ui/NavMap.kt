package com.headunit.launcher.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.background
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.headunit.launcher.nav.NavUi
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.map.display.TomTomMap as MapInstance
import com.tomtom.sdk.map.display.camera.CameraOptions
import com.tomtom.sdk.map.display.camera.InitialCameraOptions
import com.tomtom.sdk.map.display.compose.TomTomMap
import com.tomtom.sdk.map.display.compose.model.MapDisplayInfrastructure     // SDK-CHECK import
import com.tomtom.sdk.map.display.compose.model.MapLocationInfrastructure    // SDK-CHECK import
import com.tomtom.sdk.map.display.compose.state.rememberMapViewState         // SDK-CHECK import
import com.tomtom.sdk.map.display.route.RouteOptions                         // SDK-CHECK import
import kotlin.time.Duration.Companion.milliseconds

private val FRANKFURT = GeoPoint(latitude = 50.1109, longitude = 8.6821)

/**
 * One map instance for the whole launcher. On the Nav page it fills the screen;
 * on every other page the same instance is shrunk into a picture-in-picture window.
 */
@Composable
fun NavMap(
    ui: NavUi,
    follow: Boolean,
    tilt3d: Boolean,
    modifier: Modifier,
    onPan: () -> Unit,
) {
    if (!ui.sdkReady) {
        Box(modifier.background(Panel), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
        return
    }

    val infrastructure = remember {
        MapDisplayInfrastructure(sdkContext = TomTomSdk.sdkContext) {            // SDK-CHECK
            locationInfrastructure = MapLocationInfrastructure {
                locationProvider = TomTomSdk.locationProvider
            }
        }
    }
    val mapViewState = rememberMapViewState(
        initialCameraOptions = InitialCameraOptions.LocationBased(position = FRANKFURT, zoom = 12.0),
    )
    var map by remember { mutableStateOf<MapInstance?>(null) }

    TomTomMap(
        state = mapViewState,
        infrastructure = infrastructure,
        modifier = modifier,
        onMapReady = { m -> map = m },                                           // SDK-CHECK
        onMapPanningListener = { onPan() },                                      // SDK-CHECK
    )

    // Draw / clear the active route
    LaunchedEffect(map, ui.route) {
        val m = map ?: return@LaunchedEffect
        m.removeRoutes()                                                         // SDK-CHECK
        ui.route?.let { r ->
            m.addRoute(RouteOptions(geometry = r.geometry))                      // SDK-CHECK
        }
    }

    // Follow the car (3D chase camera while navigating, flat north-up when idle)
    LaunchedEffect(map, ui.position, ui.course, ui.navigating, tilt3d, follow) {
        val m = map ?: return@LaunchedEffect
        val p = ui.position ?: return@LaunchedEffect
        if (!follow) return@LaunchedEffect
        m.animateCamera(                                                         // SDK-CHECK
            CameraOptions(
                position = p,
                zoom = if (ui.navigating) 17.0 else 15.0,
                tilt = if (tilt3d) 55.0 else 0.0,
                rotation = if (ui.navigating) ui.course else 0.0,
            ),
            800.milliseconds,
        )
    }
}
