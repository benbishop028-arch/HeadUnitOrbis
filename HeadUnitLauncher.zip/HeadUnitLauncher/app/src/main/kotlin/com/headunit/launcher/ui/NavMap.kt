package com.headunit.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.headunit.launcher.nav.NavUi
import com.tomtom.sdk.init.TomTomSdk
import com.tomtom.sdk.location.GeoPoint
import com.tomtom.sdk.map.display.*
import com.tomtom.sdk.map.display.camera.CameraOptions
import com.tomtom.sdk.map.display.camera.InitialCameraOptions
import com.tomtom.sdk.map.display.compose.TomTomMap
import com.tomtom.sdk.map.display.compose.model.MapDisplayInfrastructure
import com.tomtom.sdk.map.display.compose.state.rememberMapViewState
import com.tomtom.sdk.map.display.compose.*
import com.tomtom.sdk.map.display.visualization.routing.*
import com.tomtom.sdk.map.display.visualization.routing.compose.*
import com.tomtom.sdk.map.display.visualization.routing.compose.model.*
import com.tomtom.sdk.map.display.visualization.routing.compose.state.*
import kotlin.time.Duration.Companion.milliseconds

private val FRANKFURT = GeoPoint(latitude = 50.1109, longitude = 8.6821)

@Composable
fun NavMap(
    ui: NavUi,
    routingInfrastructure: RoutingVisualizationInfrastructure,
    follow: Boolean,
    tilt3d: Boolean,
    modifier: Modifier,
    onPan: () -> Unit,
) {
    if (!ui.sdkReady) {
        Box(modifier.background(Panel), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
        return
    }

    val infrastructure = remember {
        MapDisplayInfrastructure(sdkContext = TomTomSdk.sdkContext) {
            locationInfrastructure = MapLocationInfrastructure {
                locationProvider = TomTomSdk.locationProvider
            }
        }
    }
    val mapViewState = rememberMapViewState(
        initialCameraOptions = InitialCameraOptions.LocationBased(position = FRANKFURT, zoom = 12.0),
    )

    TomTomMap(
        state = mapViewState,
        infrastructure = infrastructure,
        modifier = modifier,
        onMapPanningListener = { onPan() },
    ) {
        RoutingVisualization(
            infrastructure = routingInfrastructure,
            state = rememberRoutingVisualizationState(),
        ) {}
    }

    LaunchedEffect(ui.position, ui.course, ui.navigating, tilt3d, follow) {
        val p = ui.position ?: return@LaunchedEffect
        if (!follow) return@LaunchedEffect
        mapViewState.cameraState.animateCamera(
            CameraOptions(
                position = p,
                zoom = if (ui.navigating) 17.0 else 15.0,
                tilt = if (tilt3d) 55.0 else 0.0,
                rotation = if (ui.navigating) ui.course else 0.0,
            ),
            800.milliseconds,
        )
    }
}
