package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EvStation
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ThreeDRotation
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.CalEvent
import com.headunit.launcher.CalendarData
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.PhoneData
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** What can be shown on the left of the bottom bar, in the order used in "custom" mode. */
val BarInfoIds = listOf("turn", "eta", "speed", "incident", "journey", "calendar", "weather", "clock", "car")
val BarInfoNames = mapOf(
    "turn" to "Next turn", "eta" to "Arrival time", "speed" to "Speed & limit", "incident" to "Roadworks & cameras",
    "journey" to "Home / Work times", "calendar" to "Next appointment", "weather" to "Weather", "clock" to "Clock", "car" to "My car",
)
const val DefaultBarSlots = "share,fuel,parking,mute"

private class BarEntry(val width: Dp, val content: @Composable () -> Unit)

@Composable
private fun InfoChip(
    value: String, sub: String, width: Dp, modifier: Modifier = Modifier, valueColor: Color? = null, subColor: Color? = null,
    progress: Float? = null, leading: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null,
) {
    val c = LocalVw.current
    Row(
        modifier.width(width).height(52.dp).clip(RoundedCornerShape(14.dp)).background(c.surface)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .drawBehind {
                if (progress != null) {
                    drawRect(c.accent, topLeft = Offset(0f, size.height - 3.dp.toPx()), size = androidx.compose.ui.geometry.Size(size.width * progress.coerceIn(0f, 1f), 3.dp.toPx()))
                }
            }
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) { leading(); Box(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f)) {
            Text(value, color = valueColor ?: c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = subColor ?: c.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun slotLabel(id: String, prefs: Prefs, hooks: List<com.headunit.launcher.Hook>): String = when {
    id == "share" -> "Share ETA"; id == "fuel" -> "Fuel"; id == "charging" -> "EV charger"; id == "parking" -> "Parking"
    id == "mute" -> "Voice on/off"; id == "recentre" -> "Recentre map"; id == "tilt" -> "2D / 3D"; id == "home" -> "Go home"; id == "work" -> "Go to work"
    id.startsWith("app:") -> "App"
    id.startsWith("call:") -> "Call " + id.substringAfter('|', "")
    id.startsWith("hook:") -> hooks.getOrNull(id.removePrefix("hook:").toIntOrNull() ?: -1)?.name ?: "Button"
    else -> id
}
fun barSlotLabel(id: String, prefs: Prefs, hooks: List<com.headunit.launcher.Hook>, apps: AppsRepo): String =
    if (id.startsWith("app:")) apps.find(id.removePrefix("app:"))?.label ?: "App" else slotLabel(id, prefs, hooks)

/** Bottom strip: info on the left, the home key in the middle, shortcuts on the right. */
@Composable
fun BottomBar(prefs: Prefs, page: Page, amb: Color, engine: NavEngine, apps: AppsRepo, onPage: (Page) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val mini = if (page == Page.Nav) prefs.s("mini", "right") else "off"
    val enter = expandHorizontally() + fadeIn()
    val exit = shrinkHorizontally() + fadeOut()
    val shareEta = rememberShareEta(engine)

    // clock tick and next appointment (with the driving time to it)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(20_000) } }
    var event by remember { mutableStateOf<CalEvent?>(null) }
    var eventTravel by remember { mutableStateOf<Pair<Place, Int>?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            event = withContext(Dispatchers.IO) { CalendarData.upcoming(ctx, 1).firstOrNull { !it.allDay && it.begin > System.currentTimeMillis() - 600_000 } }
            delay(5 * 60_000L)
        }
    }
    LaunchedEffect(event?.begin, event?.where, engine.fix != null) {
        val e = event
        eventTravel = null
        if (e != null && e.where.isNotBlank() && engine.fix != null && e.begin - System.currentTimeMillis() < 3 * 3_600_000L) eventTravel = engine.travelTo(e.where)
    }

    val navigating = engine.route != null && !engine.previewing
    val moving = (engine.fix?.speed ?: 0.0) > 1.5
    val custom = prefs.s("barmode", "smart") == "custom"
    val order: List<String> = when {
        custom -> BarInfoIds
        navigating -> listOf("turn", "eta", "incident", "speed", "weather")
        moving -> listOf("speed", "incident", "journey", "weather")
        else -> listOf("calendar", "journey", "weather", "clock", "car")
    }.filter { prefs.b("bar_$it", true) }

    val imp = engine.imperial
    val k = if (imp) 2.23694 else 3.6
    val entries = ArrayList<BarEntry>()
    for (id in order) {
        when (id) {
            "turn" -> engine.turn?.let { t -> if (navigating) entries += BarEntry(210.dp) {
                InfoChip(Geo.fmtDist(t.dist, imp), t.street, 210.dp, leading = { ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(30.dp), color = c.text) }, onClick = { onPage(Page.Nav) })
            } }
            "eta" -> engine.eta?.let { e -> if (navigating) entries += BarEntry(170.dp) {
                InfoChip(e.arrive, Geo.fmtDur(e.secs) + " · " + Geo.fmtDist(e.dist, imp) + (if (e.delayMin >= 1) " · +${e.delayMin}m" else ""), 170.dp, progress = engine.routeFrac, subColor = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else null, onClick = { onPage(Page.Nav) })
            } }
            "speed" -> engine.fix?.let { f -> entries += BarEntry(140.dp) {
                val lim = engine.speedLimit?.let { (Math.round(it * k / 5.0) * 5).toInt() }
                InfoChip("${Math.round(f.speed * k)}", (if (imp) "mph" else "km/h") + (if (lim != null) " · limit $lim" else ""), 140.dp, valueColor = if (engine.overLimit) Bad else null, subColor = if (engine.overLimit) Bad else null, onClick = { onPage(Page.Drive) })
            } }
            "incident" -> {
                val inc = engine.incidentAhead
                val cam = engine.cameraDist
                if (inc != null) entries += BarEntry(170.dp) { InfoChip(inc.label, Geo.fmtDist(inc.dist, imp) + " ahead", 170.dp, valueColor = Warn) }
                else if (cam != null) entries += BarEntry(150.dp) { InfoChip("Camera", Geo.fmtDist(cam.toDouble(), imp) + " ahead", 150.dp, valueColor = Bad) }
            }
            "journey" -> if (!navigating) engine.quickEtas.forEach { q -> entries += BarEntry(130.dp) {
                InfoChip("${q.minutes} min", "to ${q.name}" + (if (q.delayMin >= 2) " · +${q.delayMin}" else ""), 130.dp, subColor = if (q.delayMin >= 5) Warn else null, onClick = { engine.startRoute(q.place); onPage(Page.Nav) })
            } }
            "calendar" -> event?.let { e ->
                val mins = ((e.begin - now) / 60000).toInt()
                val travel = eventTravel
                val leaveIn = if (travel != null) mins - travel.second else null
                val sub = when {
                    travel != null && leaveIn != null && leaveIn <= 0 -> "Leave now · ${travel.second} min away"
                    travel != null && leaveIn != null -> "Leave in $leaveIn min · ${travel.second} min away"
                    mins <= 0 -> "Now"
                    mins < 60 -> "In $mins min"
                    else -> "At " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(e.begin))
                }
                entries += BarEntry(230.dp) {
                    InfoChip(e.title, sub, 230.dp, subColor = if (leaveIn != null && leaveIn <= 5) Warn else null, onClick = {
                        val t = travel
                        if (t != null) { engine.startRoute(t.first); onPage(Page.Nav) } else onPage(Page.Calendar)
                    })
                }
            }
            "weather" -> engine.weather?.let { w -> entries += BarEntry(130.dp) {
                val temp = if (isImperial(prefs)) "${(w.tempC * 9 / 5 + 32).roundToInt()}°" else "${w.tempC.roundToInt()}°"
                InfoChip(temp, Weather.text(w.code), 130.dp, onClick = { onPage(Page.Weather) })
            } }
            "clock" -> entries += BarEntry(120.dp) {
                InfoChip(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)), SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(now)), 120.dp, onClick = { onPage(Page.Clock) })
            }
            "car" -> {
                val car = engine.places.parked()
                val here = engine.fix?.pos
                if (car != null && here != null) {
                    val d = Geo.dist(here, car.pos)
                    if (d in 40.0..30_000.0) entries += BarEntry(140.dp) {
                        InfoChip("My car", Geo.fmtDist(d, imp), 140.dp, leading = { Icon(Icons.Rounded.DirectionsCar, null, tint = c.sub, modifier = Modifier.size(22.dp)) }, onClick = { engine.startRoute(car); onPage(Page.Nav) })
                    }
                }
            }
        }
    }

    val slotIds = prefs.s("barslots", DefaultBarSlots).split(",").filter { it.isNotBlank() }
    val hooks = remember(prefs.s("hooks", "")) { engine.hooks.all() }

    BoxWithConstraints(
        Modifier.fillMaxWidth().height(70.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.0f), c.bg.copy(alpha = 0.85f))))
            .drawBehind {
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, amb, amb, Color.Transparent)),
                    topLeft = Offset(size.width * 0.04f, size.height - 4f), size = androidx.compose.ui.geometry.Size(size.width * 0.92f, 4f),
                )
            },
    ) {
        val half = maxWidth / 2 - 54.dp - 28.dp
        val miniW = 278.dp
        val leftAvail = half - (if (mini == "left") miniW else 0.dp)
        val rightAvail = half - (if (mini == "right") miniW else 0.dp)

        // left: mini player (if on the left) then as many info chips as fit
        Row(Modifier.align(Alignment.CenterStart).padding(start = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedVisibility(mini == "left", enter = enter, exit = exit) { MiniPlayer { onPage(Page.Media) } }
            var used = 0.dp
            for (en in entries) {
                if (used + en.width > leftAvail) break
                used += en.width + 8.dp
                en.content()
            }
        }
        HomeKey(amb, c.text, { onPage(Page.Home) }, Modifier.align(Alignment.Center).padding(bottom = 4.dp))

        // right: shortcut slots then the mini player (if on the right)
        Row(Modifier.align(Alignment.CenterEnd).padding(end = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val fit = (rightAvail / 54.dp).toInt().coerceAtLeast(0)
            for (id in slotIds.take(fit)) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(c.surface).clickable {
                        when {
                            id == "share" -> shareEta()
                            id == "fuel" -> { engine.loadNearby("fuel", false); onPage(Page.Nav) }
                            id == "charging" -> { engine.loadNearby("charging", false); onPage(Page.Nav) }
                            id == "parking" -> { engine.loadNearby("parking", false); onPage(Page.Nav) }
                            id == "mute" -> prefs.put("voice", !engine.voiceOn)
                            id == "recentre" -> { engine.recenter(); onPage(Page.Nav) }
                            id == "tilt" -> engine.toggleTilt()
                            id == "home" -> engine.places.slot("home")?.let { engine.startRoute(it); onPage(Page.Nav) } ?: engine.toast("No home address saved", 2500)
                            id == "work" -> engine.places.slot("work")?.let { engine.startRoute(it); onPage(Page.Nav) } ?: engine.toast("No work address saved", 2500)
                            id.startsWith("app:") -> com.headunit.launcher.Launch.app(ctx, id.removePrefix("app:"), null)
                            id.startsWith("call:") -> PhoneData.call(ctx, id.removePrefix("call:").substringBefore('|'))
                            id.startsWith("hook:") -> hooks.getOrNull(id.removePrefix("hook:").toIntOrNull() ?: -1)?.let { h ->
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) { engine.hooks.fire(h) }
                                    engine.toast(if (ok) "${h.name}: done" else "${h.name}: failed", 2500)
                                }
                            }
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    val app = if (id.startsWith("app:")) apps.find(id.removePrefix("app:")) else null
                    if (app != null) Image(app.icon, null, Modifier.size(32.dp), contentScale = ContentScale.Fit)
                    else if (id.startsWith("call:")) {
                        val nm = id.substringAfter('|', "")
                        if (nm.isNotBlank()) Text(nm.take(1).uppercase(), color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        else Icon(Icons.Rounded.Call, null, tint = c.text, modifier = Modifier.size(24.dp))
                    } else {
                        val icon: ImageVector = when {
                            id == "share" -> Icons.Rounded.Share
                            id == "fuel" -> Icons.Rounded.LocalGasStation
                            id == "charging" -> Icons.Rounded.EvStation
                            id == "parking" -> Icons.Rounded.LocalParking
                            id == "mute" -> if (engine.voiceOn) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff
                            id == "recentre" -> Icons.Rounded.MyLocation
                            id == "tilt" -> Icons.Rounded.ThreeDRotation
                            id == "home" -> Icons.Rounded.Home
                            id == "work" -> Icons.Rounded.Work
                            else -> Icons.Rounded.Bolt
                        }
                        Icon(icon, null, tint = c.text, modifier = Modifier.size(24.dp))
                    }
                }
            }
            AnimatedVisibility(mini == "right", enter = enter, exit = exit) { MiniPlayer { onPage(Page.Media) } }
        }
    }
}
