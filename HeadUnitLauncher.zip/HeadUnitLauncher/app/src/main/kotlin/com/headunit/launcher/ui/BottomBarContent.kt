package com.headunit.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LocalPolice
import androidx.compose.material.icons.rounded.TurnRight
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EvStation
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.LocalParking
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.CalEvent
import com.headunit.launcher.CalendarData
import com.headunit.launcher.Geo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.PhoneData
import com.headunit.launcher.Place
import com.headunit.launcher.Prefs
import com.headunit.launcher.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** What can be shown on the left of the bottom bar, in the order used in "custom" mode. */
val BarInfoIds = listOf("turn", "eta", "limit", "speed", "incident", "journey", "calendar", "weather", "clock", "bigclock", "favs", "car")
val BarInfoNames = mapOf(
    "turn" to "Next turn", "eta" to "Arrival time", "limit" to "Speed limit sign", "speed" to "Speedometer", "incident" to "Roadworks & cameras",
    "journey" to "Home / Work times", "calendar" to "Next appointment", "weather" to "Weather", "clock" to "Clock", "car" to "My car",
    "bigclock" to "Clock (large)", "favs" to "Favourite apps",
)
const val DefaultBarSlots = "share,fuel,parking,mute"

/** Whether a bar widget is switched on. The newer large clock and favourites panel start switched off. */
fun barWidgetOn(prefs: Prefs, id: String) = prefs.b("bar_$id", id != "bigclock" && id != "favs")

/** Every shortcut button that can sit at the ends of the bar (apps and contacts are added separately). */
val BarShortcutIds = listOf("share", "fuel", "charging", "parking", "mute", "recentre", "tilt", "home", "work", "recents", "police")

fun slotIcon(id: String, soundMode: Int): ImageVector = when (id) {
    "share" -> Icons.Rounded.Share
    "fuel" -> Icons.Rounded.LocalGasStation
    "charging" -> Icons.Rounded.EvStation
    "parking" -> Icons.Rounded.LocalParking
    "mute" -> when (soundMode) { 0 -> Icons.Rounded.VolumeUp; 1 -> Icons.Rounded.NotificationsActive; else -> Icons.Rounded.VolumeOff }
    "recentre" -> Icons.Rounded.MyLocation
    "tilt" -> Icons.Rounded.Explore
    "home" -> Icons.Rounded.Home
    "work" -> Icons.Rounded.Work
    "recents" -> Icons.Rounded.History
    "police" -> Icons.Rounded.LocalPolice
    else -> Icons.Rounded.Bolt
}

/** A modern clock: bold hours, light minutes, a softly pulsing accent colon, and the weekday and date in a small stack beside it. */
@Composable
internal fun BigClock(now: Long, h24: Boolean, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val c = LocalVw.current
    val pulse by rememberPulse(true, 1100, 0.3f, 1f)
    val d = Date(now)
    val hh = SimpleDateFormat(if (h24) "HH" else "h", Locale.getDefault()).format(d)
    val mm = SimpleDateFormat("mm", Locale.getDefault()).format(d)
    val ampm = if (h24) "" else SimpleDateFormat("a", Locale.getDefault()).format(d).uppercase()
    val day = SimpleDateFormat("EEE", Locale.getDefault()).format(d).uppercase()
    val date = SimpleDateFormat("d MMM", Locale.getDefault()).format(d)
    Row(
        modifier.height(60.dp).clip(RoundedCornerShape(16.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(hh, color = c.onBg, fontSize = 40.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(":", color = c.accent.copy(alpha = pulse), fontSize = 36.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(start = 2.dp, end = 2.dp, bottom = 4.dp))
            Text(mm, color = c.onBg, fontSize = 40.sp, fontWeight = FontWeight.Light, maxLines = 1)
            if (ampm.isNotEmpty()) Text(ampm, color = c.onBgSub, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 14.dp))
        }
        Box(Modifier.width(1.dp).height(30.dp).background(c.onBgSub.copy(alpha = 0.35f)))
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(day, color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, maxLines = 1)
            Text(date, color = c.onBgSub, fontSize = 14.sp, maxLines = 1)
        }
    }
}

/** 1 to 4 favourite apps in a soft capsule. An empty slot shows a plus that lets you choose an app. */
@Composable
internal fun FavApps(prefs: Prefs, apps: AppsRepo, onEmpty: (Int) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val n = prefs.i("favn", 3).coerceIn(1, 4)
    Row(
        Modifier.clip(RoundedCornerShape(32.dp)).background(c.onBg.copy(alpha = 0.07f)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        for (i in 1..n) {
            val pkg = prefs.s("fav$i", "")
            val app = if (pkg.isBlank()) null else apps.find(pkg)
            Box(
                Modifier.size(52.dp).clip(CircleShape).pressClick { if (app != null) com.headunit.launcher.Launch.app(ctx, pkg) else onEmpty(i) },
                contentAlignment = Alignment.Center,
            ) {
                if (app != null) Image(app.icon, app.label, Modifier.size(38.dp), contentScale = ContentScale.Fit)
                else Icon(Icons.Rounded.Add, "Add app", tint = c.onBgSub, modifier = Modifier.size(26.dp))
            }
        }
    }
}

/** What a bar widget looks like, with sample values (the clock and favourites show your real ones). */
@Composable
internal fun BarWidgetPreview(id: String, prefs: Prefs, apps: AppsRepo) {
    val c = LocalVw.current
    when (id) {
        "turn" -> InfoChip("0.3 mi", "High Street", 210.dp, leading = { Icon(Icons.Rounded.TurnRight, null, tint = c.onBg, modifier = Modifier.size(30.dp)) })
        "eta" -> InfoChip("14:32", "18 min · 7.4 mi", 170.dp, progress = 0.4f)
        "limit" -> Box(Modifier.size(58.dp).clip(CircleShape).background(Color.White).border(6.dp, Color(0xFFD32F2F), CircleShape), contentAlignment = Alignment.Center) {
            Text("40", color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        "speed" -> InfoChip("36", "mph", 110.dp)
        "incident" -> InfoChip("Roadworks", "0.8 mi ahead", 170.dp, valueColor = Warn)
        "journey" -> InfoChip("12 min", "to Home", 130.dp)
        "calendar" -> InfoChip("Dentist", "Leave in 14 min · 9 min away", 230.dp)
        "weather" -> InfoChip("14°", "Partly cloudy", 170.dp, leading = { Icon(wxIcon(2), null, tint = wxTint(2), modifier = Modifier.size(34.dp)) })
        "clock" -> InfoChip("14:08", "Sun 18 Oct", 120.dp)
        "bigclock" -> BigClock(System.currentTimeMillis(), prefs.b("clock24", true))
        "favs" -> FavApps(prefs, apps) { }
        "car" -> InfoChip("My car", "0.4 mi", 140.dp, leading = { Icon(Icons.Rounded.DirectionsCar, null, tint = c.onBgSub, modifier = Modifier.size(22.dp)) })
    }
}

/** Settings: every info widget as a card with a preview of how it looks; tap a card to switch it on or off. */
@Composable
fun BarWidgetGallery(prefs: Prefs, apps: AppsRepo) {
    val c = LocalVw.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BarInfoIds.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (id in row) {
                    val on = barWidgetOn(prefs, id)
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(c.tile)
                            .border(if (on) 2.dp else 1.dp, if (on) c.accent else c.line.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                            .clickable { prefs.put("bar_$id", !on) }.padding(12.dp),
                    ) {
                        Box(Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(12.dp)).background(c.bg), contentAlignment = Alignment.Center) {
                            BarWidgetPreview(id, prefs, apps)
                        }
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(BarInfoNames[id] ?: id, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Text(if (on) "On" else "Off", color = if (on) c.accent else c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                        val side = prefs.s("barside_$id", "auto")
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Side", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(end = 2.dp))
                            Pill("Left", side == "left", { prefs.put("barside_$id", "left") })
                            Pill("Auto", side != "left" && side != "right", { prefs.put("barside_$id", "auto") })
                            Pill("Right", side == "right", { prefs.put("barside_$id", "right") })
                        }
                    }
                }
                if (row.size < 2) Box(Modifier.weight(1f))
            }
        }
    }
}

/** Settings: the shortcut buttons as round-icon cards; tap one to add it to the bar. */
@Composable
fun ShortcutGallery(label: (String) -> String, soundMode: Int, onAdd: (String) -> Unit) {
    val c = LocalVw.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BarShortcutIds.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (id in row) {
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(c.tile).clickable { onAdd(id) }.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.size(54.dp).clip(CircleShape).background(c.text.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                            Icon(slotIcon(id, soundMode), null, tint = c.text, modifier = Modifier.size(28.dp))
                        }
                        Text(label(id), color = c.text, fontSize = 13.sp, maxLines = 2, modifier = Modifier.padding(top = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                repeat(4 - row.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}

/** The apps most recently opened through this launcher. */
@Composable
private fun RecentAppsDialog(apps: AppsRepo, onDismiss: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val list = remember { com.headunit.launcher.Launch.recent(ctx).mapNotNull { apps.find(it) }.take(8) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).padding(18.dp).width(560.dp)) {
            Text("Recent apps", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (list.isEmpty()) Text("Apps you open from this launcher will appear here.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp))
            else LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.heightIn(max = 260.dp).padding(top = 10.dp)) {
                items(list) { a -> AppTile(a, Modifier) { com.headunit.launcher.Launch.app(ctx, a.pkg); onDismiss() } }
            }
        }
    }
}

private class BarEntry(val width: Dp, val content: @Composable () -> Unit) { var id = "" }

@Composable
private fun BarDivider() {
    val c = LocalVw.current
    Box(Modifier.width(1.dp).height(40.dp).background(c.onBgSub.copy(alpha = 0.35f)))
}

@Composable
private fun InfoChip(
    value: String, sub: String, width: Dp, modifier: Modifier = Modifier, valueColor: Color? = null, subColor: Color? = null,
    progress: Float? = null, leading: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null,
) {
    val c = LocalVw.current
    Row(
        modifier.width(width).height(60.dp).clip(RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .drawBehind {
                if (progress != null) {
                    val w = size.width * progress.coerceIn(0f, 1f)
                    drawRoundRect(c.accent, topLeft = Offset(10.dp.toPx(), size.height - 5.dp.toPx()), size = androidx.compose.ui.geometry.Size((w - 20.dp.toPx()).coerceAtLeast(0f), 2.5.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                }
            }
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) { leading(); Box(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f)) {
            RollText(value, valueColor ?: c.onBg, 20.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = subColor ?: c.onBgSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun slotLabel(id: String, prefs: Prefs, hooks: List<com.headunit.launcher.Hook>): String = when {
    id == "share" -> "Share ETA"; id == "fuel" -> "Fuel"; id == "charging" -> "EV charger"; id == "parking" -> "Parking"
    id == "mute" -> "Sound: all / alerts / off"; id == "recentre" -> "Recentre map"; id == "tilt" -> "2D / 3D"; id == "home" -> "Go home"; id == "work" -> "Go to work"; id == "recents" -> "Recent apps"; id == "police" -> "Report police"
    id.startsWith("app:") -> "App"
    id.startsWith("call:") -> "Call " + id.substringAfter('|', "")
    id.startsWith("hook:") -> hooks.getOrNull(id.removePrefix("hook:").toIntOrNull() ?: -1)?.name ?: "Button"
    else -> id
}
fun barSlotLabel(id: String, prefs: Prefs, hooks: List<com.headunit.launcher.Hook>, apps: AppsRepo): String =
    if (id.startsWith("app:")) apps.find(id.removePrefix("app:"))?.label ?: "App" else slotLabel(id, prefs, hooks)

/** Shortcuts for the left and right ends of the bar. Falls back to the older single list, which sat on the right. */
fun barSideSlots(prefs: Prefs): Pair<List<String>, List<String>> {
    fun parse(k: String) = prefs.s(k, "").split(",").filter { it.isNotBlank() }
    if (prefs.s("barslotsL", "#") != "#" || prefs.s("barslotsR", "#") != "#") return parse("barslotsL") to parse("barslotsR")
    val old = prefs.s("barslots", DefaultBarSlots).split(",").filter { it.isNotBlank() }
    return if (prefs.s("mini", "right") == "left") old to emptyList() else emptyList<String>() to old
}

/** Bottom strip: info on the left, the home key in the middle, shortcuts on the right. */
@Composable
fun BottomBar(prefs: Prefs, page: Page, amb: Color, engine: NavEngine, apps: AppsRepo, onPage: (Page) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val mini = if (page == Page.Nav) prefs.s("mini", "right") else "off"
    val enter = expandHorizontally() + fadeIn()
    val exit = shrinkHorizontally() + fadeOut()
    val shareEta = rememberShareEta(engine)
    var showRecents by remember { mutableStateOf(false) }
    var pickFav by remember { mutableIntStateOf(0) }

    // clock tick and next appointment (with the driving time to it)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(20_000) } }
    var event by remember { mutableStateOf<CalEvent?>(null) }
    var eventTravel by remember { mutableStateOf<Pair<Place, Int>?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            event = withContext(Dispatchers.IO) { CalendarData.upcoming(ctx, 1).firstOrNull { !it.allDay && it.begin > System.currentTimeMillis() - 600_000 } }
            delay(5 * 60_000L)
        }
    }
    LaunchedEffect(event?.begin, event?.where, engine.fix != null) {
        val e = event
        eventTravel = null
        if (e != null && e.where.isNotBlank() && engine.fix != null && e.begin - System.currentTimeMillis() < 3 * 3_600_000L) eventTravel = engine.travelTo(e.where)
    }

    val navigating = engine.route != null && !engine.previewing
    // flash the ETA when traffic suddenly adds 5+ minutes
    val etaDelay = engine.eta?.delayMin ?: 0
    var baseDelay by remember { mutableStateOf(-1) }
    var etaFlash by remember { mutableStateOf(false) }
    LaunchedEffect(etaDelay, engine.route == null) {
        if (engine.route == null) { baseDelay = -1; etaFlash = false }
        else if (baseDelay < 0) baseDelay = etaDelay
        else if (etaDelay - baseDelay >= 5) { baseDelay = etaDelay; etaFlash = true; delay(6000); etaFlash = false }
        else if (etaDelay < baseDelay) baseDelay = etaDelay
    }
    val blink by rememberPulse(etaFlash, 500, 0.4f, 1f)
    val moving = (engine.fix?.speed ?: 0.0) > 1.5
    val custom = prefs.s("barmode", "smart") == "custom"
    val order: List<String> = when {
        custom -> BarInfoIds
        navigating -> listOf("turn", "eta", "limit", "incident", "speed")
        moving -> listOf("limit", "speed", "incident", "journey")
        else -> listOf("limit", "calendar", "journey", "car")
    }.let { if (custom) it else it + listOf("bigclock", "favs") }.filter { barWidgetOn(prefs, it) }
        // the Navigation page already shows the turn, ETA and hazards on screen, so the bar doesn't repeat them there
        .filter { page != Page.Nav || it !in setOf("turn", "eta", "incident", "limit") }
        // current weather sits on the bar on every page (Home, map, menus)
        .let { o -> if (!custom && prefs.b("bar_weather", true) && "weather" !in o) listOf("weather") + o else o }

    val imp = engine.imperial
    val k = if (imp) 2.23694 else 3.6
    val entries = ArrayList<BarEntry>()
    for (id in order) {
        when (id) {
            "turn" -> engine.turn?.let { t -> if (navigating) entries += BarEntry(210.dp) {
                InfoChip(Geo.fmtDist(t.dist, imp), t.street, 210.dp, leading = { ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(30.dp), color = c.onBg) }, onClick = { onPage(Page.Nav) })
            } }
            "eta" -> engine.eta?.let { e -> if (navigating) entries += BarEntry(170.dp) {
                InfoChip(e.arrive, Geo.fmtDur(e.secs) + " · " + Geo.fmtDist(e.dist, imp) + (if (e.delayMin >= 1) " · +${e.delayMin}m" else ""), 170.dp, progress = engine.routeFrac, valueColor = if (etaFlash) Warn.copy(alpha = blink) else null, subColor = if (etaFlash) Warn.copy(alpha = blink) else if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else null, onClick = { onPage(Page.Nav) })
            } }
            "limit" -> if (engine.speedLimit != null) entries.add(0, BarEntry(58.dp) { SpeedLimitSign(engine, 58.dp) { onPage(Page.Drive) } })
            "speed" -> engine.fix?.let { f -> entries += BarEntry(110.dp) {
                InfoChip("${Math.round(f.speed * k)}", if (imp) "mph" else "km/h", 110.dp, valueColor = speedTint(engine), subColor = speedTint(engine), onClick = { onPage(Page.Drive) })
            } }
            "incident" -> {
                val inc = engine.incidentAhead
                val cam = engine.cameraDist
                if (inc != null) entries += BarEntry(170.dp) { InfoChip(inc.label, Geo.fmtDist(inc.dist, imp) + " ahead", 170.dp, valueColor = Warn) }
                else if (cam != null) entries += BarEntry(150.dp) { InfoChip("Camera", Geo.fmtDist(cam.toDouble(), imp) + " ahead", 150.dp, valueColor = Bad) }
            }
            "journey" -> if (!navigating) engine.quickEtas.forEach { q -> entries += BarEntry(130.dp) {
                InfoChip("${q.minutes} min", "to ${q.name}" + (if (q.delayMin >= 2) " · +${q.delayMin}" else ""), 130.dp, subColor = if (q.delayMin >= 5) Warn else null, onClick = { engine.startRoute(q.place); onPage(Page.Nav) })
            } }
            "calendar" -> event?.let { e ->
                val mins = ((e.begin - now) / 60000).toInt()
                val travel = eventTravel
                val leaveIn = if (travel != null) mins - travel.second else null
                val sub = when {
                    travel != null && leaveIn != null && leaveIn <= 0 -> "Leave now · ${travel.second} min away"
                    travel != null && leaveIn != null -> "Leave in $leaveIn min · ${travel.second} min away"
                    mins <= 0 -> "Now"
                    mins < 60 -> "In $mins min"
                    else -> "At " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(e.begin))
                }
                entries += BarEntry(230.dp) {
                    InfoChip(e.title, sub, 230.dp, subColor = if (leaveIn != null && leaveIn <= 5) Warn else null, onClick = {
                        val t = travel
                        if (t != null) { engine.startRoute(t.first); onPage(Page.Nav) } else onPage(Page.Calendar)
                    })
                }
            }
            "weather" -> engine.weather?.let { w -> entries += BarEntry(170.dp) {
                val temp = if (isImperial(prefs)) "${(w.tempC * 9 / 5 + 32).roundToInt()}°" else "${w.tempC.roundToInt()}°"
                // while navigating, warn when rain or snow is expected on the route
                val wet = if (navigating) engine.routeWx.firstOrNull { it.code in 51..67 || it.code in 80..82 || it.code in 95..99 || it.code in 71..77 || it.code in 85..86 || it.rain >= 70 } else null
                val snow = wet != null && (wet.code in 71..77 || wet.code in 85..86)
                InfoChip(temp, if (wet != null) (if (snow) "Snow" else "Rain") + " in ${wet.minutes} min" else Weather.text(w.code), 170.dp,
                    subColor = if (wet != null) NavBlue else null,
                    leading = { Icon(wxIcon(w.code), null, tint = wxTint(w.code), modifier = Modifier.size(34.dp)) }, onClick = { onPage(Page.Weather) })
            } }
            "clock" -> entries += BarEntry(120.dp) {
                InfoChip(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)), SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(now)), 120.dp, onClick = { onPage(Page.Clock) })
            }
            "bigclock" -> entries += BarEntry(215.dp) { BigClock(now, prefs.b("clock24", true), onClick = { onPage(Page.Clock) }) }
            "favs" -> { val n = prefs.i("favn", 3).coerceIn(1, 4); entries += BarEntry((n * 56 + 8).dp) { FavApps(prefs, apps) { pickFav = it } } }
            "car" -> {
                val car = engine.places.parked()
                val here = engine.fix?.pos
                if (car != null && here != null) {
                    val d = Geo.dist(here, car.pos)
                    if (d in 40.0..30_000.0) entries += BarEntry(140.dp) {
                        InfoChip("My car", Geo.fmtDist(d, imp), 140.dp, leading = { Icon(Icons.Rounded.DirectionsCar, null, tint = c.onBgSub, modifier = Modifier.size(22.dp)) }, onClick = { engine.startRoute(car); onPage(Page.Nav) })
                    }
                }
            }
        }
        for (en in entries) if (en.id.isEmpty()) en.id = id
    }

    val (slotsL, slotsR) = barSideSlots(prefs)
    val accentLine = c.accent
    // home button outline: your chosen colour, or whichever of light/dark contrasts with the background
    val homeLine = prefs.i("homecol", -1).let { if (it in AmbientColors.indices) AmbientColors[it] else c.onBg }
    val hooks = remember(prefs.s("hooks", "")) { engine.hooks.all() }

    BoxWithConstraints(
        Modifier.fillMaxWidth().height(78.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.0f), c.bg.copy(alpha = 0.85f))))
            .drawBehind {
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, amb, amb, Color.Transparent)),
                    topLeft = Offset(size.width * 0.04f, size.height - 4f), size = androidx.compose.ui.geometry.Size(size.width * 0.92f, 4f),
                )
                // trip progress as a thin line along the top edge while navigating
                if (navigating) {
                    val th = 2.5.dp.toPx()
                    drawRect(accentLine.copy(alpha = 0.18f), size = androidx.compose.ui.geometry.Size(size.width, th))
                    drawRect(accentLine, size = androidx.compose.ui.geometry.Size(size.width * engine.routeFrac.coerceIn(0f, 1f), th))
                }
            },
    ) {
        val half = maxWidth / 2 - 62.dp - 28.dp
        val miniW = 340.dp
        val infoLeft = mini != "left"          // the info chips sit opposite the music widget
        val miniL = if (mini == "left") miniW else 0.dp
        val miniR = if (mini == "right") miniW else 0.dp
        // every widget sits on the side you chose; "auto" puts it opposite the music widget
        fun sideOf(id: String): String { val v = prefs.s("barside_$id", "auto"); return if (v == "left" || v == "right") v else if (infoLeft) "left" else "right" }
        val groups = entries.groupBy { it.id }
        val widgetIds = entries.map { it.id }.distinct()
        // everything on one side (widgets and shortcuts) in the order you set with Reorder; anything not placed yet keeps the usual order
        fun tokensFor(side: String): List<String> {
            val ws = widgetIds.filter { sideOf(it) == side }
            val ss = if (side == "left") slotsL else slotsR
            val natural = if (side == "left") ss + ws.reversed() else ws + ss
            val order = prefs.s(if (side == "left") "barorderL" else "barorderR", "").split(",").filter { it.isNotBlank() }
            return natural.sortedBy { t -> order.indexOf(t).let { if (it < 0) 1000 + natural.indexOf(t) else it } }
        }
        fun widthOf(t: String): Dp = groups[t]?.let { g -> var w = 0.dp; g.forEach { w += it.width + 21.dp }; w } ?: 76.dp
        // when the room runs out, widgets (most important first) and then shortcuts are kept; they are still drawn in your order
        fun shown(side: String, room: Dp): List<String> {
            val tokens = tokensFor(side)
            val priority = tokens.filter { it in groups }.sortedBy { widgetIds.indexOf(it) } + tokens.filter { it !in groups }
            var used = 0.dp
            val keep = HashSet<String>()
            for (t in priority) { val w = widthOf(t); if (used + w > room) continue; used += w; keep += t }
            return tokens.filter { it in keep }
        }
        val displayL = shown("left", half - miniL)
        val displayR = shown("right", half - miniR)
        val slotsContent: @Composable (List<String>) -> Unit = { ids ->
          // shortcuts sit together in one soft capsule instead of being split by dividers
          if (ids.isNotEmpty()) Row(
            Modifier.clip(RoundedCornerShape(32.dp)).background(c.onBg.copy(alpha = 0.07f)).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp),
          ) {
            for ((slotN, id) in ids.withIndex()) {
                Box(
                    Modifier.size(54.dp).clip(CircleShape).pressClick {
                        when {
                            id == "share" -> shareEta()
                            id == "fuel" -> { engine.loadNearby("fuel", false); onPage(Page.Nav) }
                            id == "charging" -> { engine.loadNearby("charging", false); onPage(Page.Nav) }
                            id == "parking" -> { engine.loadNearby("parking", false); onPage(Page.Nav) }
                            id == "mute" -> engine.cycleSound()
                            id == "recents" -> showRecents = true
                            id == "police" -> engine.reportPolice()
                            id == "recentre" -> { engine.recenter(); onPage(Page.Nav) }
                            id == "tilt" -> engine.toggleTilt()
                            id == "home" -> engine.places.slot("home")?.let { engine.startRoute(it); onPage(Page.Nav) } ?: engine.toast("No home address saved", 2500)
                            id == "work" -> engine.places.slot("work")?.let { engine.startRoute(it); onPage(Page.Nav) } ?: engine.toast("No work address saved", 2500)
                            id.startsWith("app:") -> com.headunit.launcher.Launch.app(ctx, id.removePrefix("app:"), null)
                            id.startsWith("call:") -> PhoneData.call(ctx, id.removePrefix("call:").substringBefore('|'))
                            id.startsWith("hook:") -> hooks.getOrNull(id.removePrefix("hook:").toIntOrNull() ?: -1)?.let { h ->
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) { engine.hooks.fire(h) }
                                    engine.toast(if (ok) "${h.name}: done" else "${h.name}: failed", 2500)
                                }
                            }
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    val app = if (id.startsWith("app:")) apps.find(id.removePrefix("app:")) else null
                    if (app != null) Image(app.icon, null, Modifier.size(38.dp), contentScale = ContentScale.Fit)
                    else if (id.startsWith("call:")) {
                        val nm = id.substringAfter('|', "")
                        if (nm.isNotBlank()) Text(nm.take(1).uppercase(), color = c.onBg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        else Icon(Icons.Rounded.Call, null, tint = c.onBg, modifier = Modifier.size(24.dp))
                    } else {
                        val icon: ImageVector = slotIcon(id, engine.soundMode)
                        Icon(icon, null, tint = c.onBg, modifier = Modifier.size(28.dp))
                    }
                }
            }
          }
        }

        val sideContent: @Composable (List<String>) -> Unit = { display ->
            val items = ArrayList<Pair<Boolean, List<String>>>()      // (is a widget, ids); neighbouring shortcuts share one capsule
            for (t in display) {
                if (t in groups) items += true to listOf(t)
                else if (items.isNotEmpty() && !items.last().first) items[items.size - 1] = false to (items.last().second + t)
                else items += false to listOf(t)
            }
            items.forEachIndexed { i, item ->
                if (i > 0) BarDivider()
                if (item.first) groups[item.second[0]]?.forEachIndexed { j, e -> if (j > 0) BarDivider(); e.content() }
                else slotsContent(item.second)
            }
        }
        // left end: [mini player] [items]
        Row(
            Modifier.align(Alignment.CenterStart).padding(start = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AnimatedVisibility(mini == "left", enter = enter, exit = exit) { MiniPlayer { onPage(Page.Media) } }
            if (mini == "left" && displayL.isNotEmpty()) BarDivider()
            sideContent(displayL)
            if (displayL.isNotEmpty()) BarDivider()
        }
        HomeKey(amb, homeLine, { onPage(Page.Home) }, Modifier.align(Alignment.Center).padding(bottom = 4.dp))

        // right end: [items] [mini player]
        Row(
            Modifier.align(Alignment.CenterEnd).padding(end = 16.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (displayR.isNotEmpty()) BarDivider()
            sideContent(displayR)
            if (mini == "right" && displayR.isNotEmpty()) BarDivider()
            AnimatedVisibility(mini == "right", enter = enter, exit = exit) { MiniPlayer { onPage(Page.Media) } }
        }
        if (showRecents) RecentAppsDialog(apps) { showRecents = false }
        if (pickFav > 0) AppPickerDialog(apps, "Choose a favourite app", { prefs.put("fav$pickFav", it.pkg); pickFav = 0 }, { pickFav = 0 })
    }
}
