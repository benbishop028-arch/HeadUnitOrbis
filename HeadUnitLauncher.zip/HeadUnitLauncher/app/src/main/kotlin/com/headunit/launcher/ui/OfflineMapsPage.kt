package com.headunit.launcher.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.LL
import com.headunit.launcher.NavEngine
import com.headunit.launcher.OfflineMap
import com.headunit.launcher.OfflineRouter
import com.headunit.launcher.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun fmtSize(b: Long): String = if (b >= 1_000_000_000L) "%.1f GB".format(b / 1e9) else "%.0f MB".format(b / 1e6)

/** Everything about the downloaded offline pack: what is on the unit, how big it is, and download / update / delete. */
@Composable
internal fun OfflineMapsContent(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    @Suppress("UNUSED_VARIABLE") val rev = engine.packRev // re-read the files when a download or delete finishes
    var url by remember { mutableStateOf(prefs.s("offlineurl", "")) }
    var confirmDelete by remember { mutableStateOf(false) }
    var testOut by remember { mutableStateOf("") }
    var testBusy by remember { mutableStateOf(false) }

    val dir = OfflineRouter.dir(ctx)
    val routing = File(dir, "tiles.tar")
    val map = File(dir, "map.pmtiles")
    val search = File(dir, "places.tsv")
    val fonts = File(dir, "fonts")
    val installed = OfflineRouter.installed(ctx)
    val total = OfflineRouter.sizeOf(dir)
    val free = try { android.os.StatFs(dir.path).availableBytes } catch (e: Exception) { -1L }
    val built = if (routing.exists()) java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.UK).format(java.util.Date(routing.lastModified())) else ""

    Text(
        "Download a region once and the map, search and routes all work with no signal. The pack is a snapshot of the roads on the day it was built: download again to update it.",
        color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp),
    )

    // what is on the unit
    Text("On this unit", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 2.dp))
    @Composable fun part(name: String, what: String, size: Long) {
        Row2(name) {
            Text(if (size > 0) fmtSize(size) else "Not installed", color = if (size > 0) c.text else c.sub, fontSize = 15.sp)
        }
    }
    part("Routes", "tiles", OfflineRouter.sizeOf(routing))
    part("Map", "map", OfflineRouter.sizeOf(map))
    part("Search (streets, shops, places)", "search", OfflineRouter.sizeOf(search))
    part("House numbers and postcodes", "addresses", OfflineRouter.sizeOf(File(dir, "addresses.tsv")) + OfflineRouter.sizeOf(File(dir, "postcodes.tsv")))
    part("Map labels (fonts)", "fonts", OfflineRouter.sizeOf(fonts))
    Row2(if (installed) "Pack installed" + (if (built.isNotEmpty()) " (built $built)" else "") else "No pack installed") {
        Text(fmtSize(total) + (if (free >= 0) " used · ${fmtSize(free)} free" else " used"), color = c.sub, fontSize = 14.sp)
    }

    // download / update
    Text("Download or update", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 2.dp))
    Row2("Pack address") {
        TextField(
            value = url, onValueChange = { url = it; prefs.put("offlineurl", it.trim()) },
            placeholder = { Text("https://github.com/…/releases/download/pack-ew") }, singleLine = true,
            colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile),
            modifier = Modifier.width(420.dp),
        )
    }
    Row2(if (engine.packBusy) "Downloading, you can leave this page" else if (installed) "Update the pack (needs Wi-Fi, several GB)" else "Download the pack (needs Wi-Fi, several GB)") {
        Pill(if (engine.packBusy) "Working…" else if (installed) "Update" else "Download", false, { engine.downloadPack(url) })
    }
    if (engine.packBusy) LinearProgressIndicator(color = c.accent, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
    if (engine.packStatus.isNotBlank()) Text(engine.packStatus, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 6.dp))

    // map choice
    Text("Map without signal", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 2.dp))
    Row2("Which map to draw") {
        val om = prefs.s("offmap", "auto")
        Pill("Auto", om == "auto", { prefs.put("offmap", "auto"); engine.restyle() })
        Pill("Always downloaded", om == "always", { prefs.put("offmap", "always"); engine.restyle() })
        Pill("Always online", om == "never", { prefs.put("offmap", "never"); engine.restyle() })
    }
    Text("Auto uses the downloaded map when there is no signal and switches back when signal returns.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))

    // delete
    if (installed || total > 0) {
        Text("Free up space", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 2.dp))
        Row2("Delete the downloaded pack (${fmtSize(total)})") {
            if (!confirmDelete) Pill("Delete", false, { confirmDelete = true })
            else {
                Pill("Yes, delete it", false, { confirmDelete = false; engine.deletePack() })
                Pill("Keep", false, { confirmDelete = false })
            }
        }
    }

    // check it works
    Text("Check", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 2.dp))
    Row2("Test that offline routing starts and finds a route") {
        Pill(if (testBusy) "Working…" else "Run test", false, {
            if (!testBusy) {
                testBusy = true; testOut = "Running the test…"
                sc.launch {
                    val a = engine.fix?.pos ?: LL(50.9070, -1.4140)
                    val b = if (engine.fix != null) LL(a.lat + 0.03, a.lon) else LL(51.0632, -1.3080)
                    testOut = try { withContext(Dispatchers.Default) { OfflineRouter.diagnose(ctx, a, b) } } catch (e: Throwable) { "Test crashed: ${e.javaClass.simpleName} ${e.message}" }
                    testBusy = false
                }
            }
        })
    }
    if (testOut.isNotBlank()) Text(testOut, color = c.sub, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp).heightIn(max = 260.dp).verticalScroll(rememberScrollState()))
}
