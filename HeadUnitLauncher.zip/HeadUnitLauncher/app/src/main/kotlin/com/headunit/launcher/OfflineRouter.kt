package com.headunit.launcher

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Offline routing, stage 1: gets a region's routing data onto the device, starts the Valhalla engine on it and reports what happened.
 * The engine is driven by reflection for now, so this stays safe to build while its exact classes are confirmed on the real device.
 */
object OfflineRouter {
    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "offline").also { it.mkdirs() }

    fun installed(ctx: Context): Boolean =
        File(dir(ctx), "tiles.tar").let { it.exists() && it.length() > 100_000 } && File(dir(ctx), "valhalla.json").exists()

    /** Downloads valhalla.json, admins.sqlite and tiles.tar from [baseUrl] (for example a GitHub release's download folder). */
    fun download(ctx: Context, baseUrl: String, progress: (String) -> Unit) {
        val base = baseUrl.trim().trimEnd('/')
        for (name in listOf("valhalla.json", "admins.sqlite", "tiles.tar")) {
            progress("Downloading $name…")
            val c = URL("$base/$name").openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = true
            if (c.responseCode !in 200..299) throw java.io.IOException("$name: HTTP ${c.responseCode}")
            val tmp = File(dir(ctx), "$name.part")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val dst = File(dir(ctx), name)
            dst.delete(); tmp.renameTo(dst)
        }
    }

    /** The build machine's valhalla.json points at its own folders: rewrite those paths for this device. */
    private fun deviceConfig(ctx: Context): String {
        val d = dir(ctx)
        val j = JSONObject(File(d, "valhalla.json").readText())
        val m = j.getJSONObject("mjolnir")
        m.put("tile_extract", File(d, "tiles.tar").absolutePath)
        m.put("tile_dir", File(d, "tiles").absolutePath)
        m.put("admin", File(d, "admins.sqlite").absolutePath)
        m.remove("timezone")
        val out = File(d, "valhalla_device.json")
        out.writeText(j.toString())
        return out.absolutePath
    }

    private fun sig(m: java.lang.reflect.Method) =
        m.name + m.parameterTypes.joinToString(", ", "(", ")") { it.simpleName } + ": " + m.returnType.simpleName

    /** Starts the engine on the downloaded pack, asks it for a short route and returns a plain-text report of everything it found. */
    fun diagnose(ctx: Context, from: LL, to: LL): String {
        val sb = StringBuilder()
        sb.appendLine("Pack folder: ${dir(ctx)}")
        sb.appendLine(if (installed(ctx)) "Pack files: found (tiles.tar ${"%.0f".format(File(dir(ctx), "tiles.tar").length() / 1048576.0)} MB)" else "Pack files: NOT found (need tiles.tar and valhalla.json)")
        // which engine classes are in the app
        try {
            val names = ArrayList<String>()
            @Suppress("DEPRECATION")
            val df = dalvik.system.DexFile(ctx.packageCodePath)
            val en = df.entries()
            while (en.hasMoreElements()) {
                val n = en.nextElement()
                if (n.startsWith("com.valhalla") || n.startsWith("io.github.rallista")) names += n
            }
            sb.appendLine("Engine classes in the app: ${names.size}")
            names.filter { !it.contains('$') }.sorted().take(120).forEach { sb.appendLine("  $it") }
        } catch (e: Throwable) { sb.appendLine("Could not list classes: ${e.javaClass.simpleName} ${e.message}") }
        val cls = try { Class.forName("com.valhalla.valhalla.Valhalla") } catch (e: Throwable) {
            sb.appendLine("Engine class not found: ${e.javaClass.simpleName} ${e.message}"); return sb.toString()
        }
        sb.appendLine("Valhalla constructors:")
        cls.constructors.forEach { sb.appendLine("  $it") }
        sb.appendLine("Valhalla methods:")
        cls.methods.filter { it.declaringClass == cls }.forEach { sb.appendLine("  ${sig(it)}") }
        if (!installed(ctx)) return sb.toString()
        try {
            val cfg = deviceConfig(ctx)
            val ctor = cls.constructors.firstOrNull { it.parameterTypes.size == 1 && it.parameterTypes[0] == String::class.java }
            if (ctor == null) { sb.appendLine("No (String) constructor: need the other form"); return sb.toString() }
            val t0 = System.currentTimeMillis()
            val engine = ctor.newInstance(cfg)
            sb.appendLine("Engine started in ${System.currentTimeMillis() - t0} ms")
            try {
                val req = """{"locations":[{"lat":${from.lat},"lon":${from.lon}},{"lat":${to.lat},"lon":${to.lon}}],"costing":"auto"}"""
                val routeM = cls.methods.firstOrNull { it.name == "route" && it.parameterTypes.size == 1 }
                if (routeM == null) sb.appendLine("No route(request) method found")
                else {
                    val reqType = routeM.parameterTypes[0]
                    sb.appendLine("route() takes ${reqType.name}")
                    // build the typed request from JSON with Moshi, which the engine already depends on
                    val builderC = Class.forName("com.squareup.moshi.Moshi\$Builder")
                    val b = builderC.getDeclaredConstructor().newInstance()
                    val fac = Class.forName("com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory").getDeclaredConstructor().newInstance()
                    builderC.getMethod("add", Class.forName("com.squareup.moshi.JsonAdapter\$Factory")).invoke(b, fac)
                    val moshi = builderC.getMethod("build").invoke(b)
                    val adapter = moshi.javaClass.getMethod("adapter", Class::class.java).invoke(moshi, reqType)
                    val typed = adapter.javaClass.getMethod("fromJson", String::class.java).invoke(adapter, req)
                    val t1 = System.currentTimeMillis()
                    val resp = routeM.invoke(engine, typed)
                    sb.appendLine("Route answered in ${System.currentTimeMillis() - t1} ms")
                    sb.appendLine("Response type: ${resp?.javaClass?.name}")
                    sb.appendLine((resp?.toString() ?: "null").take(700))
                }
            } catch (e: Throwable) {
                val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
                sb.appendLine("Route test failed: ${c.javaClass.simpleName}: ${c.message}")
            }
            (engine as? java.io.Closeable)?.close()
        } catch (e: Throwable) {
            val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
            sb.appendLine("Engine failed: ${c.javaClass.simpleName}: ${c.message}")
        }
        return sb.toString()
    }

    // ---- real routing (stage 2) ----
    private var engine: com.valhalla.valhalla.Valhalla? = null
    private var engineStamp = 0L

    /** One engine, kept open and reused. It is rebuilt only if the pack file changes. */
    @Synchronized
    private fun engine(ctx: Context): com.valhalla.valhalla.Valhalla {
        val stamp = File(dir(ctx), "tiles.tar").lastModified()
        val cur = engine
        if (cur != null && stamp == engineStamp) return cur
        try { cur?.close() } catch (e: Exception) { }
        val e = com.valhalla.valhalla.Valhalla(deviceConfig(ctx))
        engine = e; engineStamp = stamp
        return e
    }

    private fun decode6(s: String): List<LL> {
        val out = ArrayList<LL>()
        var i = 0; var lat = 0; var lon = 0
        while (i < s.length) {
            var sh = 0; var r = 0; var b: Int
            do { b = s[i++].code - 63; r = r or ((b and 31) shl sh); sh += 5 } while (b >= 32)
            lat += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            sh = 0; r = 0
            do { b = s[i++].code - 63; r = r or ((b and 31) shl sh); sh += 5 } while (b >= 32)
            lon += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            out += LL(lat / 1e6, lon / 1e6)
        }
        return out
    }

    private fun manText(type: Int, exits: Int): String? = when (type) {
        1, 2, 3 -> "DEPART"
        4 -> "ARRIVE"; 5 -> "ARRIVE_RIGHT"; 6 -> "ARRIVE_LEFT"
        7, 8 -> "FOLLOW"
        9 -> "BEAR_RIGHT"; 10 -> "TURN_RIGHT"; 11 -> "SHARP_RIGHT"
        12, 13 -> "MAKE_UTURN"
        14 -> "SHARP_LEFT"; 15 -> "TURN_LEFT"; 16 -> "BEAR_LEFT"
        17, 22 -> "STRAIGHT"
        18, 20 -> "MOTORWAY_EXIT_RIGHT"; 19, 21 -> "MOTORWAY_EXIT_LEFT"
        23 -> "KEEP_RIGHT"; 24 -> "KEEP_LEFT"
        25, 37, 38 -> "FOLLOW"
        26 -> when { exits <= 1 -> "ROUNDABOUT_LEFT"; exits == 2 -> "ROUNDABOUT_CROSS"; exits == 3 -> "ROUNDABOUT_RIGHT"; else -> "ROUNDABOUT_BACK" }
        28 -> "TAKE_FERRY"
        else -> null // 0 none and 27 roundabout exit (the roundabout step already says which exit)
    }

    /** Routes on the device with no network. Blocking: call it off the main thread. */
    fun routes(ctx: Context, from: LL, to: LL, via: List<LL> = emptyList(), headingDeg: Double = -1.0): List<Route> {
        if (!installed(ctx)) throw IllegalStateException("No offline pack installed")
        val locs = org.json.JSONArray()
        locs.put(JSONObject().put("lat", from.lat).put("lon", from.lon).apply { if (headingDeg >= 0) { put("heading", headingDeg.toInt()); put("heading_tolerance", 60) } })
        for (v in via) locs.put(JSONObject().put("lat", v.lat).put("lon", v.lon).put("type", "through"))
        locs.put(JSONObject().put("lat", to.lat).put("lon", to.lon))
        val req = JSONObject().put("locations", locs).put("costing", "auto")
            .put("directions_options", JSONObject().put("units", "kilometers").put("language", "en-GB"))
        val raw = engine(ctx).routeRaw(req.toString())
        val o = JSONObject(raw)
        if (o.has("error") && !o.has("trip")) throw IllegalStateException("No offline route here (${o.optString("error")}). Is it inside the downloaded area?")
        val trip = o.getJSONObject("trip")
        val legs = trip.getJSONArray("legs")
        val pts = ArrayList<LL>()
        data class M(val base: Int, val m: JSONObject)
        val mans = ArrayList<M>()
        for (li in 0 until legs.length()) {
            val leg = legs.getJSONObject(li)
            val shape = decode6(leg.getString("shape"))
            val base = if (pts.isEmpty()) 0 else pts.size - 1
            if (pts.isEmpty()) pts.addAll(shape) else pts.addAll(shape.drop(1))
            val ms = leg.optJSONArray("maneuvers")
            if (ms != null) for (i in 0 until ms.length()) mans += M(base, ms.getJSONObject(i))
        }
        if (pts.size < 2) throw IllegalStateException("No offline route found")
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + Geo.dist(pts[i - 1], pts[i])
        val steps = ArrayList<Step>()
        for ((base, m) in mans) {
            val exits = m.optInt("roundabout_exit_count", 0)
            val man = manText(m.optInt("type", 0), exits) ?: continue
            val gi = (base + m.optInt("begin_shape_index", 0)).coerceIn(0, pts.size - 1)
            val names = m.optJSONArray("street_names")
            val street = if (names != null && names.length() > 0) names.optString(0) else ""
            val sign = m.optJSONObject("sign")
            val exitNo = sign?.optJSONArray("exit_number_elements")?.optJSONObject(0)?.optString("text").orEmpty()
            val toward = sign?.optJSONArray("exit_toward_elements")?.optJSONObject(0)?.optString("text").orEmpty()
            steps += Step(cum[gi], man, street, m.optString("instruction"), if (man.startsWith("ROUNDABOUT")) exits else 0, exitNo, toward)
        }
        val sum = trip.optJSONObject("summary")
        val len = (sum?.optDouble("length", 0.0) ?: 0.0) * 1000.0
        return listOf(Route(pts, cum, steps, if (len > 0) len else cum.last(), sum?.optDouble("time", 0.0) ?: 0.0, 0.0))
    }
}
