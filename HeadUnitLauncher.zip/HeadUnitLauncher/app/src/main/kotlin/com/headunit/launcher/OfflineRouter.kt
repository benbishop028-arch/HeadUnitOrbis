package com.headunit.launcher

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Offline routing, stage 1: gets a region's routing data onto the device, starts the Valhalla engine on it and reports what happened.
 * The engine is driven by reflection for now, so this stays safe to build while its exact classes are confirmed on the real device.
 */
object OfflineRouter {
    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "offline").also { it.mkdirs() }

    fun installed(ctx: Context): Boolean =
        File(dir(ctx), "tiles.tar").let { it.exists() && it.length() > 100_000 } && File(dir(ctx), "valhalla.json").exists()

    /** Downloads valhalla.json, admins.sqlite and tiles.tar from [baseUrl] (for example a GitHub release's download folder). */
    fun download(ctx: Context, baseUrl: String, progress: (String) -> Unit) {
        val base = baseUrl.trim().trimEnd('/')
        for (name in listOf("valhalla.json", "admins.sqlite", "tiles.tar")) {
            progress("Downloading $name…")
            val c = URL("$base/$name").openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = true
            if (c.responseCode !in 200..299) throw java.io.IOException("$name: HTTP ${c.responseCode}")
            val tmp = File(dir(ctx), "$name.part")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val dst = File(dir(ctx), name)
            dst.delete(); tmp.renameTo(dst)
        }
    }

    /** The build machine's valhalla.json points at its own folders: rewrite those paths for this device. */
    private fun deviceConfig(ctx: Context): String {
        val d = dir(ctx)
        val j = JSONObject(File(d, "valhalla.json").readText())
        val m = j.getJSONObject("mjolnir")
        m.put("tile_extract", File(d, "tiles.tar").absolutePath)
        m.put("tile_dir", File(d, "tiles").absolutePath)
        m.put("admin", File(d, "admins.sqlite").absolutePath)
        m.remove("timezone")
        val out = File(d, "valhalla_device.json")
        out.writeText(j.toString())
        return out.absolutePath
    }

    private fun sig(m: java.lang.reflect.Method) =
        m.name + m.parameterTypes.joinToString(", ", "(", ")") { it.simpleName } + ": " + m.returnType.simpleName

    /** Starts the engine on the downloaded pack, asks it for a short route and returns a plain-text report of everything it found. */
    fun diagnose(ctx: Context, from: LL, to: LL): String {
        val sb = StringBuilder()
        sb.appendLine("Pack folder: ${dir(ctx)}")
        sb.appendLine(if (installed(ctx)) "Pack files: found (tiles.tar ${"%.0f".format(File(dir(ctx), "tiles.tar").length() / 1048576.0)} MB)" else "Pack files: NOT found (need tiles.tar and valhalla.json)")
        // which engine classes are in the app
        try {
            val names = ArrayList<String>()
            @Suppress("DEPRECATION")
            val df = dalvik.system.DexFile(ctx.packageCodePath)
            val en = df.entries()
            while (en.hasMoreElements()) {
                val n = en.nextElement()
                if (n.startsWith("com.valhalla") || n.startsWith("io.github.rallista")) names += n
            }
            sb.appendLine("Engine classes in the app: ${names.size}")
            names.filter { !it.contains('$') }.sorted().take(120).forEach { sb.appendLine("  $it") }
        } catch (e: Throwable) { sb.appendLine("Could not list classes: ${e.javaClass.simpleName} ${e.message}") }
        val cls = try { Class.forName("com.valhalla.valhalla.Valhalla") } catch (e: Throwable) {
            sb.appendLine("Engine class not found: ${e.javaClass.simpleName} ${e.message}"); return sb.toString()
        }
        sb.appendLine("Valhalla constructors:")
        cls.constructors.forEach { sb.appendLine("  $it") }
        sb.appendLine("Valhalla methods:")
        cls.methods.filter { it.declaringClass == cls }.forEach { sb.appendLine("  ${sig(it)}") }
        if (!installed(ctx)) return sb.toString()
        try {
            val cfg = deviceConfig(ctx)
            val ctor = cls.constructors.firstOrNull { it.parameterTypes.size == 1 && it.parameterTypes[0] == String::class.java }
            if (ctor == null) { sb.appendLine("No (String) constructor: need the other form"); return sb.toString() }
            val t0 = System.currentTimeMillis()
            val engine = ctor.newInstance(cfg)
            sb.appendLine("Engine started in ${System.currentTimeMillis() - t0} ms")
            try {
                val req = """{"locations":[{"lat":${from.lat},"lon":${from.lon}},{"lat":${to.lat},"lon":${to.lon}}],"costing":"auto"}"""
                val routeM = cls.methods.firstOrNull { it.name == "route" && it.parameterTypes.size == 1 }
                if (routeM == null) sb.appendLine("No route(request) method found")
                else {
                    val reqType = routeM.parameterTypes[0]
                    sb.appendLine("route() takes ${reqType.name}")
                    // build the typed request from JSON with Moshi, which the engine already depends on
                    val builderC = Class.forName("com.squareup.moshi.Moshi\$Builder")
                    val b = builderC.getDeclaredConstructor().newInstance()
                    val fac = Class.forName("com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory").getDeclaredConstructor().newInstance()
                    builderC.getMethod("add", Class.forName("com.squareup.moshi.JsonAdapter\$Factory")).invoke(b, fac)
                    val moshi = builderC.getMethod("build").invoke(b)
                    val adapter = moshi.javaClass.getMethod("adapter", Class::class.java).invoke(moshi, reqType)
                    val typed = adapter.javaClass.getMethod("fromJson", String::class.java).invoke(adapter, req)
                    val t1 = System.currentTimeMillis()
                    val resp = routeM.invoke(engine, typed)
                    sb.appendLine("Route answered in ${System.currentTimeMillis() - t1} ms")
                    sb.appendLine("Response type: ${resp?.javaClass?.name}")
                    sb.appendLine((resp?.toString() ?: "null").take(700))
                }
            } catch (e: Throwable) {
                val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
                sb.appendLine("Route test failed: ${c.javaClass.simpleName}: ${c.message}")
            }
            (engine as? java.io.Closeable)?.close()
        } catch (e: Throwable) {
            val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
            sb.appendLine("Engine failed: ${c.javaClass.simpleName}: ${c.message}")
        }
        return sb.toString()
    }
}
