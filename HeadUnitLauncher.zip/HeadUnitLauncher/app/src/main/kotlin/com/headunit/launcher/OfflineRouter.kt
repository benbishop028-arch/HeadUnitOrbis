package com.headunit.launcher

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Offline routing, stage 1: gets a region's routing data onto the device, starts the Valhalla engine on it and reports what happened.
 * The engine is driven by reflection for now, so this stays safe to build while its exact classes are confirmed on the real device.
 */
object OfflineRouter {
    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "offline").also { it.mkdirs() }

    fun installed(ctx: Context): Boolean =
        File(dir(ctx), "tiles.tar").let { it.exists() && it.length() > 100_000 } && File(dir(ctx), "valhalla.json").exists()

    /** Fetches one file of the pack. Returns false if the server does not have it. A file already here with the same size is kept, so an interrupted download can be repeated cheaply. */
    private fun fetch(ctx: Context, base: String, name: String, progress: (String) -> Unit): Boolean {
        val c = URL("$base/$name").openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = true
        if (c.responseCode !in 200..299) { c.disconnect(); return false }
        val total = c.contentLengthLong
        val dst = File(dir(ctx), name)
        if (total > 0 && dst.exists() && dst.length() == total) { c.disconnect(); progress("Already have $name"); return true }
        progress("Downloading $name…")
        val tmp = File(dir(ctx), "$name.part")
        c.inputStream.use { i ->
            tmp.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                var done = 0L; var lastMb = -1L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val mb = done / 8_000_000
                    if (mb != lastMb) { lastMb = mb; progress("Downloading $name… ${done / 1_048_576} MB" + if (total > 0) " of ${total / 1_048_576} MB" else "") }
                }
            }
        }
        dst.delete(); tmp.renameTo(dst)
        return true
    }

    /** A file that is either whole on the server or (when too big for one release file) in parts name.part00, .part01 … that are joined here. */
    private fun fetchJoined(ctx: Context, base: String, name: String, progress: (String) -> Unit): Boolean {
        if (fetch(ctx, base, name, progress)) return true
        var n = 0
        while (fetch(ctx, base, "$name.part%02d".format(n), progress)) n++
        if (n == 0) return false
        progress("Joining $name…")
        val joined = File(dir(ctx), "$name.joining")
        joined.outputStream().use { o ->
            for (i in 0 until n) {
                val part = File(dir(ctx), "$name.part%02d".format(i))
                part.inputStream().use { it.copyTo(o) }
                part.delete()
            }
        }
        val dst = File(dir(ctx), name)
        dst.delete(); joined.renameTo(dst)
        return true
    }

    /** Downloads the pack's files from [baseUrl] (for example a GitHub release's download folder). The map, fonts and search list are optional. */
    fun download(ctx: Context, baseUrl: String, progress: (String) -> Unit) {
        val base = baseUrl.trim().trimEnd('/')
        for (name in listOf("valhalla.json", "admins.sqlite")) if (!fetch(ctx, base, name, progress)) throw java.io.IOException("$name not found at that address")
        if (!fetchJoined(ctx, base, "tiles.tar", progress)) throw java.io.IOException("tiles.tar not found at that address")
        if (!fetchJoined(ctx, base, "places.tsv", progress)) progress("No places.tsv: streets and shops will not be searchable offline")
        if (fetchJoined(ctx, base, "fonts.zip", progress)) OfflineMap.unpackFonts(ctx, File(dir(ctx), "fonts.zip"))
        if (!fetchJoined(ctx, base, "map.pmtiles", progress)) progress("No map.pmtiles in this pack")
        progress("Download finished")
    }

    /** The build machine's valhalla.json points at its own folders: rewrite those paths for this device. */
    private fun deviceConfig(ctx: Context): String {
        val d = dir(ctx)
        val j = JSONObject(File(d, "valhalla.json").readText())
        val m = j.getJSONObject("mjolnir")
        m.put("tile_extract", File(d, "tiles.tar").absolutePath)
        m.put("tile_dir", File(d, "tiles").absolutePath)
        m.put("admin", File(d, "admins.sqlite").absolutePath)
        m.remove("timezone")
        val out = File(d, "valhalla_device.json")
        out.writeText(j.toString())
        return out.absolutePath
    }

    private fun sig(m: java.lang.reflect.Method) =
        m.name + m.parameterTypes.joinToString(", ", "(", ")") { it.simpleName } + ": " + m.returnType.simpleName

    /** Starts the engine on the downloaded pack, asks it for a short route and returns a plain-text report of everything it found. */
    fun diagnose(ctx: Context, from: LL, to: LL): String {
        val sb = StringBuilder()
        sb.appendLine("Pack folder: ${dir(ctx)}")
        sb.appendLine(if (installed(ctx)) "Pack files: found (tiles.tar ${"%.0f".format(File(dir(ctx), "tiles.tar").length() / 1048576.0)} MB)" else "Pack files: NOT found (need tiles.tar and valhalla.json)")
        // which engine classes are in the app
        try {
            val names = ArrayList<String>()
            @Suppress("DEPRECATION")
            val df = dalvik.system.DexFile(ctx.packageCodePath)
            val en = df.entries()
            while (en.hasMoreElements()) {
                val n = en.nextElement()
                if (n.startsWith("com.valhalla") || n.startsWith("io.github.rallista")) names += n
            }
            sb.appendLine("Engine classes in the app: ${names.size}")
            names.filter { !it.contains('$') }.sorted().take(120).forEach { sb.appendLine("  $it") }
        } catch (e: Throwable) { sb.appendLine("Could not list classes: ${e.javaClass.simpleName} ${e.message}") }
        val cls = try { Class.forName("com.valhalla.valhalla.Valhalla") } catch (e: Throwable) {
            sb.appendLine("Engine class not found: ${e.javaClass.simpleName} ${e.message}"); return sb.toString()
        }
        sb.appendLine("Valhalla constructors:")
        cls.constructors.forEach { sb.appendLine("  $it") }
        sb.appendLine("Valhalla methods:")
        cls.methods.filter { it.declaringClass == cls }.forEach { sb.appendLine("  ${sig(it)}") }
        if (!installed(ctx)) return sb.toString()
        try {
            val cfg = deviceConfig(ctx)
            val ctor = cls.constructors.firstOrNull { it.parameterTypes.size == 1 && it.parameterTypes[0] == String::class.java }
            if (ctor == null) { sb.appendLine("No (String) constructor: need the other form"); return sb.toString() }
            val t0 = System.currentTimeMillis()
            val engine = ctor.newInstance(cfg)
            sb.appendLine("Engine started in ${System.currentTimeMillis() - t0} ms")
            try {
                val req = """{"locations":[{"lat":${from.lat},"lon":${from.lon}},{"lat":${to.lat},"lon":${to.lon}}],"costing":"auto"}"""
                val routeM = cls.methods.firstOrNull { it.name == "route" && it.parameterTypes.size == 1 }
                if (routeM == null) sb.appendLine("No route(request) method found")
                else {
                    val reqType = routeM.parameterTypes[0]
                    sb.appendLine("route() takes ${reqType.name}")
                    // build the typed request from JSON with Moshi, which the engine already depends on
                    val builderC = Class.forName("com.squareup.moshi.Moshi\$Builder")
                    val b = builderC.getDeclaredConstructor().newInstance()
                    val fac = Class.forName("com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory").getDeclaredConstructor().newInstance()
                    builderC.getMethod("add", Class.forName("com.squareup.moshi.JsonAdapter\$Factory")).invoke(b, fac)
                    val moshi = builderC.getMethod("build").invoke(b)
                    val adapter = moshi.javaClass.getMethod("adapter", Class::class.java).invoke(moshi, reqType)
                    val typed = adapter.javaClass.getMethod("fromJson", String::class.java).invoke(adapter, req)
                    val t1 = System.currentTimeMillis()
                    val resp = routeM.invoke(engine, typed)
                    sb.appendLine("Route answered in ${System.currentTimeMillis() - t1} ms")
                    sb.appendLine("Response type: ${resp?.javaClass?.name}")
                    sb.appendLine((resp?.toString() ?: "null").take(700))
                }
            } catch (e: Throwable) {
                val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
                sb.appendLine("Route test failed: ${c.javaClass.simpleName}: ${c.message}")
            }
            (engine as? java.io.Closeable)?.close()
        } catch (e: Throwable) {
            val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
            sb.appendLine("Engine failed: ${c.javaClass.simpleName}: ${c.message}")
        }
        return sb.toString()
    }


    // ---- offline search over the pack's own streets, shops and places ----
    fun hasPlaces(ctx: Context): Boolean = File(dir(ctx), "places.tsv").let { it.exists() && it.length() > 1000 }

    private fun lowerB(b: Byte): Byte = if (b in 65..90) (b + 32).toByte() else b

    /** True when every word in [toks] (lower case, UTF-8 bytes) appears in buf[from, to). */
    private fun lineMatches(buf: ByteArray, from: Int, to: Int, toks: List<ByteArray>): Boolean {
        for (t in toks) {
            var found = false
            var i = from
            val last = to - t.size
            while (i <= last) {
                var k = 0
                while (k < t.size && lowerB(buf[i + k]) == t[k]) k++
                if (k == t.size) { found = true; break }
                i++
            }
            if (!found) return false
        }
        return true
    }

    private class Hit(val score: Double, val place: Place)

    /**
     * Every word you typed must appear in the name. Names starting with it come first, then the closest.
     * The list is big (hundreds of thousands of lines for all of England and Wales), so it is read in chunks and never held in memory.
     */
    fun searchPlaces(ctx: Context, q: String, near: LL?): List<Place> {
        val toks = q.lowercase().split(' ', ',').filter { it.isNotBlank() }.map { it.toByteArray(Charsets.UTF_8) }
        if (toks.isEmpty()) return emptyList()
        val f = File(dir(ctx), "places.tsv")
        if (!f.exists()) return emptyList()
        val top = ArrayList<Hit>()
        try {
            f.inputStream().use { ins ->
                val buf = ByteArray(1 shl 20)
                var have = 0
                val tab = '\t'.code.toByte(); val nl = '\n'.code.toByte()
                while (true) {
                    val r = ins.read(buf, have, buf.size - have)
                    val end = if (r < 0) have else have + r
                    var i = 0
                    while (i < end) {
                        var e = i
                        while (e < end && buf[e] != nl) e++
                        if (e >= end && r >= 0) break // incomplete last line: finish it after the next read
                        var t = i
                        while (t < e && buf[t] != tab) t++
                        if (t < e && lineMatches(buf, i, t, toks)) {
                            val p = String(buf, i, e - i, Charsets.UTF_8).split('\t')
                            val la = p.getOrNull(2)?.toDoubleOrNull(); val lo = p.getOrNull(3)?.toDoubleOrNull()
                            if (la != null && lo != null) {
                                val pos = LL(la, lo)
                                val starts = if (t - i >= toks[0].size && (0 until toks[0].size).all { k -> lowerB(buf[i + k]) == toks[0][k] }) 0.0 else 1.0
                                val far = if (near != null) minOf(Geo.dist(near, pos) / 1000.0, 999.0) else 0.0
                                val score = starts * 1e6 + far
                                if (top.size < 8 || score < top.last().score) {
                                    top += Hit(score, Place(p[0], p[1] + " · offline", pos))
                                    top.sortBy { it.score }
                                    if (top.size > 8) top.removeAt(top.size - 1)
                                }
                            }
                        }
                        i = e + 1
                    }
                    if (r < 0) break
                    // keep the unfinished last line at the front of the buffer
                    val keep = if (i < end) end - i else 0
                    if (keep > 0) System.arraycopy(buf, i, buf, 0, keep)
                    have = keep
                    if (have >= buf.size) have = 0 // a line longer than the buffer cannot be real: drop it
                }
            }
        } catch (e: Throwable) { }
        return top.map { it.place }
    }

    // ---- real routing (stage 2) ----
    private var engine: com.valhalla.valhalla.Valhalla? = null
    private var engineStamp = 0L

    /** One engine, kept open and reused. It is rebuilt only if the pack file changes. */
    @Synchronized
    private fun engine(ctx: Context): com.valhalla.valhalla.Valhalla {
        val stamp = File(dir(ctx), "tiles.tar").lastModified()
        val cur = engine
        if (cur != null && stamp == engineStamp) return cur
        try { cur?.close() } catch (e: Exception) { }
        val e = com.valhalla.valhalla.Valhalla(deviceConfig(ctx))
        engine = e; engineStamp = stamp
        return e
    }

    private fun decode6(s: String): List<LL> {
        val out = ArrayList<LL>()
        var i = 0; var lat = 0; var lon = 0
        while (i < s.length) {
            var sh = 0; var r = 0; var b: Int
            do { b = s[i++].code - 63; r = r or ((b and 31) shl sh); sh += 5 } while (b >= 32)
            lat += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            sh = 0; r = 0
            do { b = s[i++].code - 63; r = r or ((b and 31) shl sh); sh += 5 } while (b >= 32)
            lon += if (r and 1 != 0) (r shr 1).inv() else r shr 1
            out += LL(lat / 1e6, lon / 1e6)
        }
        return out
    }

    private fun manText(type: Int, exits: Int): String? = when (type) {
        1, 2, 3 -> "DEPART"
        4 -> "ARRIVE"; 5 -> "ARRIVE_RIGHT"; 6 -> "ARRIVE_LEFT"
        7, 8 -> "FOLLOW"
        9 -> "BEAR_RIGHT"; 10 -> "TURN_RIGHT"; 11 -> "SHARP_RIGHT"
        12, 13 -> "MAKE_UTURN"
        14 -> "SHARP_LEFT"; 15 -> "TURN_LEFT"; 16 -> "BEAR_LEFT"
        17, 22 -> "STRAIGHT"
        18, 20 -> "MOTORWAY_EXIT_RIGHT"; 19, 21 -> "MOTORWAY_EXIT_LEFT"
        23 -> "KEEP_RIGHT"; 24 -> "KEEP_LEFT"
        25, 37, 38 -> "FOLLOW"
        26 -> when { exits <= 1 -> "ROUNDABOUT_LEFT"; exits == 2 -> "ROUNDABOUT_CROSS"; exits == 3 -> "ROUNDABOUT_RIGHT"; else -> "ROUNDABOUT_BACK" }
        28 -> "TAKE_FERRY"
        else -> null // 0 none and 27 roundabout exit (the roundabout step already says which exit)
    }

    /** Routes on the device with no network. Blocking: call it off the main thread. */
    fun routes(ctx: Context, from: LL, to: LL, via: List<LL> = emptyList(), headingDeg: Double = -1.0): List<Route> {
        if (!installed(ctx)) throw IllegalStateException("No offline pack installed")
        val locs = org.json.JSONArray()
        locs.put(JSONObject().put("lat", from.lat).put("lon", from.lon).apply { if (headingDeg >= 0) { put("heading", headingDeg.toInt()); put("heading_tolerance", 60) } })
        for (v in via) locs.put(JSONObject().put("lat", v.lat).put("lon", v.lon).put("type", "through"))
        locs.put(JSONObject().put("lat", to.lat).put("lon", to.lon))
        val req = JSONObject().put("locations", locs).put("costing", "auto")
            .put("directions_options", JSONObject().put("units", "kilometers").put("language", "en-GB"))
        val raw = engine(ctx).routeRaw(req.toString())
        val o = JSONObject(raw)
        if (o.has("error") && !o.has("trip")) throw IllegalStateException("No offline route here (${o.optString("error")}). Is it inside the downloaded area?")
        val trip = o.getJSONObject("trip")
        val legs = trip.getJSONArray("legs")
        val pts = ArrayList<LL>()
        data class M(val base: Int, val m: JSONObject)
        val mans = ArrayList<M>()
        for (li in 0 until legs.length()) {
            val leg = legs.getJSONObject(li)
            val shape = decode6(leg.getString("shape"))
            val base = if (pts.isEmpty()) 0 else pts.size - 1
            if (pts.isEmpty()) pts.addAll(shape) else pts.addAll(shape.drop(1))
            val ms = leg.optJSONArray("maneuvers")
            if (ms != null) for (i in 0 until ms.length()) mans += M(base, ms.getJSONObject(i))
        }
        if (pts.size < 2) throw IllegalStateException("No offline route found")
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + Geo.dist(pts[i - 1], pts[i])
        val steps = ArrayList<Step>()
        for ((base, m) in mans) {
            val exits = m.optInt("roundabout_exit_count", 0)
            val man = manText(m.optInt("type", 0), exits) ?: continue
            val gi = (base + m.optInt("begin_shape_index", 0)).coerceIn(0, pts.size - 1)
            val names = m.optJSONArray("street_names")
            val street = if (names != null && names.length() > 0) names.optString(0) else ""
            val sign = m.optJSONObject("sign")
            val exitNo = sign?.optJSONArray("exit_number_elements")?.optJSONObject(0)?.optString("text").orEmpty()
            val toward = sign?.optJSONArray("exit_toward_elements")?.optJSONObject(0)?.optString("text").orEmpty()
            steps += Step(cum[gi], man, street, m.optString("instruction"), if (man.startsWith("ROUNDABOUT")) exits else 0, exitNo, toward)
        }
        val sum = trip.optJSONObject("summary")
        val len = (sum?.optDouble("length", 0.0) ?: 0.0) * 1000.0
        return listOf(Route(pts, cum, steps, if (len > 0) len else cum.last(), sum?.optDouble("time", 0.0) ?: 0.0, 0.0))
    }
}
