package com.headunit.launcher.ui

import android.content.Intent
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.TextUnit
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.MediaInfo
import com.headunit.launcher.MediaSource
import com.headunit.launcher.Prefs

/** Main colour of the album art, used to tint the player the way Android Auto does. */
@Composable
internal fun rememberArtTint(m: MediaInfo?): Color? {
    val art = m?.art
    return remember(art) { art?.let { artColor(it) } }
}

@Composable
private fun rememberAppIcon(pkg: String): ImageBitmap? {
    val ctx = LocalContext.current
    return remember(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(64, 64).asImageBitmap() } catch (e: Exception) { null }
    }
}

private fun appLabel(ctx: android.content.Context, pkg: String): String = try {
    ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { "" }

/** Fades and lifts the album art in whenever the track changes. */
private fun Modifier.trackChange(key: Any): Modifier = this.composed {
    val a = androidx.compose.runtime.remember { androidx.compose.animation.core.Animatable(1f) }
    androidx.compose.runtime.LaunchedEffect(key) { a.snapTo(0f); a.animateTo(1f, androidx.compose.animation.core.tween(450)) }
    this.graphicsLayer { alpha = 0.3f + 0.7f * a.value; val sc = 0.95f + 0.05f * a.value; scaleX = sc; scaleY = sc }
}

/** Text that cross-fades and slides up when it changes (track title and artist). */
@Composable
private fun FadeText(text: String, color: Color, size: TextUnit, weight: FontWeight?, maxLines: Int) {
    androidx.compose.animation.AnimatedContent(
        targetState = text,
        transitionSpec = {
            (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260)) + androidx.compose.animation.slideInVertically { it / 4 }) togetherWith
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140))
        },
        label = "fadeText",
    ) { t -> Text(t, color = color, fontSize = size, fontWeight = weight, maxLines = maxLines, overflow = TextOverflow.Ellipsis) }
}

/** The cover blurred and dimmed behind the player (Android 12 and newer; older versions keep the plain tint). */
@Composable
private fun ArtBackdrop(art: ImageBitmap?, modifier: Modifier = Modifier) {
    if (art == null || android.os.Build.VERSION.SDK_INT < 31) return
    val c = LocalVw.current
    Box(modifier) {
        Image(art, null, Modifier.fillMaxSize().blur(48.dp).graphicsLayer { alpha = if (c.dark) 0.45f else 0.35f }, contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(c.panel.copy(alpha = 0.5f)))
    }
}

@Composable
private fun tintedBrush(tint: Color): Brush {
    val c = LocalVw.current
    return Brush.verticalGradient(listOf(lerp(c.panel, tint, if (c.dark) 0.45f else 0.30f), c.panel))
}

@Composable
private fun AppHeader(m: MediaInfo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val bt = MediaHelper.isBluetooth(m.app)
    val icon = if (bt) null else rememberAppIcon(m.app)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (bt) Icon(Icons.Rounded.Bluetooth, null, tint = c.accent, modifier = Modifier.size(22.dp))
        else if (icon != null) Image(icon, null, Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)))
        Text(if (bt) "Bluetooth audio" else if (m.app == MediaHelper.EXTERNAL) "Audio source" else appLabel(ctx, m.app), color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp).weight(1f))
        if (m.playing) Icon(Icons.Rounded.GraphicEq, null, tint = c.sub, modifier = Modifier.size(20.dp))
    }
}

/** Previous, big white play/pause, next: the Android Auto transport row. */
@Composable
private fun Transport(m: MediaInfo, playSize: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    Row(modifier, horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        TileBtn(Icons.Rounded.SkipPrevious, { m.previous() }, size = playSize * 0.85f, bg = Color.Transparent)
        Box(
            Modifier.size(playSize).clip(CircleShape).background(if (c.dark) Color.White else Color(0xFF14171C))
                .clickable { m.toggle() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = if (c.dark) Color(0xFF14171C) else Color.White, modifier = Modifier.size(playSize * 0.55f))
        }
        TileBtn(Icons.Rounded.SkipNext, { m.next() }, size = playSize * 0.85f, bg = Color.Transparent)
    }
}

@Composable
private fun Progress(m: MediaInfo, modifier: Modifier = Modifier, fill: Color? = null) {
    val c = LocalVw.current
    val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
    Column(modifier) {
        SeekBar(frac, m.dur > 0, { f -> m.seek((f * m.dur).toLong()) }, Modifier.fillMaxWidth(), fill = fill ?: c.text, track = c.text.copy(alpha = 0.2f))
        if (m.dur > 0) Row(Modifier.fillMaxWidth()) {
            Text(fmtClock(m.pos), color = c.sub, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(fmtClock(m.dur), color = c.sub, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ home screen widget
@Composable
fun MediaWidget(modifier: Modifier, onOpen: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = rememberMediaAccess()
    val tint = rememberArtTint(m) ?: c.accent
    Box(
        modifier.clip(RoundedCornerShape(24.dp)).background(tintedBrush(tint))
            .clickable(onClick = if (access) onOpen else ({ MediaHelper.openAccess(ctx) })),
    ) {
        ArtBackdrop(m?.art, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 14.dp, bottom = 10.dp), verticalArrangement = Arrangement.SpaceBetween) {
            if (m != null) AppHeader(m)
            Box(
                Modifier.weight(1f, fill = false).trackChange(m?.title ?: "").fillMaxWidth(0.8f).align(Alignment.CenterHorizontally).aspectRatio(1f)
                    .shadow(14.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)).background(c.tile),
                contentAlignment = Alignment.Center,
            ) {
                if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(64.dp))
            }
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                FadeText(m?.title ?: if (access) "Nothing playing" else "Allow media access", c.text, 22.sp, FontWeight.Bold, 1)
                FadeText(m?.artist ?: if (access) "Start music in any app" else "Tap to enable, then turn on this app", c.sub, 15.sp, null, 1)
            }
            if (m != null) {
                Progress(m)
                Transport(m, 60.dp, Modifier.fillMaxWidth())
            }
        }
    }
}

// ------------------------------------------------------------------ full music page
@Composable
fun MediaPage(apps: AppsRepo, prefs: Prefs) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = MediaHelper.hasAccess(ctx)
    val tint = rememberArtTint(m) ?: c.accent
    // highlight colour taken from the cover, nudged so it stays readable
    val accent = if (tint == c.accent) c.accent else if (c.dark) tint.lighten(0.18f) else tint.darken(0.12f)
    var tab by remember { mutableIntStateOf(0) }
    val voicePlay = rememberVoiceInput("Say a song, artist or playlist") { q ->
        val mc = m?.controller
        if (mc != null) mc.transportControls.playFromSearch(q, null)
        else try {
            ctx.startActivity(
                Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(android.app.SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) { android.widget.Toast.makeText(ctx, "Start a music app first", android.widget.Toast.LENGTH_SHORT).show() }
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        // now playing
        Box(Modifier.weight(1.4f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).background(tintedBrush(tint))) {
            if (!access) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Allow notification access to show what is playing and use the controls.", color = c.text, fontSize = 16.sp, textAlign = TextAlign.Center)
                    Pill("Open access settings", true, { Launch.settings(ctx, android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, Modifier.padding(top = 14.dp))
                }
            } else if (m == null) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(72.dp))
                    Text("Nothing playing", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Text("Start a music app from Sources.", color = c.sub, fontSize = 15.sp)
                }
            } else {
                ArtBackdrop(m.art, Modifier.fillMaxSize())
                BoxWithConstraints(Modifier.fillMaxSize().padding(22.dp)) {
                    // the art takes at most 42% of the width so the controls beside it never get squeezed
                    val artSize = minOf(maxHeight - 78.dp, maxWidth * 0.42f).coerceAtLeast(120.dp)
                    Column(Modifier.fillMaxSize()) {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(26.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.trackChange(m.title).size(artSize).shadow(18.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.tile),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (m.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(72.dp))
                            }
                            Column(Modifier.weight(1f).height(artSize), verticalArrangement = Arrangement.SpaceBetween) {
                                AppHeader(m)
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FadeText(m.title, c.text, 28.sp, FontWeight.Bold, 2)
                                    FadeText(m.artist, c.sub, 18.sp, null, 1)
                                }
                                Column {
                                    Progress(m, fill = accent)
                                    Transport(m, 68.dp, Modifier.fillMaxWidth().padding(top = 12.dp))
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            TileBtn(Icons.Rounded.VolumeDown, { Launch.volume(ctx, false) }, size = 46.dp, bg = c.text.copy(alpha = 0.10f))
                            TileBtn(Icons.Rounded.VolumeUp, { Launch.volume(ctx, true) }, size = 46.dp, bg = c.text.copy(alpha = 0.10f))
                            Spacer(Modifier.weight(1f))
                            Pill("Voice play", false, { voicePlay() })
                        }
                    }
                }
            }
        }
        // up next / sources
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Up next", tab == 0, { tab = 0 }, selectedColor = accent)
                    Pill("Sources", tab == 1, { tab = 1 }, selectedColor = accent)
                }
                if (tab == 0) {
                    val queue = try { m?.controller?.queue.orEmpty() } catch (e: Exception) { emptyList() }
                    val activeId = try { m?.controller?.playbackState?.activeQueueItemId ?: -1L } catch (e: Exception) { -1L }
                    if (queue.isEmpty()) {
                        Text(
                            if (m == null) "Nothing is playing." else "This app does not share its play queue. Use Sources to open it.",
                            color = c.sub, fontSize = 14.sp,
                        )
                    } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(queue.size) { i ->
                            val q = queue[i]
                            val now = q.queueId == activeId
                            Row(
                                Modifier.fillMaxWidth().inset(14.dp, if (now) accent else null)
                                    .clickable { m?.controller?.transportControls?.skipToQueueItem(q.queueId) }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                IconBadge(if (now) Icons.Rounded.GraphicEq else Icons.Rounded.MusicNote, if (now) accent else c.sub, size = 36.dp)
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text(q.description.title?.toString() ?: "Track", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    val sub = q.description.subtitle?.toString()
                                    if (!sub.isNullOrBlank()) Text(sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                } else {
                    val music = apps.musicApps()
                    val srcs by produceState(emptyList<MediaSource>(), ctx) { while (true) { value = MediaHelper.sources(ctx); kotlinx.coroutines.delay(1500) } }
                    val pref = prefs.s("mediasrc", "")
                    val bt = srcs.firstOrNull { it.bluetooth }
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SourceRow(Icons.Rounded.GraphicEq, "Automatic", "Shows whatever is playing", pref.isEmpty(), accent) { prefs.put("mediasrc", "") }
                        SourceRow(
                            Icons.Rounded.Bluetooth, "Bluetooth audio",
                            when {
                                bt == null -> "No Bluetooth player found. Tap to open Bluetooth settings"
                                bt.playing -> "Playing from your phone"
                                else -> "Phone connected. Press play on it"
                            },
                            bt != null && pref == bt.pkg, accent,
                        ) { if (bt != null) prefs.put("mediasrc", bt.pkg) else Launch.settings(ctx, android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) }
                        srcs.filter { !it.bluetooth }.forEach { sr ->
                            SourceRow(Icons.Rounded.MusicNote, sr.label, (if (sr.playing) "Playing · " else "") + sr.pkg, pref == sr.pkg, accent) { prefs.put("mediasrc", sr.pkg) }
                        }
                        if (music.isNotEmpty()) SectionLabel("Open an app", Modifier.padding(top = 6.dp))
                        music.chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth()) {
                                row.forEach { a -> Box(Modifier.weight(1f)) { AppTile(a, Modifier.padding(4.dp).inset(16.dp)) { Launch.app(ctx, a.pkg) } } }
                                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val c = LocalVw.current
    Row(
        Modifier.fillMaxWidth().inset(14.dp, if (selected) accent else null).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(icon, if (selected) accent else c.sub, size = 38.dp)
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
