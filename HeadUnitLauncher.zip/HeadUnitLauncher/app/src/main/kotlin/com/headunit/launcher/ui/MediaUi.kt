package com.headunit.launcher.ui

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.MediaInfo

/** Main colour of the album art, used to tint the player the way Android Auto does. */
@Composable
internal fun rememberArtTint(m: MediaInfo?): Color? {
    val art = m?.art
    return remember(art) { art?.let { artColor(it) } }
}

@Composable
private fun rememberAppIcon(pkg: String): ImageBitmap? {
    val ctx = LocalContext.current
    return remember(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(64, 64).asImageBitmap() } catch (e: Exception) { null }
    }
}

private fun appLabel(ctx: android.content.Context, pkg: String): String = try {
    ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { "" }

@Composable
private fun tintedBrush(tint: Color): Brush {
    val c = LocalVw.current
    return Brush.verticalGradient(listOf(lerp(c.panel, tint, if (c.dark) 0.45f else 0.30f), c.panel))
}

@Composable
private fun AppHeader(m: MediaInfo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val icon = rememberAppIcon(m.app)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Image(icon, null, Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)))
        Text(appLabel(ctx, m.app), color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp).weight(1f))
        if (m.playing) Icon(Icons.Rounded.GraphicEq, null, tint = c.sub, modifier = Modifier.size(20.dp))
    }
}

/** Previous, big white play/pause, next: the Android Auto transport row. */
@Composable
private fun Transport(m: MediaInfo, playSize: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    Row(modifier, horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        TileBtn(Icons.Rounded.SkipPrevious, { m.controller.transportControls.skipToPrevious() }, size = playSize * 0.78f, bg = Color.Transparent)
        Box(
            Modifier.size(playSize).clip(CircleShape).background(if (c.dark) Color.White else Color(0xFF14171C))
                .clickable { if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = if (c.dark) Color(0xFF14171C) else Color.White, modifier = Modifier.size(playSize * 0.55f))
        }
        TileBtn(Icons.Rounded.SkipNext, { m.controller.transportControls.skipToNext() }, size = playSize * 0.78f, bg = Color.Transparent)
    }
}

@Composable
private fun Progress(m: MediaInfo, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
    Column(modifier) {
        SeekBar(frac, m.dur > 0, { f -> m.controller.transportControls.seekTo((f * m.dur).toLong()) }, Modifier.fillMaxWidth(), fill = c.text, track = c.text.copy(alpha = 0.2f))
        if (m.dur > 0) Row(Modifier.fillMaxWidth()) {
            Text(fmtClock(m.pos), color = c.sub, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(fmtClock(m.dur), color = c.sub, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ home screen widget
@Composable
fun MediaWidget(modifier: Modifier, onOpen: () -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = rememberMediaAccess()
    val tint = rememberArtTint(m) ?: c.accent
    Box(
        modifier.clip(RoundedCornerShape(24.dp)).background(tintedBrush(tint))
            .clickable(onClick = if (access) onOpen else ({ MediaHelper.openAccess(ctx) })),
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 14.dp, bottom = 10.dp), verticalArrangement = Arrangement.SpaceBetween) {
            if (m != null) AppHeader(m)
            Box(
                Modifier.weight(1f, fill = false).fillMaxWidth(0.8f).align(Alignment.CenterHorizontally).aspectRatio(1f)
                    .shadow(14.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)).background(c.tile),
                contentAlignment = Alignment.Center,
            ) {
                if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(64.dp))
            }
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(m?.title ?: if (access) "Nothing playing" else "Allow media access", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m?.artist ?: if (access) "Start music in any app" else "Tap to enable, then turn on this app", color = c.sub, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (m != null) {
                Progress(m)
                Transport(m, 60.dp, Modifier.fillMaxWidth())
            }
        }
    }
}

// ------------------------------------------------------------------ full music page
@Composable
fun MediaPage(apps: AppsRepo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = MediaHelper.hasAccess(ctx)
    val tint = rememberArtTint(m) ?: c.accent
    var tab by remember { mutableIntStateOf(0) }
    val voicePlay = rememberVoiceInput("Say a song, artist or playlist") { q ->
        val mc = m?.controller
        if (mc != null) mc.transportControls.playFromSearch(q, null)
        else try {
            ctx.startActivity(
                Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(android.app.SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) { android.widget.Toast.makeText(ctx, "Start a music app first", android.widget.Toast.LENGTH_SHORT).show() }
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        // now playing
        Box(Modifier.weight(1.4f).fillMaxHeight().clip(RoundedCornerShape(24.dp)).background(tintedBrush(tint))) {
            if (!access) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Allow notification access to show what is playing and use the controls.", color = c.text, fontSize = 16.sp, textAlign = TextAlign.Center)
                    Pill("Open access settings", true, { Launch.settings(ctx, android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, Modifier.padding(top = 14.dp))
                }
            } else if (m == null) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(72.dp))
                    Text("Nothing playing", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Text("Start a music app from Sources.", color = c.sub, fontSize = 15.sp)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(22.dp)) {
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true)
                                .shadow(18.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(c.tile),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (m.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(72.dp))
                        }
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                            AppHeader(m)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(m.title, color = c.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(m.artist, color = c.sub, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Column {
                                Progress(m)
                                Transport(m, 72.dp, Modifier.fillMaxWidth().padding(top = 10.dp))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TileBtn(Icons.Rounded.VolumeDown, { Launch.volume(ctx, false) }, size = 46.dp, bg = c.text.copy(alpha = 0.10f))
                        TileBtn(Icons.Rounded.VolumeUp, { Launch.volume(ctx, true) }, size = 46.dp, bg = c.text.copy(alpha = 0.10f))
                        Spacer(Modifier.weight(1f))
                        Pill("Voice play", false, { voicePlay() })
                    }
                }
            }
        }
        // up next / sources
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Up next", tab == 0, { tab = 0 })
                    Pill("Sources", tab == 1, { tab = 1 })
                }
                if (tab == 0) {
                    val queue = try { m?.controller?.queue.orEmpty() } catch (e: Exception) { emptyList() }
                    val activeId = try { m?.controller?.playbackState?.activeQueueItemId ?: -1L } catch (e: Exception) { -1L }
                    if (queue.isEmpty()) {
                        Text(
                            if (m == null) "Nothing is playing." else "This app does not share its play queue. Use Sources to open it.",
                            color = c.sub, fontSize = 14.sp,
                        )
                    } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(queue.size) { i ->
                            val q = queue[i]
                            val now = q.queueId == activeId
                            Row(
                                Modifier.fillMaxWidth().inset(14.dp, if (now) c.accent else null)
                                    .clickable { m?.controller?.transportControls?.skipToQueueItem(q.queueId) }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                IconBadge(if (now) Icons.Rounded.GraphicEq else Icons.Rounded.MusicNote, if (now) c.accent else c.sub, size = 36.dp)
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text(q.description.title?.toString() ?: "Track", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    val sub = q.description.subtitle?.toString()
                                    if (!sub.isNullOrBlank()) Text(sub, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                } else {
                    val music = apps.musicApps()
                    if (music.isEmpty()) Text("No music apps found. Open the Apps page.", color = c.sub, fontSize = 14.sp)
                    LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.fillMaxSize()) {
                        items(music) { a -> AppTile(a, Modifier.padding(4.dp).inset(16.dp)) { Launch.app(ctx, a.pkg) } }
                    }
                }
            }
        }
    }
}
