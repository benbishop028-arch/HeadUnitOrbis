package com.headunit.launcher.ui

import android.graphics.Rect
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.headunit.launcher.AppEntry
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Geo
import com.headunit.launcher.Launch
import com.headunit.launcher.MapBinding
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.MediaInfo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private var autoLaunched = false

@Composable
fun HomePage(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val source = prefs.s("pip_src", "map")   // "map" or a package name
    var picker by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf<Rect?>(null) }
    val view = LocalView.current

    fun windowBounds(): Rect? {
        val b = bounds ?: return null
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)   // window origin on the screen (0,0 for a full-screen launcher)
        return Rect(b.left + loc[0], b.top + loc[1], b.right + loc[0], b.bottom + loc[1])
    }

    LaunchedEffect(source, apps.apps.size) {
        if (!autoLaunched && source != "map" && prefs.b("autoopen", false) && apps.apps.isNotEmpty()) {
            autoLaunched = true
            delay(1200)
            Launch.app(ctx, source, windowBounds())
        }
    }

    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        // ---- picture-in-picture window ----
        VCard(Modifier.weight(2.15f).fillMaxHeight()) {
            Box(Modifier.fillMaxSize().onGloballyPositioned { bounds = it.boundsInWindow().let { r -> Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()) } }) {
                if (source == "map") {
                    MapHost(map, Modifier.fillMaxSize(), cornerDp = 22)
                    val t = engine.turn
                    if (t != null) {
                        Row(
                            Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(16.dp)).background(Blue).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size(34.dp))
                            Column(Modifier.padding(start = 10.dp)) {
                                Text(Geo.fmtDist(t.dist, engine.imperial), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text(t.street, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(150.dp))
                            }
                        }
                    }
                    engine.eta?.let { e ->
                        Row(
                            Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xCC0A0D12)).padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Text(e.arrive, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(Geo.fmtDur(e.secs), color = Color.White, fontSize = 17.sp)
                            Text(Geo.fmtDist(e.dist, engine.imperial), color = Color.White, fontSize = 17.sp)
                        }
                    }
                    Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                        RoundBtn(Icons.Rounded.Fullscreen, { onOpen(Page.Nav) }, size = 46.dp)
                    }
                } else {
                    val app = apps.find(source)
                    Column(Modifier.fillMaxSize().background(c.surface2), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        if (app != null) Image(app.icon, null, Modifier.size(84.dp))
                        Text(app?.label ?: "App not installed", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Pill("Open in this window", true, {
                                if (!Launch.app(ctx, source, windowBounds())) engine.toast("Could not open that app")
                            })
                            Pill("Full screen", false, {
                                if (!Launch.app(ctx, source, null)) engine.toast("Could not open that app")
                            })
                        }
                        Text(
                            "Windowed mode needs multi-window/freeform support on this head unit; otherwise the app opens full screen.",
                            color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 30.dp, vertical = 12.dp),
                        )
                    }
                }
                // source selector
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.95f))
                        .clickable { picker = true }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(if (source == "map") "Source: Map" else "Source: " + (apps.find(source)?.label ?: "App"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        // ---- right column of widgets ----
        MediaWidget(Modifier.weight(1f).fillMaxHeight(), onOpen = { onOpen(Page.Media) })
    }

    if (picker) {
        Dialog(onDismissRequest = { picker = false }) {
            Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).padding(18.dp).height(420.dp).width(620.dp)) {
                Text("Choose what the window shows", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("Map (built-in 3D)", source == "map", { prefs.put("pip_src", "map"); picker = false })
                    Pill("Auto-open at start", prefs.b("autoopen", false), { prefs.put("autoopen", !prefs.b("autoopen", false)) })
                }
                val proj = apps.projectionApps()
                if (proj.isNotEmpty()) {
                    Text("Phone projection", color = c.sub, fontSize = 13.sp)
                    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        proj.take(4).forEach { a -> AppTile(a, Modifier.width(100.dp)) { prefs.put("pip_src", a.pkg); picker = false } }
                    }
                }
                Text("All apps", color = c.sub, fontSize = 13.sp)
                LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.fillMaxSize()) {
                    items(apps.apps) { a -> AppTile(a, Modifier) { prefs.put("pip_src", a.pkg); picker = false } }
                }
            }
        }
    }
}

@Composable
fun AppTile(a: AppEntry, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(a.icon, a.label, Modifier.size(54.dp))
        Text(a.label, color = c.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun rememberMedia(): MediaInfo? {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    LaunchedEffect(Unit) { while (true) { info = MediaHelper.current(ctx); delay(1000) } }
    return info
}

@Composable
fun MediaWidget(modifier: Modifier, onOpen: () -> Unit) {
    val c = LocalVw.current
    val m = rememberMedia()
    VCard(modifier, onClick = onOpen) {
        Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
            Box(Modifier.fillMaxWidth(0.72f).aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(c.surface2), contentAlignment = Alignment.Center) {
                if (m?.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Rounded.MusicNote, null, tint = c.sub, modifier = Modifier.size(64.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(m?.title ?: "Media", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m?.artist ?: "Tap to open Media", color = c.sub, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (m != null) {
                val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(c.line)) {
                    Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(c.accent))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(Icons.Rounded.SkipPrevious, { m.controller.transportControls.skipToPrevious() }, size = 54.dp)
                    RoundBtn(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, { if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play() }, active = true, size = 64.dp)
                    RoundBtn(Icons.Rounded.SkipNext, { m.controller.transportControls.skipToNext() }, size = 54.dp)
                }
            }
        }
    }
}
