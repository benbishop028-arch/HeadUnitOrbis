package com.headunit.launcher.ui

import android.graphics.Rect
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.lerp
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.headunit.launcher.AppEntry
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Geo
import com.headunit.launcher.Launch
import com.headunit.launcher.MapBinding
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.MediaInfo
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.widthIn
import kotlin.math.roundToInt

private var autoLaunched = false

@Composable
fun HomePage(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo, nav: Boolean, onOpen: (Page) -> Unit) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val source = prefs.s("pip_src", "map")   // "map" or a package name
    var picker by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf<Rect?>(null) }
    val view = LocalView.current

    fun windowBounds(): Rect? {
        val b = bounds ?: return null
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)   // window origin on the screen (0,0 for a full-screen launcher)
        return Rect(b.left + loc[0], b.top + loc[1], b.right + loc[0], b.bottom + loc[1])
    }

    LaunchedEffect(source, apps.apps.size) {
        if (!autoLaunched && source != "map" && prefs.b("autoopen", false) && apps.apps.isNotEmpty()) {
            autoLaunched = true
            delay(1200)
            Launch.app(ctx, source, windowBounds())
        }
    }

    val p by animateFloatAsState(if (nav) 1f else 0f, tween(480, easing = FastOutSlowInEasing), label = "stage")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val gap = 14.dp
        val homeMapW = (w - gap * 3) * (2.15f / 3.15f)
        val homeH = h - 2.dp   // same top/bottom as the full-screen map
        val homeMediaX = gap * 2 + homeMapW
        val homeMediaW = w - homeMediaX - gap
        val miniX = if (prefs.s("mini", "right") == "left") 16.dp else w - 286.dp

        val showMap = source == "map" || p > 0.5f
        Box(
            Modifier
                .offset(lerp(gap, 10.dp, p), 2.dp)
                .size(lerp(homeMapW, w - 20.dp, p), lerp(homeH, h - 2.dp, p))
                .clip(RoundedCornerShape(lerp(22.dp, 18.dp, p)))
                .background(c.surface)
                .onGloballyPositioned { bounds = it.boundsInWindow().let { r -> Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()) } },
        ) {
            if (showMap) {
                MapHost(map, Modifier.fillMaxSize(), cornerDp = 20)
                val wxCode = engine.weather?.code
                if (prefs.b("rainfx", false) && wxCode != null && (wxCode in 51..67 || wxCode in 80..82 || wxCode in 95..99)) RainOverlay(Modifier.fillMaxSize())
                if (p < 0.5f) Box(Modifier.fillMaxSize().alpha((1f - p * 2f).coerceIn(0f, 1f))) {
                    val t = engine.turn
                    if (t == null && engine.route == null && engine.quickEtas.isNotEmpty()) {
                        Row(Modifier.align(Alignment.TopStart).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            engine.quickEtas.forEach { q ->
                                Column(
                                    Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xE60A0D12))
                                        .clickable { engine.startRoute(q.place); onOpen(Page.Nav) }.padding(horizontal = 14.dp, vertical = 8.dp),
                                ) {
                                    Text(q.name, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                                    Text("${q.minutes} min", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    if (q.delayMin >= 2) Text("+${q.delayMin} traffic", color = Warn, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    if (t == null && engine.route == null && (engine.fix?.speed ?: 0.0) < 1.0) {
                        ParkedCard(engine, prefs, Modifier.align(Alignment.BottomStart).padding(10.dp))
                    }
                    if (t != null) {
                        val grow by animateFloatAsState(((450.0 - t.dist) / 450.0).coerceIn(0.0, 1.0).toFloat(), tween(500), label = "turnGrow")
                        Row(
                            Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(16.dp)).background(Blue).padding((10 + 2 * grow).dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ManeuverArrow(t.maneuver, Geo.maneuverAngle(t.maneuver), Modifier.size((30 + 10 * grow).dp))
                            Column(Modifier.padding(start = 10.dp)) {
                                RollText(Geo.fmtDist(t.dist, engine.imperial), Color.White, (20 + 6 * grow).sp, fontWeight = FontWeight.Bold)
                                Text(t.street, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(150.dp))
                                val extra = listOfNotNull(t.tag.takeIf { it.isNotBlank() }, t.laneAdvice).joinToString(" · ")
                                if (extra.isNotBlank()) Text(extra, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, modifier = Modifier.width(150.dp))
                            }
                        }
                    }
                    engine.eta?.let { e ->
                        val dc = if (e.delayMin >= 10) Bad else if (e.delayMin >= 1) Warn else Good
                        Column(
                            Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xE60F141B))
                                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 8.dp),
                        ) {
                            Text(Geo.fmtDur(e.secs), color = dc, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("${e.arrive} · ${Geo.fmtDist(e.dist, engine.imperial)}", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                        }
                    }
                    Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                        RoundBtn(Icons.Rounded.Fullscreen, { onOpen(Page.Nav) }, size = 46.dp)
                    }
                    Row(
                        Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.95f))
                            .clickable { picker = true }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(if (source == "map") "Source: Map" else "Source: " + (apps.find(source)?.label ?: "App"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                if (p > 0.5f) Box(Modifier.fillMaxSize().alpha(((p - 0.5f) * 2f).coerceIn(0f, 1f))) { NavOverlays(engine) }
            } else {
                val app = apps.find(source)
                Column(Modifier.fillMaxSize().background(c.surface2), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    if (app != null) Image(app.icon, null, Modifier.size(84.dp))
                    Text(app?.label ?: "App not installed", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Open in this window", true, {
                            if (!Launch.app(ctx, source, windowBounds())) engine.toast("Could not open that app")
                        })
                        Pill("Full screen", false, {
                            if (!Launch.app(ctx, source, null)) engine.toast("Could not open that app")
                        })
                        Pill("Source", false, { picker = true })
                    }
                    Text(
                        "Windowed mode needs multi-window/freeform support on this head unit; otherwise the app opens full screen.",
                        color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 30.dp, vertical = 12.dp),
                    )
                }
            }
        }

        // media card: shrinks down into the bottom bar's mini player when the map goes full screen
        if (p < 0.65f) {
            MediaWidget(
                Modifier
                    .offset(lerp(homeMediaX, miniX, p), lerp(2.dp, h + 14.dp, p))
                    .size(lerp(homeMediaW, 270.dp, p), lerp(homeH, 52.dp, p))
                    .alpha((1f - p * 1.5f).coerceIn(0f, 1f)),
                onOpen = { onOpen(Page.Media) },
            )
        }
    }

    if (picker) {
        Dialog(onDismissRequest = { picker = false }) {
            Column(Modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).padding(18.dp).height(420.dp).width(620.dp)) {
                Text("Choose what the window shows", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("Map (built-in 3D)", source == "map", { prefs.put("pip_src", "map"); picker = false })
                    Pill("Auto-open at start", prefs.b("autoopen", false), { prefs.put("autoopen", !prefs.b("autoopen", false)) })
                }
                val proj = apps.projectionApps()
                if (proj.isNotEmpty()) {
                    Text("Phone projection", color = c.sub, fontSize = 13.sp)
                    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        proj.take(4).forEach { a -> AppTile(a, Modifier.width(100.dp)) { prefs.put("pip_src", a.pkg); picker = false } }
                    }
                }
                Text("All apps", color = c.sub, fontSize = 13.sp)
                LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.fillMaxSize()) {
                    items(apps.apps) { a -> AppTile(a, Modifier) { prefs.put("pip_src", a.pkg); picker = false } }
                }
            }
        }
    }
}

/** Light rain streaks drawn over the map (purely cosmetic, off by default). */
@Composable
fun RainOverlay(modifier: Modifier = Modifier) {
    val drops = remember { List(70) { floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.6f + Math.random().toFloat() * 0.8f) } }
    val t by androidx.compose.animation.core.rememberInfiniteTransition(label = "rain").animateFloat(
        0f, 1f, androidx.compose.animation.core.infiniteRepeatable(tween(1100, easing = androidx.compose.animation.core.LinearEasing)), label = "rainT",
    )
    androidx.compose.foundation.Canvas(modifier) {
        for (d in drops) {
            val x = d[0] * size.width
            val y = ((d[1] + t * d[2]) % 1f) * size.height
            val len = 16.dp.toPx() * d[2]
            drawLine(Color.White.copy(alpha = 0.22f * d[2]), androidx.compose.ui.geometry.Offset(x, y), androidx.compose.ui.geometry.Offset(x - len * 0.25f, y + len), 1.5.dp.toPx())
        }
    }
}

/** What matters while parked: weather, the next appointment and how far away the car is. */
@Composable
fun ParkedCard(engine: NavEngine, prefs: Prefs, modifier: Modifier = Modifier) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var event by remember { mutableStateOf<com.headunit.launcher.CalEvent?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            event = try { withContext(Dispatchers.IO) { com.headunit.launcher.CalendarData.upcoming(ctx, 2).firstOrNull { !it.allDay && it.begin > System.currentTimeMillis() - 600_000 } } } catch (e: Exception) { null }
            delay(5 * 60_000L)
        }
    }
    val car = engine.places.parked()
    val here = engine.fix?.pos
    val carDist = if (car != null && here != null) Geo.dist(here, car.pos) else null
    val items = ArrayList<@Composable () -> Unit>()
    event?.let { e -> items += {
        val mins = ((e.begin - System.currentTimeMillis()) / 60000).toInt()
        Column(Modifier.widthIn(max = 170.dp)) {
            Text(e.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (mins <= 0) "Now" else if (mins < 60) "In $mins min" else "At " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(e.begin)), color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
        }
    } }
    if (carDist != null && carDist in 40.0..3000.0) items += {
        val mins = Math.max(1, Math.round(carDist / 80.0).toInt())
        Column {
            Text("Car " + Geo.fmtDist(carDist, engine.imperial), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("$mins min walk", color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
        }
    }
    if (items.isEmpty()) return
    Row(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xCC0A0D12)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items.forEachIndexed { i, it ->
            if (i > 0) Box(Modifier.width(1.dp).height(30.dp).background(Color.White.copy(alpha = 0.25f)))
            it()
        }
    }
}

@Composable
fun AppTile(a: AppEntry, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalVw.current
    Column(
        modifier.pressClick(onClick).clip(RoundedCornerShape(14.dp)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(a.icon, a.label, Modifier.size(54.dp))
        Text(a.label, color = c.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun rememberMedia(): MediaInfo? {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    LaunchedEffect(Unit) { while (true) { info = MediaHelper.current(ctx); delay(1000) } }
    return info
}

@Composable
fun rememberMediaAccess(): Boolean {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(MediaHelper.hasAccess(ctx)) }
    LaunchedEffect(Unit) { while (true) { access = MediaHelper.hasAccess(ctx); delay(1500) } }
    return access
}

