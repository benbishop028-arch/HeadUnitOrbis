package com.headunit.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.rounded.CallMade
import androidx.compose.material.icons.rounded.CallMissed
import androidx.compose.material.icons.rounded.CallReceived
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import com.headunit.launcher.CallEntry
import com.headunit.launcher.Contact
import com.headunit.launcher.PhoneData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlin.math.roundToInt

// ------------------------------------------------------------------ Media
internal fun fmtClock(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    return String.format("%d:%02d", t / 60, t % 60)
}

// ------------------------------------------------------------------ Phone
@Composable
fun PhonePage() {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var number by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var perms by remember { mutableIntStateOf(0) }
    val canRead = remember(perms) { PhoneData.hasContacts(ctx) || PhoneData.hasCalls(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms++ }
    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var calls by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    LaunchedEffect(perms) {
        contacts = withContext(Dispatchers.IO) { PhoneData.contacts(ctx) }
        calls = withContext(Dispatchers.IO) { PhoneData.calls(ctx) }
    }
    val dateFmt = remember { java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault()) }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(number.ifEmpty { "Enter number" }, color = if (number.isEmpty()) c.sub else c.text, fontSize = 32.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.height(48.dp))
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    keys.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            row.forEach { k ->
                                Box(Modifier.width(96.dp).fillMaxHeight().clip(RoundedCornerShape(18.dp)).background(c.tile).clickable { number += k }, contentAlignment = Alignment.Center) {
                                    Text(k, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    TileBtn(Icons.Rounded.Backspace, { number = number.dropLast(1) }, size = 54.dp)
                    TileBtn(Icons.Rounded.Call, { if (number.isNotEmpty()) PhoneData.call(ctx, number) }, size = 64.dp, bg = PhoneGreen, tint = Color.White)
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Recent calls", tab == 0, { tab = 0 })
                    Pill("Contacts", tab == 1, { tab = 1 })
                }
                if (!canRead) {
                    Text("Allow access to your contacts and call history to see them here and call with one tap.", color = c.sub, fontSize = 14.sp)
                    Pill("Allow access", true, { launcher.launch(PhoneData.permissions) })
                } else if (tab == 0) {
                    if (calls.isEmpty()) EmptyState(Icons.Rounded.Call, "No recent calls", "Calls made and received show up here.")
                    LazyColumn(Modifier.weight(1f)) {
                        items(calls) { e ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { PhoneData.call(ctx, e.number) }.padding(horizontal = 6.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconBadge(
                                    when (e.type) { 1 -> Icons.Rounded.CallReceived; 3 -> Icons.Rounded.CallMissed; else -> Icons.Rounded.CallMade },
                                    if (e.type == 3) Bad else PhoneGreen, size = 38.dp,
                                )
                                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text(e.name.ifBlank { e.number }, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(dateFmt.format(java.util.Date(e.date)), color = c.sub, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                } else {
                    TextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        placeholder = { Text("Search contacts") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                        shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth(),
                    )
                    val q = query.trim().lowercase()
                    val shown = if (q.isEmpty()) contacts else contacts.filter { it.name.lowercase().contains(q) || it.number.filter { ch -> ch.isDigit() }.contains(q.filter { ch -> ch.isDigit() }.ifEmpty { "\u0000" }) }
                    if (shown.isEmpty()) EmptyState(Icons.Rounded.Call, "No contacts found")
                    LazyColumn(Modifier.weight(1f)) {
                        items(shown.take(300)) { ct ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { PhoneData.call(ctx, ct.number) }.padding(horizontal = 6.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).clip(CircleShape).background(c.tile), contentAlignment = Alignment.Center) {
                                    Text(ct.name.take(1).uppercase(), color = c.accent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text(ct.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(ct.number, color = c.sub, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
                if (!canRead) Box(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Dialler app", false, { Launch.view(ctx, Intent(Intent.ACTION_DIAL)) })
                    Pill("Bluetooth", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Apps
@Composable
fun AppsPage(apps: AppsRepo) {
    val ctx = LocalContext.current
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        LazyVerticalGrid(GridCells.Adaptive(112.dp), Modifier.fillMaxSize().padding(10.dp)) {
            items(apps.apps) { a ->
                AppTile(a) { Launch.app(ctx, a.pkg) }
            }
        }
    }
}

// ------------------------------------------------------------------ Settings
@Composable
private fun Row2(title: String, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.width(210.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { content() }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(c.line.copy(alpha = 0.35f)))
}

@Composable
private fun LookPicker(title: String, looks: List<Pair<String, Vw>>, sel: Int, onPick: (Int) -> Unit) {
    val c = LocalVw.current
    SectionLabel(title, Modifier.padding(top = 16.dp, bottom = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        looks.forEachIndexed { i, (name, v) ->
            Column(Modifier.clip(RoundedCornerShape(14.dp)).clickable { onPick(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(width = 112.dp, height = 72.dp).clip(RoundedCornerShape(14.dp)).background(v.bg)
                        .then(if (i == sel) Modifier.border(3.dp, c.accent, RoundedCornerShape(14.dp)) else Modifier).padding(8.dp),
                ) {
                    Row(Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)).background(v.panel).padding(5.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(v.tile))
                        Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(v.tile))
                        Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(v.accent))
                    }
                }
                Text(name, color = if (i == sel) c.text else c.sub, fontSize = 13.sp, fontWeight = if (i == sel) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
            }
        }
    }
}

@Composable
private fun AccentPicker(title: String, sel: Int, lookAccent: Color, onPick: (Int) -> Unit) {
    val c = LocalVw.current
    SectionLabel(title, Modifier.padding(top = 16.dp, bottom = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        AccentChoices.forEachIndexed { i, (name, col) ->
            Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(col ?: lookAccent)
                        .border(if (i == sel) 3.dp else 1.dp, if (i == sel) c.text else c.line, CircleShape),
                )
                Text(name, color = if (i == sel) c.text else c.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 3.dp))
            }
        }
    }
}

/** Background-only colour choice, kept separately for day and night (so day can be black and night white if you like). */
@Composable
private fun BgPicker(title: String, sel: Int, lookBg: Color, onPick: (Int) -> Unit) {
    val c = LocalVw.current
    SectionLabel(title, Modifier.padding(top = 16.dp, bottom = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        BgChoices.forEachIndexed { i, (name, col) ->
            Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(col ?: lookBg)
                        .border(if (i == sel) 3.dp else 1.dp, if (i == sel) c.accent else c.line, CircleShape),
                )
                Text(name, color = if (i == sel) c.text else c.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 3.dp))
            }
        }
    }
}

/** Full-screen style app chooser: every app, searchable, in a grid. */
@Composable
private fun AppPickerDialog(apps: AppsRepo, onPick: (com.headunit.launcher.AppEntry) -> Unit, onDismiss: () -> Unit) {
    val c = LocalVw.current
    var q by remember { mutableStateOf("") }
    val shown = remember(apps.apps, q) { if (q.isBlank()) apps.apps else apps.apps.filter { it.label.contains(q.trim(), true) } }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.82f).fillMaxHeight(0.86f).glass(24.dp).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Choose an app (${shown.size})", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Pill("Close", false, onDismiss)
            }
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Search apps") },
                colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
            )
            androidx.compose.foundation.lazy.grid.LazyVerticalGrid(androidx.compose.foundation.lazy.grid.GridCells.Adaptive(96.dp), Modifier.weight(1f)) {
                items(shown.size) { i ->
                    val a = shown[i]
                    AppTile(a, Modifier.padding(3.dp)) { onPick(a) }
                }
            }
        }
    }
}

/** Shows what the launcher can see about media (sessions, notifications, Bluetooth) to explain why a source is not appearing. */
@Composable
private fun MediaDiagDialog(onDismiss: () -> Unit) {
    val c = LocalVw.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val text by androidx.compose.runtime.produceState("Reading…", ctx) {
        while (true) {
            value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.headunit.launcher.MediaHelper.diagnostics(ctx) }
            kotlinx.coroutines.delay(2000)
        }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.glass(24.dp).padding(18.dp)) {
            Text("Media diagnostics", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
            Text(text, color = c.text, fontSize = 13.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, modifier = Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()))
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Notification access", false, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
                Pill("Close", true, onDismiss)
            }
        }
    }
}

@Composable
private fun Swatches(selected: Int, size: androidx.compose.ui.unit.Dp, onPick: (Int) -> Unit) {
    val c = LocalVw.current
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        AmbientColors.forEachIndexed { i, col ->
            Box(
                Modifier.size(size).clip(CircleShape).background(col)
                    .then(if (i == selected) Modifier.border(3.dp, c.text, CircleShape) else Modifier)
                    .clickable { onPick(i) },
            )
        }
    }
}

@Composable
private fun AmbientSettings(prefs: Prefs) {
    val c = LocalVw.current
    Row2("Colour") { Swatches(prefs.i("amb", 0), 34.dp) { prefs.put("amb", it) } }
    Row2("Reactive ambient light") {
        Pill("On", prefs.b("ambreact", true), { prefs.put("ambreact", true) })
        Pill("Off", !prefs.b("ambreact", true), { prefs.put("ambreact", false) })
    }
    Row2("Pulse animation") {
        Pill("On", prefs.b("ambpulse", true), { prefs.put("ambpulse", true) })
        Pill("Off", !prefs.b("ambpulse", true), { prefs.put("ambpulse", false) })
    }
    Row2("Glow strength") {
        var v by remember { mutableStateOf(prefs.i("ambint", 100).toFloat()) }
        androidx.compose.material3.Slider(
            value = v, onValueChange = { v = it }, onValueChangeFinished = { prefs.put("ambint", v.roundToInt()) },
            valueRange = 40f..160f, modifier = Modifier.width(300.dp),
        )
        Text("${v.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
    }
    Row2("Route line pulses at turns") { Switch(prefs.b("ambmap", true), { prefs.put("ambmap", it) }) }
    SectionLabel("When this happens", Modifier.padding(top = 18.dp, bottom = 4.dp))
    val events = listOf(
        Triple("brake", "Hard braking", 2), Triple("call", "Incoming call", 0), Triple("over", "Over the speed limit", 2),
        Triple("camera", "Speed camera ahead", 3), Triple("incident", "Incident or roadworks ahead", 3),
        Triple("turn", "Turn approaching", 1), Triple("arrive", "Arrival", 0),
    )
    for ((id, label, def) in events) {
        Row2(label) {
            Switch(prefs.b("ambe_$id", true), { prefs.put("ambe_$id", it) })
            if (prefs.b("ambe_$id", true)) Box(Modifier.width(12.dp))
            if (prefs.b("ambe_$id", true)) Swatches(prefs.i("ambc_$id", def), 26.dp) { prefs.put("ambc_$id", it) }
        }
    }
    Row2("Music (colour from the album art)") { Switch(prefs.b("ambe_music", true), { prefs.put("ambe_music", it) }) }
    Text(
        "Events only change the glow while reactive ambient light is on. Hard braking is detected from GPS speed, and incoming calls are detected from the phone's ringing state.",
        color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
    )
}

@Composable
fun SettingsPage(prefs: Prefs, engine: NavEngine, apps: AppsRepo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var cat by remember { mutableIntStateOf(0) }
    var diag by remember { mutableStateOf(false) }
    val cats = listOf("Display" to Icons.Rounded.Palette, "Driving" to Icons.Rounded.Speed, "Map & voice" to Icons.Rounded.Map, "Bottom bar" to Icons.Rounded.Dashboard, "Ambient light" to Icons.Rounded.Lightbulb, "System" to Icons.Rounded.Tune)
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.width(240.dp).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                cats.forEachIndexed { i, (label, icon) ->
                    val on = i == cat
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (on) c.tile else Color.Transparent).clickable { cat = i }.padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = if (on) c.accent else c.sub, modifier = Modifier.size(26.dp))
                        Text(label, color = if (on) c.text else c.sub, fontSize = 17.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(start = 14.dp))
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
                if (diag) MediaDiagDialog { diag = false }
                PageTitle(cats[cat].first, modifier = Modifier.padding(bottom = 8.dp))
                when (cat) {
                    0 -> {
                Row2("Appearance") {
                    Pill("Auto", prefs.s("theme", "auto") == "auto", { prefs.put("theme", "auto") })
                    Pill("Day", prefs.s("theme", "auto") == "day", { prefs.put("theme", "day") })
                    Pill("Night", prefs.s("theme", "auto") == "night", { prefs.put("theme", "night") })
                    Pill("Sunrise/sunset", prefs.s("theme", "auto") == "sun", { prefs.put("theme", "sun") })
                }
                LookPicker("Day look", DayLooks, prefs.i("daylook", 0)) { prefs.put("daylook", it) }
                LookPicker("Night look", NightLooks, prefs.i("nightlook", 0)) { prefs.put("nightlook", it) }
                BgPicker("Day background colour", prefs.i("daybg", 0), DayLooks[prefs.i("daylook", 0).coerceIn(0, DayLooks.lastIndex)].second.bg) { prefs.put("daybg", it) }
                BgPicker("Night background colour", prefs.i("nightbg", 0), NightLooks[prefs.i("nightlook", 0).coerceIn(0, NightLooks.lastIndex)].second.bg) { prefs.put("nightbg", it) }
                AccentPicker("Day highlight colour", prefs.i("dayaccent", 0), DayLooks[prefs.i("daylook", 0).coerceIn(0, DayLooks.lastIndex)].second.accent) { prefs.put("dayaccent", it) }
                AccentPicker("Night highlight colour", prefs.i("nightaccent", 0), NightLooks[prefs.i("nightlook", 0).coerceIn(0, NightLooks.lastIndex)].second.accent) { prefs.put("nightaccent", it) }
                Box(Modifier.height(10.dp))
                Row2("Brightness") {
                    var b by remember { mutableStateOf(prefs.i("bright", 100).toFloat()) }
                    androidx.compose.material3.Slider(
                        value = b, onValueChange = { b = it; prefs.put("bright", it.roundToInt()) },
                        valueRange = 10f..100f, modifier = Modifier.width(300.dp),
                    )
                    Text("${b.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
                }
                Row2("Dim screen at night") { Switch(prefs.b("dimnight", false), { prefs.put("dimnight", it) }) }
                Row2("Temperature") {
                    Pill("Celsius °C", !isImperial(prefs), { prefs.put("tempunit", "C") })
                    Pill("Fahrenheit °F", isImperial(prefs), { prefs.put("tempunit", "F") })
                }
                Row2("UI size") {
                    var sv by remember { mutableStateOf(prefs.i("uiscale", 100).toFloat()) }
                    androidx.compose.material3.Slider(
                        value = sv, onValueChange = { sv = it },
                        onValueChangeFinished = { prefs.put("uiscale", sv.roundToInt()) },
                        valueRange = 60f..140f, steps = 15,
                        modifier = Modifier.width(300.dp),
                    )
                    Text("${sv.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
                    Pill("Reset", false, { sv = 100f; prefs.put("uiscale", 100) })
                }
                Row2("Clock") {
                    Pill("24 hour", prefs.b("clock24", true), { prefs.put("clock24", true) })
                    Pill("12 hour", !prefs.b("clock24", true), { prefs.put("clock24", false) })
                }
                    }
                    1 -> {
                Row2("Distance & speed") {
                    Pill("Kilometres", !engine.imperial, { prefs.put("distunit", "km") })
                    Pill("Miles", engine.imperial, { prefs.put("distunit", "mi") })
                }
                Row2("Speed camera alerts") {
                    Pill("On", prefs.b("cameras", true), { prefs.put("cameras", true) })
                    Pill("Off", !prefs.b("cameras", true), { prefs.put("cameras", false) })
                }
                Row2("Speed limit change alert") {
                    Pill("On", prefs.b("limitchange", true), { prefs.put("limitchange", true) })
                    Pill("Off", !prefs.b("limitchange", true), { prefs.put("limitchange", false) })
                }
                Row2("Weather on route") {
                    Pill("On", prefs.b("routewx", true), { prefs.put("routewx", true) })
                    Pill("Off", !prefs.b("routewx", true), { prefs.put("routewx", false) })
                }
                Row2("Roadworks & incident alerts") {
                    Pill("On", prefs.b("incidents", true), { prefs.put("incidents", true) })
                    Pill("Off", !prefs.b("incidents", true), { prefs.put("incidents", false) })
                }
                Row2("Speed limit warning") {
                    Pill("On", prefs.b("speedwarn", true), { prefs.put("speedwarn", true) })
                    Pill("Off", !prefs.b("speedwarn", true), { prefs.put("speedwarn", false) })
                }
                Row2("Warn when over by") {
                    for (t in listOf("0", "5", "10")) Pill(t + if (engine.imperial) " mph" else " km/h", prefs.s("warntol", "5") == t, { prefs.put("warntol", t) })
                }
                Row2("Break reminder (every 2 h)") {
                    Pill("On", prefs.b("breakremind", true), { prefs.put("breakremind", true) })
                    Pill("Off", !prefs.b("breakremind", true), { prefs.put("breakremind", false) })
                }
                Row2("Screensaver when parked") {
                    Pill("On", prefs.b("screensaver", true), { prefs.put("screensaver", true) })
                    Pill("Off", !prefs.b("screensaver", true), { prefs.put("screensaver", false) })
                }
                Row2("Share ETA with") {
                    val pickEta = rememberEtaContactPicker(prefs)
                    Pill(prefs.s("etaname", "").ifBlank { "Choose contact" }, false, { pickEta() })
                }
                    }
                    2 -> {
                Row2("Map source") {
                    Pill("TomTom Orbis", prefs.s("mapstyle", "tomtom") == "tomtom", { prefs.put("mapstyle", "tomtom") })
                    Pill("OpenStreetMap (free)", prefs.s("mapstyle", "tomtom") == "osm", { prefs.put("mapstyle", "osm") })
                    Pill("Google Maps", prefs.s("mapstyle", "tomtom") == "google", { prefs.put("mapstyle", "google") })
                }
                if (prefs.s("mapstyle", "tomtom") == "google") {
                    Row2("Google Maps API key") {
                        var gk by remember { mutableStateOf(prefs.s("gkey", "")) }
                        TextField(
                            value = gk, onValueChange = { gk = it; prefs.put("gkey", it.trim()) },
                            placeholder = { Text("Key with Map Tiles API enabled") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile),
                            modifier = Modifier.width(420.dp),
                        )
                    }
                    Text("Google supplies the map picture only. Search, routing, traffic colours on the route and alerts still use TomTom.", color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                }
                Row2("Simplify map while driving") { Switch(prefs.b("drivesimple", true), { prefs.put("drivesimple", it) }) }
                Row2("Rain effect on map") { Switch(prefs.b("rainfx", false), { prefs.put("rainfx", it) }) }
                Row2("Live traffic on map") { Switch(prefs.b("traffic", true), { prefs.put("traffic", it) }) }
                Row2("Sound") {
                    Pill("All", engine.soundMode == 0, { prefs.put("soundmode", 0) })
                    Pill("Alerts only", engine.soundMode == 1, { prefs.put("soundmode", 1) })
                    Pill("Off", engine.soundMode == 2, { prefs.put("soundmode", 2) })
                }
                Row2("Test alert sound") { Pill("Play test alert", false, { engine.testAlert() }) }
                Row2("Search results") {
                    Pill("United Kingdom first", prefs.s("country", "GB") == "GB", { prefs.put("country", "GB") })
                    Pill("Anywhere", prefs.s("country", "GB").isEmpty(), { prefs.put("country", "") })
                }
                Text("Alerts only skips turn-by-turn voice but still speaks and chimes for speed cameras, speed limit changes, incidents, rain and break reminders.", color = LocalVw.current.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                Row2("Read messages aloud") { Switch(prefs.b("readmsgs", false), { prefs.put("readmsgs", it) }) }
                Row2("TomTom API key") {
                    var key by remember { mutableStateOf(prefs.s("apikey", "")) }
                    TextField(
                        value = key, onValueChange = { key = it; prefs.put("apikey", it.trim()) },
                        placeholder = { Text(if (engine.hasKey) "Using the key built into this app" else "Paste a key to enable search & routing") },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(focusedContainerColor = c.tile, unfocusedContainerColor = c.tile),
                        modifier = Modifier.width(420.dp),
                    )
                }
                    }
                    3 -> {
                SectionLabel("Info shown in the bar", Modifier.padding(top = 18.dp, bottom = 10.dp))
                Row2("Layout") {
                    Pill("Smart", prefs.s("barmode", "smart") == "smart", { prefs.put("barmode", "smart") })
                    Pill("Custom", prefs.s("barmode", "smart") == "custom", { prefs.put("barmode", "custom") })
                }
                Text(
                    if (prefs.s("barmode", "smart") == "smart") "Smart shows what is useful right now: the next turn while navigating, speed and journey times while driving, your next appointment and the weather when parked. Items you switch off below never appear."
                    else "Custom shows every item you switch on below, all the time, as far as there is room.",
                    color = c.sub, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp),
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BarInfoIds.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { id -> Pill(BarInfoNames[id] ?: id, prefs.b("bar_$id", true), { prefs.put("bar_$id", !prefs.b("bar_$id", true)) }) }
                        }
                    }
                }
                val (slotsL, slotsR) = barSideSlots(prefs)
                val hookList = engine.hooks.all()
                fun saveSlots(l: List<String>, r: List<String>) { prefs.put("barslotsL", l.joinToString(",")); prefs.put("barslotsR", r.joinToString(",")) }
                val addSide = prefs.s("addside", "right")
                fun addSlot(id: String) {
                    val l = slotsL; val r = slotsR
                    when {
                        id in l || id in r -> engine.toast("Already in the bar", 2000)
                        addSide == "left" && l.size >= 5 -> engine.toast("The left side holds up to 5 shortcuts. Tap one to remove it first.", 3000)
                        addSide != "left" && r.size >= 5 -> engine.toast("The right side holds up to 5 shortcuts. Tap one to remove it first.", 3000)
                        addSide == "left" -> saveSlots(l + id, r)
                        else -> saveSlots(l, r + id)
                    }
                }
                var appDialog by remember { mutableStateOf(false) }
                val pickCall = rememberPhonePicker { num, name -> addSlot("call:" + num.replace(",", "").replace("|", "") + "|" + name.replace(",", " ").replace("|", " ")) }
                SectionLabel("Shortcuts (tap one to remove it)", Modifier.padding(top = 16.dp, bottom = 8.dp))
                Row2("Left side") {
                    if (slotsL.isEmpty()) Text("None", color = c.sub, fontSize = 14.sp)
                    slotsL.forEachIndexed { i, id -> Pill(barSlotLabel(id, prefs, hookList, apps) + "  ✕", true, { saveSlots(slotsL.filterIndexed { n, _ -> n != i }, slotsR) }) }
                }
                Row2("Right side") {
                    if (slotsR.isEmpty()) Text("None", color = c.sub, fontSize = 14.sp)
                    slotsR.forEachIndexed { i, id -> Pill(barSlotLabel(id, prefs, hookList, apps) + "  ✕", true, { saveSlots(slotsL, slotsR.filterIndexed { n, _ -> n != i }) }) }
                }
                Row2("Add new shortcuts to the") {
                    Pill("Left", addSide == "left", { prefs.put("addside", "left") })
                    Pill("Right", addSide != "left", { prefs.put("addside", "right") })
                }
                SectionLabel("Add a shortcut", Modifier.padding(top = 16.dp, bottom = 8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("share", "fuel", "charging", "parking", "mute", "recentre", "tilt", "home", "work").chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { id -> Pill(barSlotLabel(id, prefs, hookList, apps), false, { addSlot(id) }) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("An app…", false, { appDialog = true })
                        Pill("Call a contact…", false, { pickCall() })
                        hookList.forEachIndexed { i, h -> Pill(h.name, false, { addSlot("hook:$i") }) }
                    }
                }
                if (appDialog) AppPickerDialog(apps, onPick = { addSlot("app:" + it.pkg); appDialog = false }, onDismiss = { appDialog = false })
                Row2("Home button outline") {
                    Pill("Auto", prefs.i("homecol", -1) < 0, { prefs.put("homecol", -1) })
                    Swatches(prefs.i("homecol", -1), 30.dp) { prefs.put("homecol", it) }
                }
                Row2("Mini player in bottom bar") {
                    Pill("Left", prefs.s("mini", "right") == "left", { prefs.put("mini", "left") })
                    Pill("Right", prefs.s("mini", "right") == "right", { prefs.put("mini", "right") })
                    Pill("Off", prefs.s("mini", "right") == "off", { prefs.put("mini", "off") })
                }
                    }
                    4 -> {
                        AmbientSettings(prefs)
                    }
                    else -> {
                Row2("Open window app at start") { Switch(prefs.b("autoopen", false), { prefs.put("autoopen", it) }) }
                SectionLabel("System", Modifier.padding(top = 18.dp, bottom = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Pill("Wi-Fi", false, { Launch.settings(ctx, Settings.ACTION_WIFI_SETTINGS) })
                    Pill("Bluetooth", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                    Pill("Display", false, { Launch.settings(ctx, Settings.ACTION_DISPLAY_SETTINGS) })
                    Pill("Sound", false, { Launch.settings(ctx, Settings.ACTION_SOUND_SETTINGS) })
                    Pill("Hotspot", false, {
                        try {
                            ctx.startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) { Launch.settings(ctx, Settings.ACTION_WIRELESS_SETTINGS) }
                    })
                    Pill("All settings", false, { Launch.settings(ctx, Settings.ACTION_SETTINGS) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Pill("Notification access (media)", false, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
                    Pill("Media diagnostics", false, { diag = true })
                    Pill("Default home app", false, { Launch.settings(ctx, Settings.ACTION_HOME_SETTINGS) })
                    Pill("Developer options", false, { Launch.settings(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) })
                }
                Text(
                    "For apps to open in the window on the Home page, turn on 'Enable freeform windows' (and 'Force activities to be resizable') in Developer options, then reboot. Without that, apps open full screen.",
                    color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp),
                )
                SectionLabel("Backup", Modifier.padding(top = 18.dp, bottom = 10.dp))
                val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
                    if (uri != null) {
                        val ok = try {
                            ctx.contentResolver.openOutputStream(uri)?.use { it.write(prefs.exportJson().toByteArray()) }
                            true
                        } catch (e: Exception) { false }
                        android.widget.Toast.makeText(ctx, if (ok) "Backup saved" else "Could not save the backup", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
                val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) {
                        val msg = try {
                            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                            "Restored ${prefs.importJson(text)} settings"
                        } catch (e: Exception) { "That file is not a valid backup" }
                        android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Back up settings & saved data", false, { exporter.launch("drive-launcher-backup.json") })
                    Pill("Restore from backup", false, { importer.launch(arrayOf("application/json", "text/plain", "*/*")) })
                }
                Text("Backups include settings, saved places, trips and logs. The API key is not included.", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}
