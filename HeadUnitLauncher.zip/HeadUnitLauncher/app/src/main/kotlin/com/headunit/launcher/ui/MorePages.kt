package com.headunit.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlin.math.roundToInt

// ------------------------------------------------------------------ Media
@Composable
fun MediaPage(apps: AppsRepo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = MediaHelper.hasAccess(ctx)
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1.3f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (!access) {
                    Text("Allow notification access to show what is playing and use the controls.", color = c.text, fontSize = 16.sp, textAlign = TextAlign.Center)
                    Pill("Open access settings", true, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, Modifier.padding(top = 14.dp))
                } else if (m == null) {
                    Text("Nothing playing", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text("Start a music app on the right.", color = c.sub, fontSize = 15.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(150.dp).clip(RoundedCornerShape(18.dp)).background(c.surface2), contentAlignment = Alignment.Center) {
                            if (m.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Column(Modifier.padding(start = 20.dp).width(260.dp)) {
                            Text(m.title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(m.artist, color = c.sub, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
                    Box(Modifier.padding(top = 22.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(c.line)) {
                        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(c.accent))
                    }
                    Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        RoundBtn(Icons.Rounded.SkipPrevious, { m.controller.transportControls.skipToPrevious() }, size = 62.dp)
                        RoundBtn(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, { if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play() }, active = true, size = 76.dp)
                        RoundBtn(Icons.Rounded.SkipNext, { m.controller.transportControls.skipToNext() }, size = 62.dp)
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp)) {
                Text("Sources", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                val music = apps.musicApps().ifEmpty { apps.apps.take(0) }
                if (music.isEmpty()) Text("No music apps found. Open the Apps page.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.fillMaxSize()) {
                    items(music) { a -> AppTile(a) { Launch.app(ctx, a.pkg) } }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Phone
@Composable
fun PhonePage() {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var number by remember { mutableStateOf("") }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(number.ifEmpty { "Enter number" }, color = if (number.isEmpty()) c.sub else c.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.height(44.dp))
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    keys.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            row.forEach { k ->
                                Box(Modifier.width(96.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(c.surface2).clickable { number += k }, contentAlignment = Alignment.Center) {
                                    Text(k, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(Icons.Rounded.Backspace, { number = number.dropLast(1) }, size = 52.dp)
                    RoundBtn(Icons.Rounded.Call, {
                        if (number.isNotEmpty()) Launch.view(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                    }, size = 62.dp, active = true, tint = Color.White)
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Phone", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Pill("Contacts", false, { Launch.view(ctx, Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)) })
                Pill("Recent calls", false, { Launch.view(ctx, Intent(Intent.ACTION_VIEW, CallLog.Calls.CONTENT_URI)) })
                Pill("Dialler app", false, { Launch.view(ctx, Intent(Intent.ACTION_DIAL)) })
                Pill("Bluetooth settings", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                Text("Calls go through the head unit's own phone/Bluetooth app.", color = c.sub, fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Vehicle (trip computer from GPS)
@Composable
fun CarPage(engine: NavEngine) {
    val c = LocalVw.current
    val f = engine.fix
    val imp = engine.imperial
    val spd = (f?.speed ?: 0.0) * (if (imp) 2.23694 else 3.6)
    val unit = if (imp) "mph" else "km/h"
    val dist = engine.tripDist / (if (imp) 1609.344 else 1000.0)
    val avgMs = if (engine.tripMoving > 0) engine.tripDist / engine.tripMoving else 0.0
    val avg = avgMs * (if (imp) 2.23694 else 3.6)
    val max = engine.tripMax * (if (imp) 2.23694 else 3.6)
    val heading = f?.heading ?: 0.0
    val card = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")[(((heading % 360) + 360) % 360 / 45.0 + 0.5).toInt() % 8]
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("${spd.roundToInt()}", color = c.text, fontSize = 84.sp, fontWeight = FontWeight.Bold)
                Text(unit, color = c.sub, fontSize = 20.sp)
                Box(Modifier.padding(top = 16.dp).size(96.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize().rotate((-heading).toFloat())) {
                        drawCircle(c.line, size.minDimension / 2, style = Stroke(4f))
                        drawLine(Color(0xFFFF4D4D), center, Offset(center.x, 6f), 6f)
                        drawLine(c.sub, center, Offset(center.x, size.height - 6f), 4f)
                    }
                    Text(card, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Text("${heading.roundToInt()}°", color = c.sub, fontSize = 14.sp)
            }
        }
        VCard(Modifier.weight(1.4f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Stat("Trip", String.format("%.1f", dist), if (imp) "mi" else "km", Modifier.weight(1f))
                    Stat("Average", "${avg.roundToInt()}", unit, Modifier.weight(1f))
                    Stat("Max", "${max.roundToInt()}", unit, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    val mins = (engine.tripMoving / 60).roundToInt()
                    Stat("Moving", "${mins / 60}:${(mins % 60).toString().padStart(2, '0')}", "h", Modifier.weight(1f))
                    val alt = f?.alt ?: 0.0
                    Stat("Altitude", "${(if (imp) alt * 3.28084 else alt).roundToInt()}", if (imp) "ft" else "m", Modifier.weight(1f))
                    val w = engine.weather
                    Stat("Outside", if (w != null) "${(if (imp) w.tempC * 9 / 5 + 32 else w.tempC).roundToInt()}" else "--", if (imp) "°F" else "°C", Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill("Reset trip", false, { engine.resetTrip() })
                    Text(if (f == null) "Waiting for GPS…" else "GPS locked", color = if (f == null) Warn else Good, fontSize = 14.sp)
                }
                Text("Values come from the head unit's GPS. Fuel, range and tyre data are not available to a normal app.", color = c.sub, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, unit: String, modifier: Modifier) {
    val c = LocalVw.current
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(c.surface2).padding(14.dp)) {
        Text(label, color = c.sub, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = c.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(" $unit", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(bottom = 5.dp))
        }
    }
}

// ------------------------------------------------------------------ Apps
@Composable
fun AppsPage(apps: AppsRepo) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().padding(14.dp)) {
        LazyVerticalGrid(GridCells.Adaptive(112.dp), Modifier.fillMaxSize()) {
            items(apps.apps) { a ->
                AppTile(a) { Launch.app(ctx, a.pkg) }
            }
        }
    }
}

// ------------------------------------------------------------------ Settings
@Composable
private fun Row2(title: String, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.width(210.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { content() }
    }
}

@Composable
fun SettingsPage(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row2("Appearance") {
                Pill("Auto", prefs.s("theme", "auto") == "auto", { prefs.put("theme", "auto") })
                Pill("Day", prefs.s("theme", "auto") == "day", { prefs.put("theme", "day") })
                Pill("Night", prefs.s("theme", "auto") == "night", { prefs.put("theme", "night") })
            }
            Row2("Units") {
                Pill("Metric", !engine.imperial, { prefs.put("units", "metric") })
                Pill("Imperial", engine.imperial, { prefs.put("units", "imperial") })
            }
            Row2("Clock") {
                Pill("24 hour", prefs.b("clock24", true), { prefs.put("clock24", true) })
                Pill("12 hour", !prefs.b("clock24", true), { prefs.put("clock24", false) })
            }
            Row2("Map source") {
                Pill("TomTom Orbis", prefs.s("mapstyle", "tomtom") == "tomtom", { prefs.put("mapstyle", "tomtom") })
                Pill("OpenStreetMap (free)", prefs.s("mapstyle", "tomtom") == "osm", { prefs.put("mapstyle", "osm") })
            }
            Row2("Live traffic on map") { Switch(prefs.b("traffic", true), { prefs.put("traffic", it) }) }
            Row2("Voice guidance") { Switch(engine.voiceOn, { prefs.put("voice", it) }) }
            Row2("Open window app at start") { Switch(prefs.b("autoopen", false), { prefs.put("autoopen", it) }) }
            Row2("TomTom API key") {
                var key by remember { mutableStateOf(prefs.s("apikey", "")) }
                TextField(
                    value = key, onValueChange = { key = it; prefs.put("apikey", it.trim()) },
                    placeholder = { Text(if (engine.hasKey) "Using the key built into this app" else "Paste a key to enable search & routing") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2),
                    modifier = Modifier.width(420.dp),
                )
            }
            Text("System", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Pill("Wi-Fi", false, { Launch.settings(ctx, Settings.ACTION_WIFI_SETTINGS) })
                Pill("Bluetooth", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                Pill("Display", false, { Launch.settings(ctx, Settings.ACTION_DISPLAY_SETTINGS) })
                Pill("Sound", false, { Launch.settings(ctx, Settings.ACTION_SOUND_SETTINGS) })
                Pill("All settings", false, { Launch.settings(ctx, Settings.ACTION_SETTINGS) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Pill("Notification access (media)", false, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
                Pill("Default home app", false, { Launch.settings(ctx, Settings.ACTION_HOME_SETTINGS) })
                Pill("Developer options", false, { Launch.settings(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) })
            }
            Text(
                "For apps to open in the window on the Home page, turn on 'Enable freeform windows' (and 'Force activities to be resizable') in Developer options, then reboot. Without that, apps open full screen.",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp),
            )
            Text(
                "The climate bar is a visual copy of a car's controls; it does not control the vehicle.",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}
