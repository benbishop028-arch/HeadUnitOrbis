package com.headunit.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.rounded.CallMade
import androidx.compose.material.icons.rounded.CallMissed
import androidx.compose.material.icons.rounded.CallReceived
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import com.headunit.launcher.CallEntry
import com.headunit.launcher.Contact
import com.headunit.launcher.PhoneData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlin.math.roundToInt

// ------------------------------------------------------------------ Media
@Composable
fun MediaPage(apps: AppsRepo) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    val m = rememberMedia()
    val access = MediaHelper.hasAccess(ctx)
    val voicePlay = rememberVoiceInput("Say a song, artist or playlist") { q ->
        val mc = m?.controller
        if (mc != null) mc.transportControls.playFromSearch(q, null)
        else try {
            ctx.startActivity(
                Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(android.app.SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) { android.widget.Toast.makeText(ctx, "Start a music app first", android.widget.Toast.LENGTH_SHORT).show() }
    }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1.3f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (!access) {
                    Text("Allow notification access to show what is playing and use the controls.", color = c.text, fontSize = 16.sp, textAlign = TextAlign.Center)
                    Pill("Open access settings", true, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, Modifier.padding(top = 14.dp))
                } else if (m == null) {
                    Text("Nothing playing", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text("Start a music app on the right.", color = c.sub, fontSize = 15.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(150.dp).clip(RoundedCornerShape(18.dp)).background(c.surface2), contentAlignment = Alignment.Center) {
                            if (m.art != null) Image(m.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Column(Modifier.padding(start = 20.dp).width(260.dp)) {
                            Text(m.title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(m.artist, color = c.sub, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    val frac = if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f
                    SeekBar(frac, m.dur > 0, { f -> m.controller.transportControls.seekTo((f * m.dur).toLong()) }, Modifier.padding(top = 18.dp).fillMaxWidth())
                    if (m.dur > 0) Row(Modifier.fillMaxWidth()) {
                        Text(fmtClock(m.pos), color = c.sub, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(fmtClock(m.dur), color = c.sub, fontSize = 12.sp)
                    }
                    Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        RoundBtn(Icons.Rounded.SkipPrevious, { m.controller.transportControls.skipToPrevious() }, size = 62.dp)
                        RoundBtn(if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, { if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play() }, active = true, size = 76.dp)
                        RoundBtn(Icons.Rounded.SkipNext, { m.controller.transportControls.skipToNext() }, size = 62.dp)
                    }
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp)) {
                Row(Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Volume", color = c.sub, fontSize = 14.sp)
                    Pill("–", false, { Launch.volume(ctx, false) })
                    Pill("+", false, { Launch.volume(ctx, true) })
                    Pill("Voice play", false, { voicePlay() })
                }
                Text("Sources", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                val music = apps.musicApps().ifEmpty { apps.apps.take(0) }
                if (music.isEmpty()) Text("No music apps found. Open the Apps page.", color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.fillMaxSize()) {
                    items(music) { a -> AppTile(a) { Launch.app(ctx, a.pkg) } }
                }
            }
        }
    }
}

private fun fmtClock(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    return String.format("%d:%02d", t / 60, t % 60)
}

// ------------------------------------------------------------------ Phone
@Composable
fun PhonePage() {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var number by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var perms by remember { mutableIntStateOf(0) }
    val canRead = remember(perms) { PhoneData.hasContacts(ctx) || PhoneData.hasCalls(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms++ }
    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var calls by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    LaunchedEffect(perms) {
        contacts = withContext(Dispatchers.IO) { PhoneData.contacts(ctx) }
        calls = withContext(Dispatchers.IO) { PhoneData.calls(ctx) }
    }
    val dateFmt = remember { java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault()) }
    Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(number.ifEmpty { "Enter number" }, color = if (number.isEmpty()) c.sub else c.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.height(44.dp))
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    keys.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            row.forEach { k ->
                                Box(Modifier.width(96.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(c.surface2).clickable { number += k }, contentAlignment = Alignment.Center) {
                                    Text(k, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(Icons.Rounded.Backspace, { number = number.dropLast(1) }, size = 52.dp)
                    RoundBtn(Icons.Rounded.Call, { if (number.isNotEmpty()) PhoneData.call(ctx, number) }, size = 62.dp, active = true, tint = Color.White)
                }
            }
        }
        VCard(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Recent calls", tab == 0, { tab = 0 })
                    Pill("Contacts", tab == 1, { tab = 1 })
                }
                if (!canRead) {
                    Text("Allow access to your contacts and call history to see them here and call with one tap.", color = c.sub, fontSize = 14.sp)
                    Pill("Allow access", true, { launcher.launch(PhoneData.permissions) })
                } else if (tab == 0) {
                    if (calls.isEmpty()) Text("No recent calls.", color = c.sub, fontSize = 14.sp)
                    LazyColumn(Modifier.weight(1f)) {
                        items(calls) { e ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { PhoneData.call(ctx, e.number) }.padding(horizontal = 6.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    when (e.type) { 1 -> Icons.Rounded.CallReceived; 3 -> Icons.Rounded.CallMissed; else -> Icons.Rounded.CallMade },
                                    null, tint = if (e.type == 3) Bad else c.sub, modifier = Modifier.size(20.dp),
                                )
                                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text(e.name.ifBlank { e.number }, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(dateFmt.format(java.util.Date(e.date)), color = c.sub, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                } else {
                    TextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        placeholder = { Text("Search contacts") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                        shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth(),
                    )
                    val q = query.trim().lowercase()
                    val shown = if (q.isEmpty()) contacts else contacts.filter { it.name.lowercase().contains(q) || it.number.filter { ch -> ch.isDigit() }.contains(q.filter { ch -> ch.isDigit() }.ifEmpty { "\u0000" }) }
                    if (shown.isEmpty()) Text("No contacts found.", color = c.sub, fontSize = 14.sp)
                    LazyColumn(Modifier.weight(1f)) {
                        items(shown.take(300)) { ct ->
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { PhoneData.call(ctx, ct.number) }.padding(horizontal = 6.dp, vertical = 8.dp)) {
                                Text(ct.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(ct.number, color = c.sub, fontSize = 12.sp)
                            }
                        }
                    }
                }
                if (!canRead) Box(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Dialler app", false, { Launch.view(ctx, Intent(Intent.ACTION_DIAL)) })
                    Pill("Bluetooth", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Apps
@Composable
fun AppsPage(apps: AppsRepo) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().padding(14.dp)) {
        LazyVerticalGrid(GridCells.Adaptive(112.dp), Modifier.fillMaxSize()) {
            items(apps.apps) { a ->
                AppTile(a) { Launch.app(ctx, a.pkg) }
            }
        }
    }
}

// ------------------------------------------------------------------ Settings
@Composable
private fun Row2(title: String, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.width(210.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { content() }
    }
}

@Composable
fun SettingsPage(prefs: Prefs, engine: NavEngine) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    VCard(Modifier.fillMaxSize().padding(14.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row2("Appearance") {
                Pill("Auto", prefs.s("theme", "auto") == "auto", { prefs.put("theme", "auto") })
                Pill("Day", prefs.s("theme", "auto") == "day", { prefs.put("theme", "day") })
                Pill("Night", prefs.s("theme", "auto") == "night", { prefs.put("theme", "night") })
                Pill("Sunrise/sunset", prefs.s("theme", "auto") == "sun", { prefs.put("theme", "sun") })
            }
            Row2("Brightness") {
                var b by remember { mutableStateOf(prefs.i("bright", 100).toFloat()) }
                androidx.compose.material3.Slider(
                    value = b, onValueChange = { b = it; prefs.put("bright", it.roundToInt()) },
                    valueRange = 10f..100f, modifier = Modifier.width(300.dp),
                )
                Text("${b.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
            }
            Row2("Dim screen at night") { Switch(prefs.b("dimnight", false), { prefs.put("dimnight", it) }) }
            Row2("Distance & speed") {
                Pill("Kilometres", !engine.imperial, { prefs.put("distunit", "km") })
                Pill("Miles", engine.imperial, { prefs.put("distunit", "mi") })
            }
            Row2("Speed camera alerts") {
                Pill("On", prefs.b("cameras", true), { prefs.put("cameras", true) })
                Pill("Off", !prefs.b("cameras", true), { prefs.put("cameras", false) })
            }
            Row2("Temperature") {
                Pill("Celsius °C", !isImperial(prefs), { prefs.put("tempunit", "C") })
                Pill("Fahrenheit °F", isImperial(prefs), { prefs.put("tempunit", "F") })
            }
            Row2("UI size") {
                var sv by remember { mutableStateOf(prefs.i("uiscale", 100).toFloat()) }
                androidx.compose.material3.Slider(
                    value = sv, onValueChange = { sv = it },
                    onValueChangeFinished = { prefs.put("uiscale", sv.roundToInt()) },
                    valueRange = 60f..140f, steps = 15,
                    modifier = Modifier.width(300.dp),
                )
                Text("${sv.roundToInt()}%", color = c.text, fontSize = 16.sp, modifier = Modifier.width(56.dp))
                Pill("Reset", false, { sv = 100f; prefs.put("uiscale", 100) })
            }
            Row2("Clock") {
                Pill("24 hour", prefs.b("clock24", true), { prefs.put("clock24", true) })
                Pill("12 hour", !prefs.b("clock24", true), { prefs.put("clock24", false) })
            }
            Row2("Map source") {
                Pill("TomTom Orbis", prefs.s("mapstyle", "tomtom") == "tomtom", { prefs.put("mapstyle", "tomtom") })
                Pill("OpenStreetMap (free)", prefs.s("mapstyle", "tomtom") == "osm", { prefs.put("mapstyle", "osm") })
            }
            Row2("Mini player in bottom bar") {
                Pill("Left", prefs.s("mini", "right") == "left", { prefs.put("mini", "left") })
                Pill("Right", prefs.s("mini", "right") == "right", { prefs.put("mini", "right") })
                Pill("Off", prefs.s("mini", "right") == "off", { prefs.put("mini", "off") })
            }
            Row2("Live traffic on map") { Switch(prefs.b("traffic", true), { prefs.put("traffic", it) }) }
            Row2("Voice guidance") { Switch(engine.voiceOn, { prefs.put("voice", it) }) }
            Row2("Read messages aloud") { Switch(prefs.b("readmsgs", false), { prefs.put("readmsgs", it) }) }
            Row2("Open window app at start") { Switch(prefs.b("autoopen", false), { prefs.put("autoopen", it) }) }
            Row2("TomTom API key") {
                var key by remember { mutableStateOf(prefs.s("apikey", "")) }
                TextField(
                    value = key, onValueChange = { key = it; prefs.put("apikey", it.trim()) },
                    placeholder = { Text(if (engine.hasKey) "Using the key built into this app" else "Paste a key to enable search & routing") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(focusedContainerColor = c.surface2, unfocusedContainerColor = c.surface2),
                    modifier = Modifier.width(420.dp),
                )
            }
            Text("System", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Pill("Wi-Fi", false, { Launch.settings(ctx, Settings.ACTION_WIFI_SETTINGS) })
                Pill("Bluetooth", false, { Launch.settings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
                Pill("Display", false, { Launch.settings(ctx, Settings.ACTION_DISPLAY_SETTINGS) })
                Pill("Sound", false, { Launch.settings(ctx, Settings.ACTION_SOUND_SETTINGS) })
                Pill("Hotspot", false, {
                    try {
                        ctx.startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) { Launch.settings(ctx, Settings.ACTION_WIRELESS_SETTINGS) }
                })
                Pill("All settings", false, { Launch.settings(ctx, Settings.ACTION_SETTINGS) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Pill("Notification access (media)", false, { Launch.settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
                Pill("Default home app", false, { Launch.settings(ctx, Settings.ACTION_HOME_SETTINGS) })
                Pill("Developer options", false, { Launch.settings(ctx, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) })
            }
            Text(
                "For apps to open in the window on the Home page, turn on 'Enable freeform windows' (and 'Force activities to be resizable') in Developer options, then reboot. Without that, apps open full screen.",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp),
            )
            Text("Backup", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
            val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
                if (uri != null) {
                    val ok = try {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(prefs.exportJson().toByteArray()) }
                        true
                    } catch (e: Exception) { false }
                    android.widget.Toast.makeText(ctx, if (ok) "Backup saved" else "Could not save the backup", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    val msg = try {
                        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                        "Restored ${prefs.importJson(text)} settings"
                    } catch (e: Exception) { "That file is not a valid backup" }
                    android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Back up settings & saved data", false, { exporter.launch("drive-launcher-backup.json") })
                Pill("Restore from backup", false, { importer.launch(arrayOf("application/json", "text/plain", "*/*")) })
            }
            Text("Backups include settings, saved places, trips and logs. The API key is not included.", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
