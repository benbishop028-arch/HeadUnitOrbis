package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class Page(val label: String) {
    Home("Home"), Menu("Menu"), Nav("Navigation"), Media("Radio/Media"), Phone("Telephone"),
    AppConnect("App-Connect"), Apps("Apps"), Settings("Settings"), Ambient("Ambient light"),
    Weather("Weather"), Calendar("Calendar"), Clock("Clock"), Trips("Trips"), CarLog("Car log"),
    Drive("Drive computer"), SmartHome("Smart home"), DashCam("Dash cam"), Discover("Discover"),
}

private fun findActivity(c: android.content.Context): android.app.Activity? {
    var x: android.content.Context = c
    while (x is android.content.ContextWrapper) {
        if (x is android.app.Activity) return x
        x = x.baseContext
    }
    return null
}

fun ambientOf(prefs: Prefs): Color = AmbientColors[prefs.i("amb", 0).coerceIn(0, AmbientColors.lastIndex)]

@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        delay(6000)
        try {
            val due = com.headunit.launcher.ServiceStore(prefs).dueSoon()
            if (due != null) engine.toast(due, 8000)
        } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = System.currentTimeMillis() } }
    val dark = resolveDark(prefs.s("theme", "auto"), prefs.s("lastlat", "").toDoubleOrNull(), prefs.s("lastlon", "").toDoubleOrNull(), nowMs)

    // screen brightness (per window, no permission needed) incl. dimming at night
    val bright = prefs.i("bright", 100)
    val dimNight = prefs.b("dimnight", false)
    val hostCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(bright, dimNight, dark) {
        val win = findActivity(hostCtx)?.window ?: return@LaunchedEffect
        val dim = dimNight && dark
        val v = if (bright >= 100 && !dim) -1f else (bright / 100f * (if (dim) 0.5f else 1f)).coerceIn(0.03f, 1f)
        val lp = win.attributes
        lp.screenBrightness = v
        win.attributes = lp
    }
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    LaunchedEffect(dark, style, traffic, key) { engine.applyStyle(dark) }
    LaunchedEffect(Unit) { apps.refresh() }
    val sat = prefs.b("satellite", false)
    val b3d = prefs.b("buildings3d", true)
    LaunchedEffect(sat, b3d) { map.setView(sat, b3d) }

    val scale = prefs.i("uiscale", 100).coerceIn(60, 140) / 100f
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density * scale, baseDensity.fontScale),
    ) {
    VwTheme(dark) {
        val c = LocalVw.current
        val amb = ambientOf(prefs)
        var page by rememberSaveable { mutableStateOf(Page.Home) }
        BackHandler(enabled = page != Page.Home) { page = if (page == Page.Menu) Page.Home else Page.Menu.takeIf { page in menuChildren } ?: Page.Home }

        // very slow drift of the ambient light (a full sweep takes minutes, so it is barely noticeable)
        val drift = androidx.compose.animation.core.rememberInfiniteTransition(label = "ambDrift")
        val d1 by drift.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(150_000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "d1")
        val d2 by drift.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(210_000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "d2")
        var lastTouch by remember { mutableStateOf(System.currentTimeMillis()) }
        var saver by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(5000)
                val parked = (engine.fix?.speed ?: 0.0) < 1.0
                val playing = try { com.headunit.launcher.MediaHelper.current(hostCtx)?.playing == true } catch (e: Exception) { false }
                saver = prefs.b("screensaver", true) && parked && engine.route == null && !playing && System.currentTimeMillis() - lastTouch > 300_000
            }
        }
        Box(
            Modifier.fillMaxSize().background(c.bg).pointerInput(Unit) {
                awaitPointerEventScope { while (true) { awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial); lastTouch = System.currentTimeMillis() } }
            }.drawBehind {
                // ambient light bleeding in from the edges, like the green glow in the car
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, amb.copy(alpha = if (c.dark) 0.24f else 0.14f)), startY = size.height * (0.52f + 0.08f * d2)))
                drawRect(Brush.horizontalGradient(listOf(amb.copy(alpha = if (c.dark) 0.20f else 0.10f), Color.Transparent), endX = size.width * (0.14f + 0.08f * d1)))
                // a soft pool of light that wanders along the bottom edge
                val cx = size.width * (0.15f + 0.70f * d1)
                drawRect(Brush.radialGradient(
                    listOf(amb.copy(alpha = if (c.dark) 0.16f else 0.09f), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(cx, size.height * (1.02f - 0.06f * d2)), radius = size.width * 0.42f))
            },
        ) {
            Box(Modifier.fillMaxSize().padding(top = 46.dp, bottom = 70.dp)) {
                when (page) {
                    Page.Home, Page.Nav -> HomePage(prefs, engine, map, apps, nav = page == Page.Nav, onOpen = { page = it })
                    Page.Menu -> MenuPage(prefs, amb, onOpen = { page = it })
                    Page.Media -> MediaPage(apps)
                    Page.Phone -> PhonePage()
                    Page.AppConnect -> AppConnectPage(apps, prefs, onHome = { page = Page.Home })
                    Page.Apps -> AppsPage(apps)
                    Page.Settings -> SettingsPage(prefs, engine)
                    Page.Ambient -> AmbientPage(prefs)
                    Page.Weather -> WeatherPage(engine, prefs)
                    Page.Calendar -> CalendarPage(engine, onOpen = { page = it })
                    Page.Clock -> ClockPage(prefs)
                    Page.Trips -> TripsPage(engine)
                    Page.CarLog -> CarLogPage(engine)
                    Page.Drive -> DrivePage(engine)
                    Page.SmartHome -> SmartHomePage(engine)
                    Page.DashCam -> DashCamPage()
                    Page.Discover -> DiscoverPage(engine, prefs, onOpen = { page = it })
                }
                engine.message?.let { m ->
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).padding(horizontal = 20.dp, vertical = 10.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
            }
            Box(Modifier.align(Alignment.TopCenter)) { TopBar(page, { page = it }, engine, prefs, amb) }
            Box(Modifier.align(Alignment.BottomCenter)) { BottomBar(prefs, page, amb, onPage = { page = it }) }
            if (saver) Screensaver(onDismiss = { saver = false; lastTouch = System.currentTimeMillis() })
        }
    }
    }
}

private val menuChildren = setOf(
    Page.Media, Page.Phone, Page.AppConnect, Page.Apps, Page.Settings, Page.Ambient, Page.Weather, Page.Calendar, Page.Clock, Page.Trips, Page.CarLog,
    Page.Drive, Page.SmartHome, Page.DashCam, Page.Discover,
)

@Composable
private fun TopIcon(selected: Boolean, amb: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(if (selected) c.surface2 else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun TopBar(page: Page, onPage: (Page) -> Unit, engine: NavEngine, prefs: Prefs, amb: Color) {
    val c = LocalVw.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = if (prefs.b("clock24", true)) "H:mm" else "h:mm"
    val clock = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
    val imp = isImperial(prefs)
    val w = engine.weather
    val temp = w?.let { if (imp) "${(it.tempC * 9 / 5 + 32).roundToInt()} °F" else "${it.tempC.roundToInt()} °C" } ?: "-- °${if (imp) "F" else "C"}"

    Box(Modifier.fillMaxWidth().height(46.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.7f), Color.Transparent))).padding(horizontal = 12.dp)) {
        Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TopIcon(page == Page.Menu, amb, { onPage(Page.Menu) }) { Icon(Icons.Rounded.Apps, "Menu", tint = amb, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Media, amb, { onPage(Page.Media) }) { Icon(Icons.Rounded.MusicNote, "Media", tint = MediaRed, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Nav, amb, { onPage(Page.Nav) }) { Icon(Icons.Rounded.Navigation, "Navigation", tint = NavBlue, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Ambient, amb, { onPage(Page.Ambient) }) { AmbientGlyph(Modifier.size(22.dp)) }
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(26.dp).height(2.dp).background(c.sub))
            Text(temp, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 3.dp))
        }
        Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
            if (engine.fix != null) Icon(Icons.Rounded.Place, null, tint = c.text, modifier = Modifier.size(16.dp))
            Text(clock, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp, end = 4.dp))
        }
    }
}
