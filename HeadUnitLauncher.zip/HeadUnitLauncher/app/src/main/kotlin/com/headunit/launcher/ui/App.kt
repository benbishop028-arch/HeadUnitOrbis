package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class Page(val label: String) {
    Home("Home"), Menu("Menu"), Nav("Navigation"), Media("Radio/Media"), Phone("Telephone"), Car("Vehicle"),
    AppConnect("App-Connect"), Apps("Apps"), Settings("Settings"), Climate("Climate"), Seats("Seats"),
    Ambient("Ambient light"), Parking("Parking"), Assist("Assist syst."), Experience("Experience"), Offroad("Offroad"),
}

fun ambientOf(prefs: Prefs): Color = AmbientColors[prefs.i("amb", 0).coerceIn(0, AmbientColors.lastIndex)]

@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo) {
    val dark = resolveDark(prefs.s("theme", "auto"))
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    LaunchedEffect(dark, style, traffic, key) { engine.applyStyle(dark) }
    LaunchedEffect(Unit) { apps.refresh() }

    VwTheme(dark) {
        val c = LocalVw.current
        val amb = ambientOf(prefs)
        var page by rememberSaveable { mutableStateOf(Page.Home) }
        BackHandler(enabled = page != Page.Home) { page = if (page == Page.Menu) Page.Home else Page.Menu.takeIf { page in menuChildren } ?: Page.Home }

        Box(
            Modifier.fillMaxSize().background(c.bg).drawBehind {
                // ambient light bleeding in from the edges, like the green glow in the car
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, amb.copy(alpha = if (c.dark) 0.28f else 0.16f)), startY = size.height * 0.55f))
                drawRect(Brush.horizontalGradient(listOf(amb.copy(alpha = if (c.dark) 0.20f else 0.10f), Color.Transparent), endX = size.width * 0.18f))
            },
        ) {
            Box(Modifier.fillMaxSize().padding(top = 46.dp, bottom = 70.dp)) {
                when (page) {
                    Page.Home, Page.Nav -> HomePage(prefs, engine, map, apps, nav = page == Page.Nav, onOpen = { page = it })
                    Page.Menu -> MenuPage(prefs, amb, onOpen = { page = it })
                    Page.Media -> MediaPage(apps)
                    Page.Phone -> PhonePage()
                    Page.Car -> CarPage(engine)
                    Page.AppConnect -> AppConnectPage(apps, prefs, onHome = { page = Page.Home })
                    Page.Apps -> AppsPage(apps)
                    Page.Settings -> SettingsPage(prefs, engine)
                    Page.Climate -> ClimatePage(prefs)
                    Page.Seats -> SeatsPage(prefs)
                    Page.Ambient -> AmbientPage(prefs)
                    Page.Parking, Page.Assist, Page.Experience, Page.Offroad -> FeaturePage(page)
                }
                engine.message?.let { m ->
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).padding(horizontal = 20.dp, vertical = 10.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
            }
            Box(Modifier.align(Alignment.TopCenter)) { TopBar(page, { page = it }, engine, prefs, amb) }
            Box(Modifier.align(Alignment.BottomCenter)) { BottomBar(prefs, page, amb, onPage = { page = it }) }
        }
    }
}

private val menuChildren = setOf(
    Page.Media, Page.Phone, Page.Car, Page.AppConnect, Page.Apps, Page.Settings, Page.Seats, Page.Ambient,
    Page.Parking, Page.Assist, Page.Experience, Page.Offroad, Page.Climate,
)

@Composable
private fun TopIcon(selected: Boolean, amb: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(if (selected) c.surface2 else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun TopBar(page: Page, onPage: (Page) -> Unit, engine: NavEngine, prefs: Prefs, amb: Color) {
    val c = LocalVw.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = if (prefs.b("clock24", true)) "H:mm" else "h:mm"
    val clock = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
    val imp = engine.imperial
    val w = engine.weather
    val temp = w?.let { if (imp) "${(it.tempC * 9 / 5 + 32).roundToInt()} °F" else "${it.tempC.roundToInt()} °C" } ?: "-- °${if (imp) "F" else "C"}"

    Box(Modifier.fillMaxWidth().height(46.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.7f), Color.Transparent))).padding(horizontal = 12.dp)) {
        Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TopIcon(page == Page.Menu, amb, { onPage(Page.Menu) }) { Icon(Icons.Rounded.Apps, "Menu", tint = amb, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Car, amb, { onPage(Page.Car) }) { Icon(Icons.Rounded.DirectionsCar, "Vehicle", tint = c.text, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Media, amb, { onPage(Page.Media) }) { Icon(Icons.Rounded.MusicNote, "Media", tint = MediaRed, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Nav, amb, { onPage(Page.Nav) }) { Icon(Icons.Rounded.Navigation, "Navigation", tint = NavBlue, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Ambient, amb, { onPage(Page.Ambient) }) { AmbientGlyph(Modifier.size(22.dp)) }
            TopIcon(page == Page.Seats, amb, { onPage(Page.Seats) }) { Icon(Icons.Rounded.EventSeat, "Seats", tint = PhoneGreen, modifier = Modifier.size(24.dp)) }
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(26.dp).height(2.dp).background(c.sub))
            Text(temp, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 3.dp))
        }
        Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
            if (engine.fix != null) Icon(Icons.Rounded.Place, null, tint = c.text, modifier = Modifier.size(16.dp))
            Text(clock, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp, end = 4.dp))
        }
    }
}
