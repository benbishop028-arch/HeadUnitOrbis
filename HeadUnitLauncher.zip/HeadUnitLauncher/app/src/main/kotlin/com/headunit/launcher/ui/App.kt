package com.headunit.launcher.ui

import android.content.Context
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import com.headunit.launcher.Weather
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class Page(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Rounded.Home),
    Nav("Navigation", Icons.Rounded.Navigation),
    Media("Media", Icons.Rounded.MusicNote),
    Phone("Phone", Icons.Rounded.Phone),
    Car("Vehicle", Icons.Rounded.DirectionsCar),
    Apps("Apps", Icons.Rounded.Apps),
    Settings("Settings", Icons.Rounded.Settings),
}

@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo) {
    val dark = resolveDark(prefs.s("theme", "auto"))
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    LaunchedEffect(dark, style, traffic, key) { engine.applyStyle(dark) }
    LaunchedEffect(Unit) { apps.refresh() }

    VwTheme(dark) {
        val c = LocalVw.current
        var page by rememberSaveable { mutableStateOf(Page.Home) }
        BackHandler(enabled = page != Page.Home) { page = Page.Home }

        Column(Modifier.fillMaxSize().background(c.bg)) {
            TopBar(page, { page = it }, engine, prefs)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (page) {
                    Page.Home -> HomePage(prefs, engine, map, apps, onOpen = { page = it })
                    Page.Nav -> NavPage(engine, map)
                    Page.Media -> MediaPage(apps)
                    Page.Phone -> PhonePage()
                    Page.Car -> CarPage(engine)
                    Page.Apps -> AppsPage(apps)
                    Page.Settings -> SettingsPage(prefs, engine)
                }
                engine.message?.let { m ->
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).padding(horizontal = 20.dp, vertical = 10.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
            }
            ClimateBar(prefs)
        }
    }
}

@Composable
fun TopBar(page: Page, onPage: (Page) -> Unit, engine: NavEngine, prefs: Prefs) {
    val c = LocalVw.current
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = if (prefs.b("clock24", true)) "HH:mm" else "h:mm a"
    val clock = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
    val w = engine.weather
    val temp = w?.let {
        if (engine.imperial) "${(it.tempC * 9 / 5 + 32).roundToInt()}°F" else "${it.tempC.roundToInt()}°C"
    } ?: "--°"

    var vol by remember { mutableStateOf(-1) }
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    LaunchedEffect(Unit) { while (true) { vol = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); delay(1500) } }

    Row(
        Modifier.fillMaxWidth().height(56.dp).background(c.bg).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.width(110.dp)) {
            Text(clock, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Page.values().forEach { p ->
                val sel = p == page
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp)).clickable { onPage(p) }.padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(p.icon, p.label, tint = if (sel) c.accent else c.sub, modifier = Modifier.size(26.dp))
                    Box(Modifier.padding(top = 2.dp).height(3.dp).width(if (sel) 26.dp else 0.dp).clip(RoundedCornerShape(2.dp)).background(c.accent))
                }
            }
        }
        Row(Modifier.width(230.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            Text(temp, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.width(14.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(c.surface2)
                    .clickable {
                        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    }.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) { Text("–", color = c.text, fontSize = 20.sp) }
            Box(Modifier.width(6.dp))
            Icon(Icons.Rounded.VolumeUp, null, tint = c.text, modifier = Modifier.size(22.dp))
            Text(if (vol >= 0) "$vol" else "", color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(c.surface2)
                    .clickable {
                        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    }.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) { Text("+", color = c.text, fontSize = 20.sp) }
        }
    }
}
