package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.Launch
import com.headunit.launcher.MapBinding
import com.headunit.launcher.MediaHelper
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class Page(val label: String) {
    Home("Home"), Menu("Menu"), Nav("Navigation"), Media("Radio/Media"), Phone("Telephone"),
    AppConnect("App-Connect"), Apps("Apps"), Settings("Settings"), Ambient("Ambient light"),
    Weather("Weather"), Calendar("Calendar"), Clock("Clock"), Trips("Trips"), CarLog("Car log"),
    Drive("Drive computer"), SmartHome("Smart home"), DashCam("Dash cam"), Discover("Discover"), MapSettings("Map settings"),
}

private fun findActivity(c: android.content.Context): android.app.Activity? {
    var x: android.content.Context = c
    while (x is android.content.ContextWrapper) {
        if (x is android.app.Activity) return x
        x = x.baseContext
    }
    return null
}

fun ambientOf(prefs: Prefs): Color = AmbientColors[prefs.i("amb", 0).coerceIn(0, AmbientColors.lastIndex)]

internal fun artColor(img: androidx.compose.ui.graphics.ImageBitmap): Color? = try {
    val bmp = android.graphics.Bitmap.createScaledBitmap(img.asAndroidBitmap(), 24, 24, true)
    val w = FloatArray(12); val r = FloatArray(12); val g = FloatArray(12); val b = FloatArray(12)
    val hsv = FloatArray(3)
    for (x in 0 until 24) for (y in 0 until 24) {
        val px = bmp.getPixel(x, y)
        android.graphics.Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.25f || hsv[2] < 0.25f) continue
        val k = (hsv[0] / 30f).toInt().coerceIn(0, 11)
        val wt = hsv[1] * hsv[2]
        w[k] += wt; r[k] += android.graphics.Color.red(px) * wt; g[k] += android.graphics.Color.green(px) * wt; b[k] += android.graphics.Color.blue(px) * wt
    }
    val best = (0 until 12).maxByOrNull { w[it] } ?: 0
    if (w[best] < 0.6f) null else {
        android.graphics.Color.RGBToHSV((r[best] / w[best]).toInt(), (g[best] / w[best]).toInt(), (b[best] / w[best]).toInt(), hsv)
        hsv[1] = maxOf(hsv[1], 0.6f); hsv[2] = maxOf(hsv[2], 0.85f)
        Color(android.graphics.Color.HSVToColor(hsv))
    }
} catch (e: Exception) { null }

@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        delay(6000)
        try {
            val due = com.headunit.launcher.ServiceStore(prefs).dueSoon()
            if (due != null) engine.toast(due, 8000)
        } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = System.currentTimeMillis() } }
    val dark = resolveDark(prefs.s("theme", "auto"), prefs.s("lastlat", "").toDoubleOrNull(), prefs.s("lastlon", "").toDoubleOrNull(), nowMs)

    // screen brightness (per window, no permission needed) incl. dimming at night
    val bright = prefs.i("bright", 100)
    val dimNight = prefs.b("dimnight", false)
    val hostCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(bright, dimNight, dark) {
        val win = findActivity(hostCtx)?.window ?: return@LaunchedEffect
        val dim = dimNight && dark
        val v = if (bright >= 100 && !dim) -1f else (bright / 100f * (if (dim) 0.5f else 1f)).coerceIn(0.03f, 1f)
        val lp = win.attributes
        lp.screenBrightness = v
        win.attributes = lp
    }
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    val gkey = prefs.s("gkey", "")
    val mapTheme = prefs.s("maptheme", "immersive")
    LaunchedEffect(mapTheme) { map.setTheme(mapTheme) }
    val mapFps = prefs.s("mapfps", "45").toIntOrNull() ?: 45
    LaunchedEffect(mapFps) { map.setMaxFps(mapFps) }
    val arrowPct = prefs.s("arrowpct", "240").toIntOrNull() ?: 240
    LaunchedEffect(arrowPct) { map.setArrowScale(arrowPct / 100f) }
    LaunchedEffect(dark, style, traffic, key, gkey) { engine.applyStyle(dark) }
    LaunchedEffect(Unit) { apps.refresh() }
    val sat = prefs.b("satellite", false)
    val b3d = prefs.b("buildings3d", true)
    LaunchedEffect(sat, b3d) { map.setView(sat, b3d) }

    val scale = prefs.i("uiscale", 100).coerceIn(60, 140) / 100f
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density * scale, baseDensity.fontScale),
    ) {
    MediaHelper.preferred = prefs.s("mediasrc", "")
    VwTheme(dark, prefs.i(if (dark) "nightlook" else "daylook", 0), prefs.i(if (dark) "nightbg" else "daybg", 0), prefs.i(if (dark) "nightaccent" else "dayaccent", 0)) {
        val c = LocalVw.current
        val baseAmb = ambientOf(prefs)
        // reactive ambient light: the glow changes colour and pulses when something needs attention
        val react = prefs.b("ambreact", true)
        fun evOn(id: String) = prefs.b("ambe_$id", true)
        fun evCol(id: String, def: Int) = AmbientColors[prefs.i("ambc_$id", def).coerceIn(0, AmbientColors.lastIndex)]
        val audio = remember { hostCtx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
        val ringing by androidx.compose.runtime.produceState(false) {
            while (true) { value = try { audio.mode == android.media.AudioManager.MODE_RINGTONE } catch (e: Exception) { false }; delay(700) }
        }
        val media = rememberMedia()
        val artCol = remember(media?.art) { media?.art?.let { artColor(it) } }
        val turnSoon by remember { derivedStateOf { engine.route != null && !engine.previewing && (engine.turn?.dist ?: 1e9) < 150.0 } }
        // Alerts light the glow for a few seconds when they start, then it returns to your colour
        // until the next alert. activeEv is the alert currently showing.
        var activeEv by remember { mutableStateOf<String?>(null) }
        val lastFire = remember { HashMap<String, Long>() }
        fun alertEffect(cond: Boolean, id: String, showMs: Long, cooldownMs: Long): suspend () -> Unit = {
            val now = System.currentTimeMillis()
            if (react && cond && evOn(id) && now - (lastFire[id] ?: 0L) > cooldownMs) {
                lastFire[id] = now
                try { activeEv = id; delay(showMs) } finally { if (activeEv == id) activeEv = null }
            }
        }
        val brakeNow = engine.brakeFlash
        val overNow = engine.overLimit
        val camNow by remember { derivedStateOf { engine.cameraDist != null } }
        val incNow by remember { derivedStateOf { engine.incidentAhead != null } }
        val arriveNow = engine.arriveFlash
        LaunchedEffect(brakeNow, react) { alertEffect(brakeNow, "brake", 1500, 3000)() }
        LaunchedEffect(ringing, react) { alertEffect(ringing, "call", 5000, 0)() }
        LaunchedEffect(overNow, react) { alertEffect(overNow, "over", 5000, 30_000)() }
        LaunchedEffect(camNow, react) { alertEffect(camNow, "camera", 5000, 8000)() }
        LaunchedEffect(incNow, react) { alertEffect(incNow, "incident", 5000, 20_000)() }
        LaunchedEffect(turnSoon, react) { alertEffect(turnSoon, "turn", 5000, 4000)() }
        LaunchedEffect(arriveNow, react) { alertEffect(arriveNow, "arrive", 5000, 0)() }
        // kind: 0 none, 1 strong pulse, 2 soft pulse, 3 slow breathing, 4 steady flash
        var kind = 0
        var target = baseAmb
        if (react) when {
            activeEv == "brake" -> { target = evCol("brake", 2); kind = 4 }
            activeEv == "call" -> { target = evCol("call", 0); kind = 1 }
            activeEv == "over" -> { target = evCol("over", 2); kind = 1 }
            activeEv == "camera" -> { target = evCol("camera", 3); kind = 1 }
            activeEv == "incident" -> { target = evCol("incident", 3); kind = 1 }
            activeEv == "turn" -> { target = evCol("turn", 1); kind = 2 }
            activeEv == "arrive" -> { target = evCol("arrive", 0); kind = 3 }
            media?.playing == true && artCol != null && evOn("music") -> { target = artCol; kind = 3 }
        }
        val amb by androidx.compose.animation.animateColorAsState(target, androidx.compose.animation.core.tween(if (kind == 4) 120 else 600), label = "ambReact")
        val pulsing = prefs.b("ambpulse", true)
        val ambOn = prefs.b("ambon", true)
        // the pulses only run while the glow is actually reacting, and are read while drawing so the screen never recomposes for them
        val pulseS = rememberPulse(pulsing && (kind == 1 || kind == 2), 650)
        val breathS = rememberPulse(pulsing && kind == 3, 3200)
        val intensity = prefs.i("ambint", 100).coerceIn(40, 160) / 100f
        val glowKind = kind
        val boostOf: () -> Float = {
            intensity * when (glowKind) {
                1 -> if (pulsing) 1.1f + 1.0f * pulseS.value else 1.7f
                2 -> if (pulsing) 1.0f + 0.5f * pulseS.value else 1.3f
                3 -> if (pulsing) 1.1f + 0.45f * breathS.value else 1.3f
                4 -> 2.2f
                else -> 1f
            }
        }
        var page by rememberSaveable { mutableStateOf(Page.Home) }
        // moving faster than about 5 mph switches the Home screen to the full-screen map (once per drive, so you can still go back to Home)
        LaunchedEffect(Unit) {
            var armed = true
            var slowSince = 0L
            var fastSince = 0L
            while (true) {
                delay(1000)
                val sp = engine.fix?.speed ?: 0.0
                val now = System.currentTimeMillis()
                if (sp < 1.0) { fastSince = 0L; if (slowSince == 0L) slowSince = now else if (now - slowSince > 20_000) armed = true }
                else slowSince = 0L
                if (sp > 2.3) { if (fastSince == 0L) fastSince = now } else if (sp < 1.5) fastSince = 0L
                if (armed && fastSince != 0L && now - fastSince > 3000 && prefs.b("autofull", true) && page == Page.Home) { page = Page.Nav; armed = false }
            }
        }
        BackHandler(enabled = page != Page.Home) { page = if (page == Page.Menu) Page.Home else Page.Menu.takeIf { page in menuChildren } ?: Page.Home }

        // very slow drift of the ambient light (a full sweep takes minutes, so it is barely noticeable)
        // (updated once a second instead of every frame: the motion is far too slow to need more)
        var d1 by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
        var d2 by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
        LaunchedEffect(Unit) {
            fun wave(x: Float): Float { val f = x % 2f; val t = if (f < 1f) f else 2f - f; return t * t * (3f - 2f * t) }
            val t0 = android.os.SystemClock.elapsedRealtime()
            while (true) {
                val sec = (android.os.SystemClock.elapsedRealtime() - t0) / 1000f
                d1 = wave(sec / 150f); d2 = wave(sec / 210f)
                delay(1000)
            }
        }
        var lastTouch by remember { mutableStateOf(System.currentTimeMillis()) }
        var saver by remember { mutableStateOf(false) }
        var quick by remember { mutableStateOf(false) }
        var locked by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(5000)
                val parked = (engine.fix?.speed ?: 0.0) < 1.0
                val playing = MediaPoll.info?.playing == true
                saver = prefs.b("screensaver", true) && parked && engine.route == null && !playing && System.currentTimeMillis() - lastTouch > 300_000
            }
        }
        Box(
            Modifier.fillMaxSize().then(
                if (c.dark) Modifier.background(c.bg)
                else Modifier.background(Brush.linearGradient(listOf(
                    androidx.compose.ui.graphics.lerp(c.bg, Color(0xFFFFFFFF), 0.42f), c.bg, androidx.compose.ui.graphics.lerp(c.bg, Color(0xFF7E95BA), 0.30f),
                )))
            ).pointerInput(Unit) {
                awaitPointerEventScope { while (true) { awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial); lastTouch = System.currentTimeMillis() } }
            }.drawBehind {
                val boost = boostOf()
                if (!ambOn) return@drawBehind
                // ambient light bleeding in from the edges, like the green glow in the car
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, amb.copy(alpha = ((if (c.dark) 0.24f else 0.14f) * boost).coerceAtMost(0.7f))), startY = size.height * (0.52f + 0.08f * d2)))
                drawRect(Brush.horizontalGradient(listOf(amb.copy(alpha = ((if (c.dark) 0.20f else 0.10f) * boost).coerceAtMost(0.6f)), Color.Transparent), endX = size.width * (0.14f + 0.08f * d1)))
                // a soft pool of light that wanders along the bottom edge
                val cx = size.width * (0.15f + 0.70f * d1)
                drawRect(Brush.radialGradient(
                    listOf(amb.copy(alpha = ((if (c.dark) 0.16f else 0.09f) * boost).coerceAtMost(0.5f)), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(cx, size.height * (1.02f - 0.06f * d2)), radius = size.width * 0.42f))
            },
        ) {
            // pages other than the map fade and rise in; the map pages are left alone so the native map view is never faded
            var shown by remember(page) { mutableStateOf(false) }
            LaunchedEffect(page) { shown = true }
            val enterA by androidx.compose.animation.core.animateFloatAsState(if (shown) 1f else 0f, androidx.compose.animation.core.tween(240), label = "pageIn")
            val animate = page != Page.Home && page != Page.Nav
            Box(
                Modifier.fillMaxSize().padding(top = 58.dp, bottom = 78.dp)
                    .then(if (animate) Modifier.graphicsLayer { alpha = enterA; translationY = (1f - enterA) * 14f; val sc = 0.985f + 0.015f * enterA; scaleX = sc; scaleY = sc } else Modifier),
            ) {
                when (page) {
                    Page.Home, Page.Nav -> HomePage(prefs, engine, map, apps, nav = page == Page.Nav, onOpen = { page = it })
                    Page.Menu -> MenuPage(prefs, amb, onOpen = { page = it })
                    Page.Media -> MediaPage(apps, prefs)
                    Page.Phone -> PhonePage()
                    Page.AppConnect -> AppsPage(apps, prefs, onHome = { page = Page.Home })
                    Page.Apps -> AppsPage(apps, prefs, onHome = { page = Page.Home })
                    Page.Settings -> SettingsPage(prefs, engine, apps)
                    Page.Ambient -> AmbientPage(prefs)
                    Page.Weather -> WeatherPage(engine, prefs)
                    Page.Calendar -> CalendarPage(engine, onOpen = { page = it })
                    Page.Clock -> ClockPage(prefs)
                    Page.Trips -> TripsPage(engine)
                    Page.CarLog -> CarLogPage(engine)
                    Page.Drive -> DrivePage(engine)
                    Page.SmartHome -> SmartHomePage(engine)
                    Page.DashCam -> DashCamPage()
                    Page.Discover -> DiscoverPage(engine, prefs, onOpen = { page = it })
                    Page.MapSettings -> MapSettingsPage(prefs, engine)
                }
                // quick settings expand into the music widget's spot on the right, whichever screen is showing, and fold away again after a few seconds
                androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
                    val gap = 14.dp
                    val mapW = (maxWidth - gap * 3) * (2.15f / 3.15f)
                    val colX = gap * 2 + mapW
                    androidx.compose.animation.AnimatedVisibility(
                        visible = quick,
                        modifier = Modifier.offset(colX, 2.dp).width(maxWidth - colX - gap),
                        enter = androidx.compose.animation.expandVertically(expandFrom = Alignment.Top) + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.shrinkVertically(shrinkTowards = Alignment.Top) + androidx.compose.animation.fadeOut(),
                    ) {
                        QuickPanel(prefs, Modifier.fillMaxWidth().height(maxHeight - 2.dp), onClose = { quick = false }, onLock = { quick = false; locked = true })
                    }
                }
                engine.message?.let { m ->
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(50)).padding(horizontal = 22.dp, vertical = 11.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
                // alerts (camera, speed limit, incident, rain, break) get a large banner that is hard to miss
                val curAlert = engine.alert
                val lastAlert = remember { mutableStateOf(curAlert) }
                if (curAlert != null) lastAlert.value = curAlert
                androidx.compose.animation.AnimatedVisibility(
                    visible = curAlert != null,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp),
                    enter = androidx.compose.animation.slideInVertically(initialOffsetY = { -it }) + androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { -it }) + androidx.compose.animation.fadeOut(),
                ) { lastAlert.value?.let { AlertBanner(it) } }
            }
            Box(Modifier.align(Alignment.TopCenter)) { TopBar(page, { page = it }, engine, prefs, amb, apps, onQuick = { quick = !quick }) }
            Box(Modifier.align(Alignment.BottomCenter)) { BottomBar(prefs, page, if (ambOn) amb else c.onBgSub, engine, apps, onPage = { page = it }) }
            if (saver) Screensaver(onDismiss = { saver = false; lastTouch = System.currentTimeMillis() })
            if (locked) LockScreen(prefs, onUnlock = { locked = false })
        }
    }
    }
}

private val menuChildren = setOf(
    Page.Media, Page.Phone, Page.AppConnect, Page.Apps, Page.Settings, Page.Ambient, Page.Weather, Page.Calendar, Page.Clock, Page.Trips, Page.CarLog,
    Page.Drive, Page.SmartHome, Page.DashCam, Page.Discover, Page.MapSettings,
)

@Composable
private fun TopIcon(selected: Boolean, amb: Color, onClick: () -> Unit, onLong: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Box(
        (if (onLong == null) Modifier.pressClick(onClick) else Modifier.pointerInput(Unit) { androidx.compose.foundation.gestures.detectTapGestures(onLongPress = { onLong() }, onTap = { onClick() }) }).width(64.dp).height(52.dp).clip(RoundedCornerShape(18.dp)).background(if (selected) c.onBg.copy(alpha = 0.12f) else Color.Transparent),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun TopDivider() {
    val c = LocalVw.current
    Box(Modifier.width(1.dp).height(28.dp).background(c.onBgSub.copy(alpha = 0.22f)))
}

@Composable
fun TopBar(page: Page, onPage: (Page) -> Unit, engine: NavEngine, prefs: Prefs, amb: Color, apps: AppsRepo, onQuick: () -> Unit = {}) {
    val c = LocalVw.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var chooseAuto by remember { mutableStateOf(false) }
    val autoPkg = prefs.s("autoapp", "")
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = if (prefs.b("clock24", true)) "H:mm" else "h:mm"
    val clock = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
    val imp = isImperial(prefs)
    val w = engine.weather
    val temp = w?.let { if (imp) "${(it.tempC * 9 / 5 + 32).roundToInt()} °F" else "${it.tempC.roundToInt()} °C" } ?: "-- °${if (imp) "F" else "C"}"

    if (chooseAuto) AppPickerDialog(apps, "Choose the app that connects your phone", { prefs.put("autoapp", it.pkg); chooseAuto = false; Launch.app(ctx, it.pkg) }, { chooseAuto = false })
    Box(Modifier.fillMaxWidth().height(58.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.7f), Color.Transparent))).padding(horizontal = 12.dp)) {
        Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            TopIcon(page == Page.Menu, amb, { onPage(Page.Menu) }) { Icon(Icons.Rounded.GridView, "Menu", tint = if (kotlin.math.abs(amb.luminance() - c.bg.luminance()) > 0.3f) amb else c.onBg, modifier = Modifier.size(34.dp)) }
            TopDivider()
            TopIcon(page == Page.Media, amb, { onPage(Page.Media) }) { Icon(Icons.Rounded.GraphicEq, "Media", tint = MediaRed, modifier = Modifier.size(34.dp)) }
            TopDivider()
            TopIcon(page == Page.Phone, amb, { onPage(Page.Phone) }) { Icon(Icons.Rounded.Call, "Phone", tint = PhoneGreen, modifier = Modifier.size(32.dp)) }
            TopDivider()
            TopIcon(page == Page.Nav, amb, { onPage(Page.Nav) }) { Icon(Icons.Rounded.NearMe, "Navigation", tint = NavBlue, modifier = Modifier.size(32.dp)) }
            TopDivider()
            TopIcon(page == Page.Ambient, amb, { onPage(Page.Ambient) }) { AmbientGlyph(Modifier.size(30.dp)) }
            TopDivider()
            // phone projection (Android Auto etc.): the first press asks which app to open, a long press changes it
            TopIcon(false, amb, { if (autoPkg.isBlank() || !Launch.app(ctx, autoPkg)) chooseAuto = true }, onLong = { chooseAuto = true }) {
                val style = prefs.s("autoicon", "app")
                val teal = Color(0xFF2DD4BF)
                val appIcon = if (autoPkg.isBlank()) null else apps.find(autoPkg)?.icon
                val custom = remember(prefs.s("autoiconv", "0")) {
                    try { android.graphics.BitmapFactory.decodeFile(java.io.File(ctx.filesDir, "proj_icon.png").path)?.asImageBitmap() } catch (e: Exception) { null }
                }
                when {
                    style == "custom" && custom != null -> androidx.compose.foundation.Image(custom, "Phone projection", modifier = Modifier.size(36.dp))
                    style == "road" || style == "link" -> ProjectionGlyph(style, teal, Modifier.size(34.dp))
                    style == "app" && appIcon != null -> androidx.compose.foundation.Image(appIcon, "Phone projection", modifier = Modifier.size(36.dp))
                    else -> Icon(Icons.Rounded.DirectionsCar, "Phone projection", tint = teal, modifier = Modifier.size(34.dp))
                }
            }
        }
        Row(Modifier.align(Alignment.Center).clip(RoundedCornerShape(20.dp)).pressClick { onPage(Page.Weather) }.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (w != null) Icon(wxIcon(w.code), null, tint = wxTint(w.code), modifier = Modifier.size(22.dp))
            Text(temp, color = c.onBg, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        }
        Row(Modifier.align(Alignment.CenterEnd).clip(RoundedCornerShape(24.dp)).pressClick(onQuick).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusIcons()
            Box(Modifier.width(12.dp))
            if (engine.fix != null) Icon(Icons.Rounded.Place, null, tint = c.onBg, modifier = Modifier.size(16.dp))
            Text(clock, color = c.onBg, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp, end = 4.dp))
        }
    }
}
