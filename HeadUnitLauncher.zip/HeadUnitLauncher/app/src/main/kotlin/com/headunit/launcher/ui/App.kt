package com.headunit.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.EventSeat
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.headunit.launcher.AppsRepo
import com.headunit.launcher.MapBinding
import com.headunit.launcher.NavEngine
import com.headunit.launcher.Prefs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class Page(val label: String) {
    Home("Home"), Menu("Menu"), Nav("Navigation"), Media("Radio/Media"), Phone("Telephone"),
    AppConnect("App-Connect"), Apps("Apps"), Settings("Settings"), Ambient("Ambient light"),
    Weather("Weather"), Calendar("Calendar"), Clock("Clock"), Trips("Trips"), CarLog("Car log"),
    Drive("Drive computer"), SmartHome("Smart home"), DashCam("Dash cam"), Discover("Discover"),
}

private fun findActivity(c: android.content.Context): android.app.Activity? {
    var x: android.content.Context = c
    while (x is android.content.ContextWrapper) {
        if (x is android.app.Activity) return x
        x = x.baseContext
    }
    return null
}

fun ambientOf(prefs: Prefs): Color = AmbientColors[prefs.i("amb", 0).coerceIn(0, AmbientColors.lastIndex)]

internal fun artColor(img: androidx.compose.ui.graphics.ImageBitmap): Color? = try {
    val bmp = android.graphics.Bitmap.createScaledBitmap(img.asAndroidBitmap(), 24, 24, true)
    val w = FloatArray(12); val r = FloatArray(12); val g = FloatArray(12); val b = FloatArray(12)
    val hsv = FloatArray(3)
    for (x in 0 until 24) for (y in 0 until 24) {
        val px = bmp.getPixel(x, y)
        android.graphics.Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.25f || hsv[2] < 0.25f) continue
        val k = (hsv[0] / 30f).toInt().coerceIn(0, 11)
        val wt = hsv[1] * hsv[2]
        w[k] += wt; r[k] += android.graphics.Color.red(px) * wt; g[k] += android.graphics.Color.green(px) * wt; b[k] += android.graphics.Color.blue(px) * wt
    }
    val best = (0 until 12).maxByOrNull { w[it] } ?: 0
    if (w[best] < 0.6f) null else {
        android.graphics.Color.RGBToHSV((r[best] / w[best]).toInt(), (g[best] / w[best]).toInt(), (b[best] / w[best]).toInt(), hsv)
        hsv[1] = maxOf(hsv[1], 0.6f); hsv[2] = maxOf(hsv[2], 0.85f)
        Color(android.graphics.Color.HSVToColor(hsv))
    }
} catch (e: Exception) { null }

@Composable
fun App(prefs: Prefs, engine: NavEngine, map: MapBinding, apps: AppsRepo) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        delay(6000)
        try {
            val due = com.headunit.launcher.ServiceStore(prefs).dueSoon()
            if (due != null) engine.toast(due, 8000)
        } catch (_: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = System.currentTimeMillis() } }
    val dark = resolveDark(prefs.s("theme", "auto"), prefs.s("lastlat", "").toDoubleOrNull(), prefs.s("lastlon", "").toDoubleOrNull(), nowMs)

    // screen brightness (per window, no permission needed) incl. dimming at night
    val bright = prefs.i("bright", 100)
    val dimNight = prefs.b("dimnight", false)
    val hostCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(bright, dimNight, dark) {
        val win = findActivity(hostCtx)?.window ?: return@LaunchedEffect
        val dim = dimNight && dark
        val v = if (bright >= 100 && !dim) -1f else (bright / 100f * (if (dim) 0.5f else 1f)).coerceIn(0.03f, 1f)
        val lp = win.attributes
        lp.screenBrightness = v
        win.attributes = lp
    }
    val style = prefs.s("mapstyle", "tomtom")
    val traffic = prefs.b("traffic", true)
    val key = prefs.s("apikey", "")
    LaunchedEffect(dark, style, traffic, key) { engine.applyStyle(dark) }
    LaunchedEffect(Unit) { apps.refresh() }
    val sat = prefs.b("satellite", false)
    val b3d = prefs.b("buildings3d", true)
    LaunchedEffect(sat, b3d) { map.setView(sat, b3d) }

    val scale = prefs.i("uiscale", 100).coerceIn(60, 140) / 100f
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density * scale, baseDensity.fontScale),
    ) {
    VwTheme(dark, prefs.i(if (dark) "nightlook" else "daylook", 0)) {
        val c = LocalVw.current
        val baseAmb = ambientOf(prefs)
        // reactive ambient light: the glow changes colour and pulses when something needs attention
        val react = prefs.b("ambreact", true)
        fun evOn(id: String) = prefs.b("ambe_$id", true)
        fun evCol(id: String, def: Int) = AmbientColors[prefs.i("ambc_$id", def).coerceIn(0, AmbientColors.lastIndex)]
        val audio = remember { hostCtx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
        val ringing by androidx.compose.runtime.produceState(false) {
            while (true) { value = try { audio.mode == android.media.AudioManager.MODE_RINGTONE } catch (e: Exception) { false }; delay(700) }
        }
        val media = rememberMedia()
        val artCol = remember(media?.art) { media?.art?.let { artColor(it) } }
        val turnSoon = engine.route != null && !engine.previewing && (engine.turn?.dist ?: 1e9) < 150.0
        // Alerts light the glow for a few seconds when they start, then it returns to your colour
        // until the next alert. activeEv is the alert currently showing.
        var activeEv by remember { mutableStateOf<String?>(null) }
        val lastFire = remember { HashMap<String, Long>() }
        fun alertEffect(cond: Boolean, id: String, showMs: Long, cooldownMs: Long): suspend () -> Unit = {
            val now = System.currentTimeMillis()
            if (react && cond && evOn(id) && now - (lastFire[id] ?: 0L) > cooldownMs) {
                lastFire[id] = now
                try { activeEv = id; delay(showMs) } finally { if (activeEv == id) activeEv = null }
            }
        }
        val brakeNow = engine.brakeFlash
        val overNow = engine.overLimit
        val camNow = engine.cameraDist != null
        val incNow = engine.incidentAhead != null
        val arriveNow = engine.arriveFlash
        LaunchedEffect(brakeNow, react) { alertEffect(brakeNow, "brake", 1500, 3000)() }
        LaunchedEffect(ringing, react) { alertEffect(ringing, "call", 5000, 0)() }
        LaunchedEffect(overNow, react) { alertEffect(overNow, "over", 5000, 30_000)() }
        LaunchedEffect(camNow, react) { alertEffect(camNow, "camera", 5000, 8000)() }
        LaunchedEffect(incNow, react) { alertEffect(incNow, "incident", 5000, 20_000)() }
        LaunchedEffect(turnSoon, react) { alertEffect(turnSoon, "turn", 5000, 4000)() }
        LaunchedEffect(arriveNow, react) { alertEffect(arriveNow, "arrive", 5000, 0)() }
        // kind: 0 none, 1 strong pulse, 2 soft pulse, 3 slow breathing, 4 steady flash
        var kind = 0
        var target = baseAmb
        if (react) when {
            activeEv == "brake" -> { target = evCol("brake", 2); kind = 4 }
            activeEv == "call" -> { target = evCol("call", 0); kind = 1 }
            activeEv == "over" -> { target = evCol("over", 2); kind = 1 }
            activeEv == "camera" -> { target = evCol("camera", 3); kind = 1 }
            activeEv == "incident" -> { target = evCol("incident", 3); kind = 1 }
            activeEv == "turn" -> { target = evCol("turn", 1); kind = 2 }
            activeEv == "arrive" -> { target = evCol("arrive", 0); kind = 3 }
            media?.playing == true && artCol != null && evOn("music") -> { target = artCol; kind = 3 }
        }
        val amb by androidx.compose.animation.animateColorAsState(target, androidx.compose.animation.core.tween(if (kind == 4) 120 else 600), label = "ambReact")
        val pulseT = androidx.compose.animation.core.rememberInfiniteTransition(label = "ambPulse")
        val pulseV by pulseT.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(650, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "pulse")
        val breathV by pulseT.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(3200, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "breath")
        val pulsing = prefs.b("ambpulse", true)
        val intensity = prefs.i("ambint", 100).coerceIn(40, 160) / 100f
        val boost = intensity * when (kind) {
            1 -> if (pulsing) 1.1f + 1.0f * pulseV else 1.7f
            2 -> if (pulsing) 1.0f + 0.5f * pulseV else 1.3f
            3 -> if (pulsing) 1.1f + 0.45f * breathV else 1.3f
            4 -> 2.2f
            else -> 1f
        }
        var page by rememberSaveable { mutableStateOf(Page.Home) }
        BackHandler(enabled = page != Page.Home) { page = if (page == Page.Menu) Page.Home else Page.Menu.takeIf { page in menuChildren } ?: Page.Home }

        // very slow drift of the ambient light (a full sweep takes minutes, so it is barely noticeable)
        val drift = androidx.compose.animation.core.rememberInfiniteTransition(label = "ambDrift")
        val d1 by drift.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(150_000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "d1")
        val d2 by drift.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(210_000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse), label = "d2")
        var lastTouch by remember { mutableStateOf(System.currentTimeMillis()) }
        var saver by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            while (true) {
                delay(5000)
                val parked = (engine.fix?.speed ?: 0.0) < 1.0
                val playing = try { com.headunit.launcher.MediaHelper.current(hostCtx)?.playing == true } catch (e: Exception) { false }
                saver = prefs.b("screensaver", true) && parked && engine.route == null && !playing && System.currentTimeMillis() - lastTouch > 300_000
            }
        }
        Box(
            Modifier.fillMaxSize().background(c.bg).pointerInput(Unit) {
                awaitPointerEventScope { while (true) { awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial); lastTouch = System.currentTimeMillis() } }
            }.drawBehind {
                // ambient light bleeding in from the edges, like the green glow in the car
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, amb.copy(alpha = ((if (c.dark) 0.24f else 0.14f) * boost).coerceAtMost(0.7f))), startY = size.height * (0.52f + 0.08f * d2)))
                drawRect(Brush.horizontalGradient(listOf(amb.copy(alpha = ((if (c.dark) 0.20f else 0.10f) * boost).coerceAtMost(0.6f)), Color.Transparent), endX = size.width * (0.14f + 0.08f * d1)))
                // a soft pool of light that wanders along the bottom edge
                val cx = size.width * (0.15f + 0.70f * d1)
                drawRect(Brush.radialGradient(
                    listOf(amb.copy(alpha = ((if (c.dark) 0.16f else 0.09f) * boost).coerceAtMost(0.5f)), Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(cx, size.height * (1.02f - 0.06f * d2)), radius = size.width * 0.42f))
            },
        ) {
            Box(Modifier.fillMaxSize().padding(top = 46.dp, bottom = 70.dp)) {
                when (page) {
                    Page.Home, Page.Nav -> HomePage(prefs, engine, map, apps, nav = page == Page.Nav, onOpen = { page = it })
                    Page.Menu -> MenuPage(prefs, amb, onOpen = { page = it })
                    Page.Media -> MediaPage(apps)
                    Page.Phone -> PhonePage()
                    Page.AppConnect -> AppConnectPage(apps, prefs, onHome = { page = Page.Home })
                    Page.Apps -> AppsPage(apps)
                    Page.Settings -> SettingsPage(prefs, engine, apps)
                    Page.Ambient -> AmbientPage(prefs)
                    Page.Weather -> WeatherPage(engine, prefs)
                    Page.Calendar -> CalendarPage(engine, onOpen = { page = it })
                    Page.Clock -> ClockPage(prefs)
                    Page.Trips -> TripsPage(engine)
                    Page.CarLog -> CarLogPage(engine)
                    Page.Drive -> DrivePage(engine)
                    Page.SmartHome -> SmartHomePage(engine)
                    Page.DashCam -> DashCamPage()
                    Page.Discover -> DiscoverPage(engine, prefs, onOpen = { page = it })
                }
                engine.message?.let { m ->
                    Box(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6101820)).padding(horizontal = 20.dp, vertical = 10.dp),
                    ) { Text(m, color = Color.White, fontSize = 15.sp) }
                }
            }
            Box(Modifier.align(Alignment.TopCenter)) { TopBar(page, { page = it }, engine, prefs, amb) }
            Box(Modifier.align(Alignment.BottomCenter)) { BottomBar(prefs, page, amb, engine, apps, onPage = { page = it }) }
            if (saver) Screensaver(onDismiss = { saver = false; lastTouch = System.currentTimeMillis() })
        }
    }
    }
}

private val menuChildren = setOf(
    Page.Media, Page.Phone, Page.AppConnect, Page.Apps, Page.Settings, Page.Ambient, Page.Weather, Page.Calendar, Page.Clock, Page.Trips, Page.CarLog,
    Page.Drive, Page.SmartHome, Page.DashCam, Page.Discover,
)

@Composable
private fun TopIcon(selected: Boolean, amb: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    val c = LocalVw.current
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(if (selected) c.surface2 else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun TopBar(page: Page, onPage: (Page) -> Unit, engine: NavEngine, prefs: Prefs, amb: Color) {
    val c = LocalVw.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val fmt = if (prefs.b("clock24", true)) "H:mm" else "h:mm"
    val clock = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
    val imp = isImperial(prefs)
    val w = engine.weather
    val temp = w?.let { if (imp) "${(it.tempC * 9 / 5 + 32).roundToInt()} °F" else "${it.tempC.roundToInt()} °C" } ?: "-- °${if (imp) "F" else "C"}"

    Box(Modifier.fillMaxWidth().height(46.dp).background(Brush.verticalGradient(listOf(c.bg.copy(alpha = 0.7f), Color.Transparent))).padding(horizontal = 12.dp)) {
        Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TopIcon(page == Page.Menu, amb, { onPage(Page.Menu) }) { Icon(Icons.Rounded.Apps, "Menu", tint = amb, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Media, amb, { onPage(Page.Media) }) { Icon(Icons.Rounded.MusicNote, "Media", tint = MediaRed, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Nav, amb, { onPage(Page.Nav) }) { Icon(Icons.Rounded.Navigation, "Navigation", tint = NavBlue, modifier = Modifier.size(24.dp)) }
            TopIcon(page == Page.Ambient, amb, { onPage(Page.Ambient) }) { AmbientGlyph(Modifier.size(22.dp)) }
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(26.dp).height(2.dp).background(c.sub))
            Text(temp, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 3.dp))
        }
        Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
            if (engine.fix != null) Icon(Icons.Rounded.Place, null, tint = c.text, modifier = Modifier.size(16.dp))
            Text(clock, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp, end = 4.dp))
        }
    }
}
