package com.headunit.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.headunit.launcher.Sun

data class Vw(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color,
    val text: Color, val sub: Color, val accent: Color, val line: Color,
    val panel: Color, val tile: Color,
    /** Text colours for things drawn straight on the background, so they stay readable when the background colour is overridden. */
    val onBg: Color = text, val onBgSub: Color = sub,
    /** Wash laid over the map so it matches non-default looks. */
    val mapTint: Color = Color.Transparent,
)

val DarkVw = Vw(true, Color(0xFF08090B), Color(0xFF232326), Color(0xFF303034), Color(0xFFF4F5F7), Color(0xFF9A9AA3), Color(0xFF3FA9F5), Color(0xFF3C3C41), Color(0xFF2A2A2D), Color(0xFF151517))
val LightVw = Vw(false, Color(0xFFB0B8C8), Color(0xFFE6E9F0), Color(0xFFD9DDE7), Color(0xFF14171C), Color(0xFF59616D), Color(0xFF0B79D0), Color(0xFFBCC2CB), Color(0xFFD9DDE3), Color(0xFFE8EBEF))

/** Selectable looks for day and night. Index 0 is the default. */
val DayLooks: List<Pair<String, Vw>> = listOf(
    "Soft grey" to LightVw,
    "Warm sand" to Vw(false, Color(0xFFB3A99D), Color(0xFFE6E1DA), Color(0xFFD9D3CA), Color(0xFF1F1A14), Color(0xFF675F55), Color(0xFFC2651A), Color(0xFFC3BCB1), Color(0xFFDED8CF), Color(0xFFEDE9E3)),
    "Cool blue" to Vw(false, Color(0xFF93A8BE), Color(0xFFDEE6EF), Color(0xFFD0DBE6), Color(0xFF111A24), Color(0xFF54647A), Color(0xFF0B79D0), Color(0xFFB7C5D4), Color(0xFFD5DEE8), Color(0xFFE6ECF3)),
    "Graphite" to Vw(false, Color(0xFF878B92), Color(0xFFD6D8DB), Color(0xFFC8CACE), Color(0xFF14171C), Color(0xFF555A62), Color(0xFF0B79D0), Color(0xFFB0B3B8), Color(0xFFCDD0D4), Color(0xFFDFE1E4)),
)

val NightLooks: List<Pair<String, Vw>> = listOf(
    "Black" to DarkVw,
    "Midnight" to Vw(true, Color(0xFF060B16), Color(0xFF1B2233), Color(0xFF262F44), Color(0xFFF4F5F7), Color(0xFF98A2B8), Color(0xFF4DA3FF), Color(0xFF313B52), Color(0xFF1F2740), Color(0xFF0F1526)),
    "Charcoal" to Vw(true, Color(0xFF121212), Color(0xFF2B2B2B), Color(0xFF363636), Color(0xFFF4F5F7), Color(0xFFA0A0A6), Color(0xFF3FA9F5), Color(0xFF454545), Color(0xFF303030), Color(0xFF1B1B1B)),
    "Forest" to Vw(true, Color(0xFF06100C), Color(0xFF1A2620), Color(0xFF24342B), Color(0xFFF2F7F4), Color(0xFF94A89D), Color(0xFF34C77B), Color(0xFF2F4439), Color(0xFF1F2D26), Color(0xFF101A15)),
    "Amber" to Vw(true, Color(0xFF100B06), Color(0xFF2A221A), Color(0xFF372D22), Color(0xFFF7F3EE), Color(0xFFA89C8E), Color(0xFFFFA726), Color(0xFF453A2C), Color(0xFF2F261C), Color(0xFF1A140D)),
)
/** Background-only colour choices. Index 0 keeps the look's own background. */
val BgChoices: List<Pair<String, Color?>> = listOf(
    "Default" to null, "Black" to Color(0xFF000000), "Dark grey" to Color(0xFF1A1C20), "Navy" to Color(0xFF0A1220),
    "Grey" to Color(0xFF878B92), "Light grey" to Color(0xFFB4B9C1), "Silver" to Color(0xFFD3D6DB), "White" to Color(0xFFFFFFFF),
)

val LocalVw = staticCompositionLocalOf { DarkVw }

val Blue = Color(0xFF2A3647)
val BlueSoft = Color(0xFF364559)
val Good = Color(0xFF34C759)
val Warn = Color(0xFFFFB020)
val Bad = Color(0xFFFF4D4D)

@Composable
fun resolveDark(mode: String, lat: Double?, lon: Double?, nowMs: Long): Boolean {
    val system = isSystemInDarkTheme()
    return when (mode) {
        "day" -> false
        "night" -> true
        "sun" -> if (lat != null && lon != null) !Sun.isDay(lat, lon, nowMs) else system
        else -> system
    }
}

/** Highlight colour choices. Index 0 keeps the look's own accent. */
val AccentChoices: List<Pair<String, Color?>> = listOf(
    "Default" to null, "Blue" to Color(0xFF2F8CFF), "Teal" to Color(0xFF10A99A), "Green" to Color(0xFF22B35E), "Amber" to Color(0xFFF59E0B),
    "Orange" to Color(0xFFF26B21), "Red" to Color(0xFFE5484D), "Pink" to Color(0xFFE5539B), "Purple" to Color(0xFF8E5CF0),
)

@Composable
fun VwTheme(dark: Boolean, look: Int = 0, bgChoice: Int = 0, accentChoice: Int = 0, content: @Composable () -> Unit) {
    val looks = if (dark) NightLooks else DayLooks
    val li = look.coerceIn(0, looks.lastIndex)
    var v = looks[li].second
    val bgc = BgChoices[bgChoice.coerceIn(0, BgChoices.lastIndex)].second
    if (bgc != null) v = v.copy(bg = bgc)
    // text that sits directly on the background (bottom bar, top bar) always takes whichever of white or near-black reads best
    run {
        fun cr(a: Color, b: Color): Float {
            val la = a.luminance() + 0.05f; val lb = b.luminance() + 0.05f
            return kotlin.math.max(la, lb) / kotlin.math.min(la, lb)
        }
        val white = Color(0xFFFFFFFF); val black = Color(0xFF0B0D10)
        val on = if (cr(white, v.bg) >= cr(black, v.bg)) white else black
        var sub = androidx.compose.ui.graphics.lerp(on, v.bg, 0.22f)
        if (cr(sub, v.bg) < 4.5f) sub = on
        v = v.copy(onBg = on, onBgSub = sub)
    }
    val ac = AccentChoices[accentChoice.coerceIn(0, AccentChoices.lastIndex)].second
    if (ac != null) v = v.copy(accent = ac)
    if (li > 0) v = v.copy(mapTint = v.panel.copy(alpha = if (dark) 0.30f else 0.16f))
    val scheme = if (dark) darkColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    else lightColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    CompositionLocalProvider(LocalVw provides v) { MaterialTheme(colorScheme = scheme, content = content) }
}

val AmbientColors = listOf(
    Color(0xFF2BD66B), Color(0xFF2D8CFF), Color(0xFFFF3B4D), Color(0xFFFF9F1C), Color(0xFFEAF2FF), Color(0xFFA855F7),
)
val AmbientNames = listOf("Green", "Blue", "Red", "Amber", "White", "Purple")
val SeatRed = Color(0xFFFF4B3A)
val AutoAmber = Color(0xFFFFA726)
val MediaRed = Color(0xFFFF4B5C)
val NavBlue = Color(0xFF4DA3FF)
val PhoneGreen = Color(0xFF3DDC5A)
