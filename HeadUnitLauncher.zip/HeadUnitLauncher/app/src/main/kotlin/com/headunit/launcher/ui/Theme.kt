package com.headunit.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Follows the device dark/light setting. Colours below read this state so the whole UI recomposes on change. */
var darkMode by mutableStateOf(true)

val Rail: Color get() = if (darkMode) Color(0xFF0A0E13) else Color(0xFFE6EAF0)
val Panel: Color get() = if (darkMode) Color(0xFF11161C) else Color(0xFFF7F8FA)
val Line: Color get() = if (darkMode) Color(0xFF2A323B) else Color(0xFFC4CBD4)
val Blue = Color(0xFF2D4A9A)
val BlueSoft = Color(0xFF3A57A5)
val Accent: Color get() = if (darkMode) Color(0xFF4DA3FF) else Color(0xFF1F6FD6)
val TextDim: Color get() = if (darkMode) Color(0xFF9AA5B1) else Color(0xFF59636F)
val Green = Color(0xFF4CD08A)
/** Primary text/icon colour on Panel/Rail backgrounds. */
val Ink: Color get() = if (darkMode) Color.White else Color(0xFF11161C)

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    SideEffect { darkMode = dark }
    darkMode = dark
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = Accent, background = Rail, surface = Panel,
            onSurface = Color.White, onBackground = Color.White,
        ) else lightColorScheme(
            primary = Accent, background = Rail, surface = Panel,
            onSurface = Color(0xFF11161C), onBackground = Color(0xFF11161C),
        ),
        content = content,
    )
}
