package com.headunit.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Rail = Color(0xFF0A0E13)
val Panel = Color(0xFF11161C)
val Line = Color(0xFF2A323B)
val Blue = Color(0xFF2D4A9A)
val BlueSoft = Color(0xFF3A57A5)
val Accent = Color(0xFF4DA3FF)
val TextDim = Color(0xFF9AA5B1)
val Green = Color(0xFF4CD08A)

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Rail, surface = Panel,
            onSurface = Color.White, onBackground = Color.White,
        ),
        content = content,
    )
}
