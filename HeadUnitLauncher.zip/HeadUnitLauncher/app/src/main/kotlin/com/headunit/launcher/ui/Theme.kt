package com.headunit.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.headunit.launcher.Sun

class Vw(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color,
    val text: Color, val sub: Color, val accent: Color, val line: Color,
    val panel: Color, val tile: Color,
)

val DarkVw = Vw(true, Color(0xFF08090B), Color(0xFF232326), Color(0xFF303034), Color(0xFFF4F5F7), Color(0xFF9A9AA3), Color(0xFF3FA9F5), Color(0xFF3C3C41), Color(0xFF2A2A2D), Color(0xFF151517))
val LightVw = Vw(false, Color(0xFFCDD2D9), Color(0xFFE2E5EA), Color(0xFFD5D9DF), Color(0xFF14171C), Color(0xFF59616D), Color(0xFF0B79D0), Color(0xFFBCC2CB), Color(0xFFD9DDE3), Color(0xFFE8EBEF))
val LocalVw = staticCompositionLocalOf { DarkVw }

val Blue = Color(0xFF0B5FD0)
val BlueSoft = Color(0xFF1E74F0)
val Good = Color(0xFF34C759)
val Warn = Color(0xFFFFB020)
val Bad = Color(0xFFFF4D4D)

@Composable
fun resolveDark(mode: String, lat: Double?, lon: Double?, nowMs: Long): Boolean {
    val system = isSystemInDarkTheme()
    return when (mode) {
        "day" -> false
        "night" -> true
        "sun" -> if (lat != null && lon != null) !Sun.isDay(lat, lon, nowMs) else system
        else -> system
    }
}

@Composable
fun VwTheme(dark: Boolean, content: @Composable () -> Unit) {
    val v = if (dark) DarkVw else LightVw
    val scheme = if (dark) darkColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    else lightColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    CompositionLocalProvider(LocalVw provides v) { MaterialTheme(colorScheme = scheme, content = content) }
}

val AmbientColors = listOf(
    Color(0xFF2BD66B), Color(0xFF2D8CFF), Color(0xFFFF3B4D), Color(0xFFFF9F1C), Color(0xFFEAF2FF), Color(0xFFA855F7),
)
val AmbientNames = listOf("Green", "Blue", "Red", "Amber", "White", "Purple")
val SeatRed = Color(0xFFFF4B3A)
val AutoAmber = Color(0xFFFFA726)
val MediaRed = Color(0xFFFF4B5C)
val NavBlue = Color(0xFF4DA3FF)
val PhoneGreen = Color(0xFF3DDC5A)
