package com.headunit.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

class Vw(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color,
    val text: Color, val sub: Color, val accent: Color, val line: Color,
)

val DarkVw = Vw(true, Color(0xFF0A0D12), Color(0xFF151A22), Color(0xFF1F2630), Color(0xFFF2F5F8), Color(0xFF8E9BAB), Color(0xFF00B0F0), Color(0xFF2A323D))
val LightVw = Vw(false, Color(0xFFE9EDF2), Color(0xFFFFFFFF), Color(0xFFF1F4F8), Color(0xFF0F1722), Color(0xFF627083), Color(0xFF0086C8), Color(0xFFD3DAE3))
val LocalVw = staticCompositionLocalOf { DarkVw }

val Blue = Color(0xFF0B5FD0)
val BlueSoft = Color(0xFF1E74F0)
val Good = Color(0xFF34C759)
val Warn = Color(0xFFFFB020)
val Bad = Color(0xFFFF4D4D)

@Composable
fun resolveDark(mode: String): Boolean = when (mode) {
    "day" -> false
    "night" -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun VwTheme(dark: Boolean, content: @Composable () -> Unit) {
    val v = if (dark) DarkVw else LightVw
    val scheme = if (dark) darkColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    else lightColorScheme(primary = v.accent, background = v.bg, surface = v.surface, onSurface = v.text, onBackground = v.text)
    CompositionLocalProvider(LocalVw provides v) { MaterialTheme(colorScheme = scheme, content = content) }
}
