package com.headunit.launcher

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONObject

/** Tiny observable key/value store (Compose-aware). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
    private val m = mutableStateMapOf<String, String>().apply {
        sp.all.forEach { (k, v) -> put(k, v.toString()) }
    }

    fun s(k: String, d: String) = m[k] ?: d
    fun b(k: String, d: Boolean) = m[k]?.toBooleanStrictOrNull() ?: d
    fun i(k: String, d: Int) = m[k]?.toIntOrNull() ?: d
    fun f(k: String, d: Float) = m[k]?.toFloatOrNull() ?: d
    /** Everything except the API key, as JSON text (settings, saved places, logs...). */
    fun exportJson(): String {
        val o = JSONObject()
        m.forEach { (k, v) -> if (k != "apikey") o.put(k, v) }
        return o.toString(2)
    }

    /** Restores values from [exportJson] output; returns how many entries were applied. */
    fun importJson(text: String): Int {
        val o = JSONObject(text)
        var n = 0
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k == "apikey") continue
            put(k, o.get(k))
            n++
        }
        return n
    }

    fun put(k: String, v: Any) {
        m[k] = v.toString()
        sp.edit().putString(k, v.toString()).apply()
    }
}
