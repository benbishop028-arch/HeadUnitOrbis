package com.headunit.launcher

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf

/** Tiny observable key/value store (Compose-aware). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("drive_launcher", Context.MODE_PRIVATE)
    private val m = mutableStateMapOf<String, String>().apply {
        sp.all.forEach { (k, v) -> put(k, v.toString()) }
    }

    fun s(k: String, d: String) = m[k] ?: d
    fun b(k: String, d: Boolean) = m[k]?.toBooleanStrictOrNull() ?: d
    fun i(k: String, d: Int) = m[k]?.toIntOrNull() ?: d
    fun f(k: String, d: Float) = m[k]?.toFloatOrNull() ?: d
    fun put(k: String, v: Any) {
        m[k] = v.toString()
        sp.edit().putString(k, v.toString()).apply()
    }
}
