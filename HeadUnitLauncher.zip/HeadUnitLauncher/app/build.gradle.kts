plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val tomtomApiKey: String by project
// One APK per TomTom SDK version, installable side by side, to find which v2 release renders on the device.
val sdkVersions = mapOf("v255" to "2.5.5", "v243" to "2.4.3")

android {
    namespace = "com.headunit.launcher"
    compileSdk = 35
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "com.headunit.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
        missingDimensionStrategy("tomtom-sdk-version", "complete")
    }

    flavorDimensions += "sdk"
    productFlavors {
        sdkVersions.forEach { (flavor, version) ->
            create(flavor) {
                dimension = "sdk"
                applicationIdSuffix = ".$flavor"
                versionNameSuffix = "-sdk$version"
                buildConfigField("String", "SDK_VERSION", "\"$version\"")
                resValue("string", "app_name", "Launcher SDK $version")
            }
        }
    }

    buildFeatures { compose = true; buildConfig = true }
    buildTypes.configureEach {
        buildConfigField("String", "TOMTOM_API_KEY", "\"$tomtomApiKey\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin { jvmToolchain(17) }

dependencies {
    val bom = platform("androidx.compose:compose-bom:2025.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.github.tony19:logback-android:3.0.0")

    // TomTom Maps SDK (Orbis, v2), a different release per flavor
    sdkVersions.forEach { (flavor, version) ->
        add("${flavor}Implementation", "com.tomtom.sdk:init:$version")
        add("${flavor}Implementation", "com.tomtom.sdk.maps:map-display-compose-premium:$version")
        add("${flavor}Implementation", "com.tomtom.sdk.telemetry:telemetry:$version")
    }
}

// Put every flavor's APK in app/build/outputs/apk/debug so the existing workflow uploads all of them
tasks.register<Copy>("collectApks") {
    from(layout.buildDirectory.dir("outputs/apk")) {
        include("**/*.apk")
        exclude("debug/*.apk")
    }
    into(layout.buildDirectory.dir("outputs/apk/debug"))
    eachFile { path = name }
    includeEmptyDirs = false
    mustRunAfter(tasks.matching { it.name.startsWith("package") && it.name.endsWith("Debug") })
}
tasks.matching { it.name == "assembleDebug" }.configureEach { finalizedBy("collectApks") }
