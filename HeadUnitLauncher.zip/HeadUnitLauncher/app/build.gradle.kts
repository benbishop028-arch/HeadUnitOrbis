plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val tomtomApiKey: String by project
val tomtomSdk = "1.26.4"

android {
    namespace = "com.example.usecase"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.usecase"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    buildFeatures { viewBinding = true; buildConfig = true }
    buildTypes.configureEach {
        buildConfigField("String", "TOMTOM_API_KEY", "\"$tomtomApiKey\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation("com.tomtom.sdk.location:provider-default:$tomtomSdk")
    implementation("com.tomtom.sdk.location:provider-simulation:$tomtomSdk")
    implementation("com.tomtom.sdk.location:provider-map-matched:$tomtomSdk")
    implementation("com.tomtom.sdk.maps:map-display:$tomtomSdk")
    implementation("com.tomtom.sdk.navigation:navigation-online:$tomtomSdk")
    implementation("com.tomtom.sdk.navigation:ui:$tomtomSdk")
    implementation("com.tomtom.sdk.routing:route-planner-online:$tomtomSdk")
    implementation("com.tomtom.sdk.navigation:route-replanner-online:$tomtomSdk")
    implementation("com.tomtom.sdk:feature-toggle:$tomtomSdk")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.constraintlayout:constraintlayout:2.2.1")
    implementation("com.google.android.material:material:1.12.0")
}
